#pragma once

typedef int BSTElem;

void bstElemPrint(BSTElem elem);
int bstElemCompare(BSTElem elem1, BSTElem elem2);