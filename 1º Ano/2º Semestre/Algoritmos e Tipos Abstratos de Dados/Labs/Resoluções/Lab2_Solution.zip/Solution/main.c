#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

int     strLength(char *str);
bool    swapStrings(char *s1, char *s2, int by);

int main() {

    char s1[] = "abcdefghij";
    char s2[] = "klmnopqrst";
    int by = 3;

    swapStrings(s1, s2, by);

    printf("by = %d | s1 = \"%s\" | s2 = \"%s\" \n", 
                by, s1, s2);

    by = 1;
    //reset original characters
    strcpy(s1, "abcdefghij");
    strcpy(s2, "klmnopqrst");

    swapStrings(s1, s2, by);

    printf("by = %d | s1 = \"%s\" | s2 = \"%s\" \n", 
                by, s1, s2);

    by = 10;
    //reset original characters
    strcpy(s1, "abcdefghij");
    strcpy(s2, "klmnopqrst");

    swapStrings(s1, s2, by);

    printf("by = %d | s1 = \"%s\" | s2 = \"%s\" \n", 
                by, s1, s2);

    by = -5;
    //reset original characters
    strcpy(s1, "abcdefghij");
    strcpy(s2, "klmnopqrst");

    swapStrings(s1, s2, by);

    printf("by = %d | s1 = \"%s\" | s2 = \"%s\" \n", 
                by, s1, s2);

    return EXIT_SUCCESS;
}

int     strLength(char *str) {
    int len = 0;
    int i = 0;
    while( str[i++] != '\0') {
        len++;
    }

    return len;
}

bool    swapStrings(char *s1, char *s2, int by) {
    int len1 = strLength(s1);
    int len2 = strLength(s2);

    if ( len1 != len2 ) {
        return false;
    }

    if( by < 1 || by > len1 ) {
        return false;
    }

    for(int i=0; i< len1 ; i++) {

        if( (i+1) % by == 0 ) {
            char aux = s1[i];
            s1[i] = s2[i];
            s2[i] = aux;
        }

    }

    return true;
}
