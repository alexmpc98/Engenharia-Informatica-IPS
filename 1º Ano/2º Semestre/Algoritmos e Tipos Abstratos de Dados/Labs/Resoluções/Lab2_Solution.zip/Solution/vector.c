#include "vector.h"
#include <stdio.h>
#include <math.h>

Vector vectorCreate(int x, int y) {
    Vector v = {x, y};
    return v;
}

void vectorPrint(Vector v) {
    printf("<%d, %d>", v.x, v.y);
}

double vectorLength(Vector v) {
    return sqrt( v.x*v.x + v.y*v.y );
}

int vectorDotProduct(Vector v1, Vector v2) {

    return v1.x * v2.x + v1.y * v2.y;

}


bool existOrthogonals(Vector list[], int listSize) {

    //The complexity is of O(n^2) just for the array access.
    //If vectorDotProduct, by its own, is of O(n),
    //then the overall complexity is of O(n^3)
    for(int i=0; i<listSize; i++) {
        for(int j=i; j<listSize; j++) {
            int dot = vectorDotProduct(list[i], list[j]);
            if(dot == 0) {
                return true;
            }
        }
    }

    return false;
}

void vectorListPrint(Vector list[], int listSize, const char *name) {
    printf("%s = [ ", name);
    for(int i=0; i<listSize; i++) {
        vectorPrint(list[i]);
        printf(", ");
    }
    //with backspaces we remove the last comma ;)
    printf("\b\b ] \n");
}
