var searchData=
[
  ['false_34',['false',['../pseudocode_8txt.html#aad2457ae3f2e3d9202a113e52239ca3c',1,'pseudocode.txt']]]
];
