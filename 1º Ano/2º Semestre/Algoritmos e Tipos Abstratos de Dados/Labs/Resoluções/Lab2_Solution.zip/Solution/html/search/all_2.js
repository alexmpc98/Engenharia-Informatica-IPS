var searchData=
[
  ['input_2',['input',['../pseudocode_8txt.html#a72354259774284f3f563a31aa2f9f19a',1,'pseudocode.txt']]]
];
