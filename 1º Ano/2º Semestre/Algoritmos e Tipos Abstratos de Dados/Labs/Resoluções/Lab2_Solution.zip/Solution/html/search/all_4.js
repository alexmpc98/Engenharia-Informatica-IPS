var searchData=
[
  ['pseudocode_2etxt_6',['pseudocode.txt',['../pseudocode_8txt.html',1,'']]]
];
