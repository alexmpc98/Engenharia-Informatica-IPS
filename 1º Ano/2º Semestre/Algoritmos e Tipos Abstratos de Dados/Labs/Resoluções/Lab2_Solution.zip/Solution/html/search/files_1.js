var searchData=
[
  ['pseudocode_2etxt_22',['pseudocode.txt',['../pseudocode_8txt.html',1,'']]]
];
