var indexSectionsWithContent =
{
  0: "efimpsvxy",
  1: "v",
  2: "mpv",
  3: "emsv",
  4: "fixy",
  5: "v"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs"
};

