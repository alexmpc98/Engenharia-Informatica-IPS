var structvector =
[
    [ "x", "structvector.html#a0403eb3aea23a3009e276fba1d317046", null ],
    [ "y", "structvector.html#aad6de640298eae97ca0a094db5aff477", null ]
];