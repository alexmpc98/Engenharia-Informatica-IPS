var searchData=
[
  ['existorthogonals_25',['existOrthogonals',['../vector_8c.html#a49fed5da93753d896dbc5df413e2f357',1,'existOrthogonals(Vector list[], int listSize):&#160;vector.c'],['../vector_8h.html#a49fed5da93753d896dbc5df413e2f357',1,'existOrthogonals(Vector list[], int listSize):&#160;vector.c']]]
];
