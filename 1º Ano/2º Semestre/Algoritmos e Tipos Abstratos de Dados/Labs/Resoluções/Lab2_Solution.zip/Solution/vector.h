#pragma once

#include <stdbool.h>

/**
 * @brief Represents a 2d Vector in Euclidean space.
 */
typedef struct vector {
    int x; ///< Scalar projection on the x-axis
    int y; ///< Scalar projection on the y-axis
} Vector;

/**
 * @brief Creates and initializes a new instance of a Vector.
 * 
 * @param x [in] scalar projection on the x-axis
 * @param y [in] scalar projection on the y-axis.
 * 
 * @return a new Vector instance. 
 */
Vector vectorCreate(int x, int y);

/**
 * @brief Prints the Vector instance 'v'.
 * 
 * The format is "<x, y>"".
 * 
 * @param v [in] Vector instance.
 */
void vectorPrint(Vector v);

/**
 * @brief Computes the length, or magnitude, of a Vector.
 * 
 * @param v [in] Vector instance.
 * 
 * @return the length, or magnitude, of 'v'. 
 */
double vectorLength(Vector v);

/**
 * @brief Computes the dot product between two instances of Vector.
 * 
 * @param v1 [in] instance of Vector.
 * @param v2 [in] instance of Vector.
 * @return the dot product between 'v1' and 'v2' 
 */
int vectorDotProduct(Vector v1, Vector v2);

/**
 * @brief Verifies if any two elements of a list of Vector are orthogonal.
 * 
 * @param list [in] array of Vector.
 * @param listSize [in] array of Vector size.
 * @return true if there are any two orthogonal vectors in 'list'.
 * @return false if there are NO orthogonal vectors in 'list'.
 */
bool existOrthogonals(Vector list[], int listSize);

/**
 * @brief Prints a Vector array.
 * 
 * @param list [in] array of Vector.
 * @param listSize [in] array of Vector size.
 * @param name [in] name of array of Vector.
 */
void vectorListPrint(Vector list[], int listSize, const char *name);