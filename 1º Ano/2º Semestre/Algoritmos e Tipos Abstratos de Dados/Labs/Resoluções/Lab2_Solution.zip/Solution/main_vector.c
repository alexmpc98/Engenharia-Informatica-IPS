#include <stdio.h>
#include <stdlib.h>
#include "vector.h"

int main() {

    Vector  a = vectorCreate(4, 6),
            b = vectorCreate(-3, 2),
            c = vectorCreate(1, 3);
    
    double lenA = vectorLength(a);
    
    int a_b = vectorDotProduct(a, b);
    int a_c = vectorDotProduct(a, c);

    //not conventional, but more compact
    printf("a = "); vectorPrint(a); printf("\n");
    printf("b = "); vectorPrint(b); printf("\n");
    printf("c = "); vectorPrint(c); printf("\n");

    printf("|a| = %.6f \n", lenA);

    printf("a . b = %d \n", a_b);

    printf("a . c = %d \n", a_c);

    Vector vList1[] = {a, b, c};
    Vector vList2[] = {a, c, 
                        vectorCreate(0,2), 
                        vectorCreate(-1,5) };

    bool res1 = existOrthogonals(vList1, 3);
    bool res2 = existOrthogonals(vList2, 4);

    vectorListPrint(vList1, 3, "vList1");
    printf("vList1 exist orthogonals? %s \n", res1 ? "true" : "false");
    
    vectorListPrint(vList2, 4, "vList2");
    printf("vList2 exist orthogonals? %s \n", res2 ? "true" : "false");

}