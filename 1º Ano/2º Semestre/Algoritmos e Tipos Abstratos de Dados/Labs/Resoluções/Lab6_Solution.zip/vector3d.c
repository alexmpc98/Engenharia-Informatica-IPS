/**
 * @file vector3d.c
 * @author brunomnsilva@gmail.com
 * @brief 
 * @version 0.1
 * @date 2020-04-29
 * 
 * @copyright Copyright (c) 2020
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#include "vector3d.h"

typedef struct vector3d {
    double x;
    double y;
    double z;
} Vector3d;

PtVector3d  vector3dCreate(double x, double y, double z) {
    PtVector3d p = (PtVector3d)malloc(sizeof(Vector3d));

    if( p == NULL ) return NULL;

    p->x = x;
    p->y = y;
    p->z = z;

    return p;
}

int vector3dDestroy(PtVector3d *ptrP) {
    PtVector3d p = *ptrP;

    if( p == NULL ) return VECTOR3_NULL;

    free(p);

    *ptrP = NULL;

    return VECTOR3_OK;
}

int vector3dX(PtVector3d p, double *x) {
    if( p == NULL ) return VECTOR3_NULL;

    *x = p->x;

    return VECTOR3_OK;
}

int vector3dY(PtVector3d p, double *y) {
    if( p == NULL ) return VECTOR3_NULL;

    *y = p->y;

    return VECTOR3_OK;
}

int vector3dZ(PtVector3d p, double *z) {
    if( p == NULL ) return VECTOR3_NULL;

    *z = p->z;

    return VECTOR3_OK;
}

PtVector3d vector3dMultiplyByScalar(PtVector3d p, double scalar) {
    if( p == NULL ) return NULL;

    PtVector3d c = vector3dCreate(p->x * scalar, p->y * scalar, p->z * scalar);
    
    return c;
}

PtVector3d vector3dDivideByScalar(PtVector3d p, double scalar) {
    if( p == NULL ) return NULL;
    if( scalar == 0 ) return NULL;

    PtVector3d c = vector3dCreate(p->x * scalar, p->y * scalar, p->z * scalar);
    
    return c;
}

PtVector3d vector3dAdd(PtVector3d p1, PtVector3d p2) {
    if( p1 == NULL || p2 == NULL ) return NULL;

    PtVector3d c = vector3dCreate(p1->x + p2->x, p1->y + p2->y, p1->z + p2->z);
    
    return c;  
}

PtVector3d vector3dSubstract(PtVector3d p1, PtVector3d p2) {
    if( p1 == NULL || p2 == NULL ) return NULL;

    PtVector3d c = vector3dCreate(p1->x - p2->x, p1->y - p2->y, p1->z - p2->z);
    
    return c;  
}

int vector3dMagnitude(PtVector3d p, double *magnitude) {
    if( p == NULL ) return VECTOR3_NULL;

    /* ||p|| = sqrt(x^2 + y^2 + z^2) */
    *magnitude = sqrt(p->x * p->x + p->y * p->y + p->z * p->z);
    
    return VECTOR3_OK;
}

PtVector3d vector3dNormalize(PtVector3d p) {
    if( p == NULL ) return NULL;

     /* norm(p) = p / ||p|| */
     double magnitude = 0;
     vector3dMagnitude(p, &magnitude);

    /* if ||p|| is zero, then (0,0,0) should be returned */
    if( magnitude == 0) {
        return vector3dCreate(0, 0, 0);
    } else {
        PtVector3d c = vector3dCreate(p->x, p->y, p->z);
        PtVector3d norm = vector3dDivideByScalar(c, magnitude);

        free(c);

        return norm;        
    }
}

bool vector3dOrthogonals(PtVector3d p1, PtVector3d p2) {
    if( p1 == NULL || p2 == NULL ) return false;

    /* orthogonal if inner/dot product between is zero */
    double innerProd = p1->x * p2->x + p1->y * p2->y + p1->z * p2->z;

    return (innerProd == 0) ? true : false; 
}

void vector3dPrint(PtVector3d p, bool lineBreakAfter) {
    /* Format <x, y, z>*/
    if( p == NULL) {
        printf("<NULL>");
    } else {
        printf("<%.2lf, %.2lf, %.2lf>", p->x, p->y, p->z);
    }

    if(lineBreakAfter) printf("\n");
}