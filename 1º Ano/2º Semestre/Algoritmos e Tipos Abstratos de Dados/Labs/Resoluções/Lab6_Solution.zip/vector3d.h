/**
 * @file vector3D.h
 * @author brunomnsilva@gmail.com
 * @brief 
 * @version 0.1
 * @date 2020-04-29
 * 
 * @copyright Copyright (c) 2020
 * 
 */

#pragma once

#include <stdbool.h>

#define VECTOR3_OK      0
#define VECTOR3_NULL    1

struct vector3d;
typedef struct vector3d* PtVector3d;

/**
 * @brief Creates a new vector
 * 
 * @param x [in] x component
 * @param y [in] y component
 * @param z [in] z component
 * @return PtVector3d pointer to allocated data structure
 * @return NULL if no memory available
 */
PtVector3d  vector3dCreate(double x, double y, double z);

/**
 * @brief Frees the underlying data structure
 * 
 * @param ptrP [in] address of PtVector3d
 * @return VECTOR3_OK if successful
 * @return VECTOR3_NULL if *ptrP is NULL
 */
int vector3dDestroy(PtVector3d *ptrP);

/**
 * @brief Retrieves the X component of a vector
 * 
 * @param p [in] PtVector3d pointer
 * @param x [out] address of variable to hold the value
 * @return VECTOR3_OK if successful and value in *x
 * @return VECTOR3_NULL if p is NULL and x unmodified
 */
int vector3dX(PtVector3d p, double *x);

/**
 * @brief Retrieves the Y component of a vector
 * 
 * @param p [in] PtVector3d pointer
 * @param y [out] address of variable to hold the value
 * @return VECTOR3_OK if successful and value in *y
 * @return VECTOR3_NULL if p is NULL and y unmodified
 */
int vector3dY(PtVector3d p, double *y);

/**
 * @brief Retrieves the Z component of a vector
 * 
 * @param p [in] PtVector3d pointer
 * @param z [out] address of variable to hold the value
 * @return VECTOR3_OK if successful and value in *z
 * @return VECTOR3_NULL if p is NULL and *z unmodified
 */
int vector3dZ(PtVector3d p, double *z);

/**
 * @brief Returns the multiplication of a vector by a scalar
 * 
 * The result is a number with their components multipled by 'scalar'
 * 
 * @param p [in] PtVector3d pointer
 * @param scalar [in] the scalar to multiply
 * @return PtVector3d pointer for the resulting number
 * @return NULL if p is NULL
 */
PtVector3d vector3dMultiplyByScalar(PtVector3d p, double scalar);

/**
 * @brief Returns the division of a vector by a scalar
 * 
 * The result is a number with their components divided by 'scalar'.
 * 
 * If 'scalar' is zero, the number cannot be calculated.
 * 
 * @param p [in] PtVector3d pointer
 * @param scalar [in] the scalar to multiply
 * @return PtVector3d pointer for the resulting number
 * @return NULL if p is NULL
 * @return NULL if 'scalar' is zero
 */
PtVector3d vector3dDivideByScalar(PtVector3d p, double scalar);

/**
 * @brief Computes the sum between two vectors
 * 
 * @param p1 [in] PtVector3d pointer
 * @param p2 [in] PtVector3d pointer
 * @return PtVector3d pointer for the resulting number
 * @return NULL if p1 is NULL or p2 is NULL
 */
PtVector3d vector3dAdd(PtVector3d p1, PtVector3d p2);

/**
 * @brief Computes the difference between two vectors
 * 
 * @param p1 [in] PtVector3d pointer
 * @param p2 [in] PtVector3d pointer
 * @return PtVector3d pointer for the resulting number
 * @return NULL if p1 is NULL or p2 is NULL
 */
PtVector3d vector3dSubstract(PtVector3d p1, PtVector3d p2);

/**
 * @brief Computes the magnitude (or length) of a vector
 * 
 * @param p [in] PtVector3d pointer
 * @param magnitude [out] address of variable to hold the value
 * @return VECTOR3_OK if successful and value in *magnitude
 * @return VECTOR3_NULL if p is NULL and *magnitude unmodified
 */
int vector3dMagnitude(PtVector3d p, double *magnitude);

/**
 * @brief Normalizes a vector
 * 
 * @param p [in] PtVector3d pointer
 * @return PtVector3d pointer to resulting number
 * @return NULL if p is NULL
 */
PtVector3d vector3dNormalize(PtVector3d p);

/**
 * @brief Checks whether two vectors are orthogonal
 * 
 * @param p1 [in] PtVector3d pointer
 * @param p2 [in] PtVector3d pointer
 * @return true if they are orthogonal
 * @return false if they are not orthogonal
 * @return false if p1 is NULL or p2 is NULL
 */
bool vector3dOrthogonals(PtVector3d p1, PtVector3d p2);

/**
 * @brief Prints a vector
 * 
 * @param p [in] PtVector3d pointer
 * @param lineBreakAfter [in] if a line break should be put afterwards
 */
void vector3dPrint(PtVector3d p, bool lineBreakAfter);

