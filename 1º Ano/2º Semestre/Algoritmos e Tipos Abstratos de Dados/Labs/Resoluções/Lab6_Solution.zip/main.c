/**
 * @file main.c
 * @author brunomnsilva@gmail.com
 * @brief 
 * @version 0.1
 * @date 2020-04-29
 * 
 * @copyright Copyright (c) 2020
 * 
 * Example of operations of ADT Vector3d
 * 
 */

#include <stdio.h>
#include <stdlib.h>

#include "vector3d.h"

int main() {

    /* constuctors */
    PtVector3d a = vector3dCreate(1, 2, 0);
    PtVector3d b = vector3dCreate(3, 4, -1);
    PtVector3d c = vector3dCreate(2, -1, 10);

    if(a == NULL | b == NULL | c == NULL) {
        printf("Could not create vectors! Exiting... \n");
        return EXIT_FAILURE;
    }

    printf("a = "); vector3dPrint(a, true);
    printf("b = "); vector3dPrint(b, true);
    printf("c = "); vector3dPrint(c, true);

    /* accessors */
    double x = 0, y = 0, z = 0;
    vector3dX(a, &x);
    vector3dX(a, &y);
    vector3dX(a, &z);

    printf("Components of a: X = %.lf2 | Y = %.lf2 | Z = %.lf2 \n", x, y, z);

    /* magnitude and normalization */ 
    double magnitude = 0;
    vector3dMagnitude(a, &magnitude);

    printf("||a|| = %.2lf \n", magnitude);

    PtVector3d normB = vector3dNormalize(b);
    printf("norm(b) = "); vector3dPrint(normB, true);

    /* orthogonals */
    bool ortho_ab = vector3dOrthogonals(a, b);
    bool ortho_ac = vector3dOrthogonals(a, c);

    printf("Are a and b orthogonal? %s \n", ( ortho_ab ? "true" : "false" ) );
    printf("Are a and c orthogonal? %s \n", ( ortho_ac ? "true" : "false" ) );

    /* destructors */
    vector3dDestroy(&a);
    vector3dDestroy(&b);
    vector3dDestroy(&c);
    vector3dDestroy(&normB);

    return EXIT_SUCCESS;
}