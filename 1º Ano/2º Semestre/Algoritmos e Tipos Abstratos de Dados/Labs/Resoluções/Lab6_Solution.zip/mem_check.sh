#!/bin/bash

valgrind --leak-check=full ./prog
