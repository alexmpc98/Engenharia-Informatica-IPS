#include "time.h"
#include <stdio.h>
#include <stdlib.h>

void timePrint(Time t) {
    printf("%02d:%02d:%02d", t.hours, t.minutes, t.seconds);
}

Time timeCreate(int h, int m, int s) {
    //TODO: improve and verify values and trunk them
    //to 0-23 or 0-59
    
    Time t = {h, m, s};
    return t;
}

int timeToSeconds(Time t) {
    return t.hours * 3600 + t.minutes * 60 + t.seconds;
}

Time timeUpdate(Time t) {
    //we can solve this with a lot of conditional statements.
    //or we can be smart about it: 1) convert time to seconds;
    //2) increment the necessary amount (arbitrary), and;
    //3) convert back to time
    int seconds = timeToSeconds(t);
    printf("seconds = %d \n", seconds);
    seconds += 1;
    return convertSecondsToTime(seconds);

}

Time convertSecondsToTime(int s) {
    //use integer division to solve this

    int remainingSeconds = s;

    int hours = remainingSeconds / 3600;
    remainingSeconds = remainingSeconds % 3600;

    int minutes = remainingSeconds / 60;
    remainingSeconds = remainingSeconds % 60;

    int seconds = remainingSeconds;

    //note that the seconds can span for over 24H. 
    //In that case, we'll trunk it to 24 hours
    hours = hours % 24;

    Time result = {hours, minutes, seconds};
    return result;
}

void  printSecondsToDayandTime(int n) {
    int day = n / (24 * 3600); 
    n %= (24 * 3600); 

    int hour = n / 3600; 
    n %= 3600; 

    int minutes = n / 60 ; 
    n %= 60; 

    int seconds = n; 

    printf("%d days %d hours %d minutes %d seconds\n", day,hour, minutes, seconds);
}

Time timeDiff(Time t1, Time t2) {
    //use existing functions to solve this problem
    int seconds1 = timeToSeconds(t1);
    int seconds2 = timeToSeconds(t2);

    int diff = seconds1 - seconds2;

    return convertSecondsToTime(diff);
}