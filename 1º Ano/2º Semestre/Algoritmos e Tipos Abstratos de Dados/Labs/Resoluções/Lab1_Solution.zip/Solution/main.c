#include <stdio.h>
#include <stdlib.h>
#include "time.h"

int main() {

    Time t1 = timeCreate(16, 27, 32);    
    timePrint(t1);
    printf("\n");
    //output:
    //16:27:32

    Time t2 = {5,34,59}; 
    Time t2Update = timeUpdate(t2);
    timePrint(t2Update);
    printf("\n");
    //output:
    //05:35:00

    Time t3 = {23,59,59}; 
    Time t3Update = timeUpdate(t3);
    timePrint(t3Update);
    printf("\n");
    //output:
    //00:00:00

    Time t4 = convertSecondsToTime(12345678);
    timePrint(t4);
    printf("\n");
    //output:
    //21:21:18

    printSecondsToDayandTime(12345678);
    //output:
    //142 days 21 hours 21 minutes 18 seconds

    Time diff = timeDiff(t3, t2);
    timePrint(diff);
    printf("\n");
    //output:
    //21:21:18


    return EXIT_SUCCESS;
}