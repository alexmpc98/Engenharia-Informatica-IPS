#pragma once

typedef struct time {

    int hours;
    int minutes;
    int seconds;

} Time;

/**
 * @brief Prints as instance of a time structure.
 * 
 * Prints in the format HH:MM:SS
 * 
 * @param t [in] time to print.
 */
void timePrint(Time t);

/**
 * @brief Creates and initializes an instance of a time structure.
 * 
 * @param h [in] value for hours
 * @param m [in] value for minutes
 * @param s [in] value for seconds
 * 
 * @return the created instance 
 */
Time timeCreate(int h, int m, int s);

/**
 * @brief Increments by a second an existing time structure.
 * 
 * @param t [in] the time instance.
 * 
 * @return a new instance with the time incremented by 1 second. 
 */
Time timeUpdate(Time t);

/**
 * @brief Converts a given number of seconds to a time structure.
 * 
 * @param s [in] number of seconds to convert.
 * 
 * @return a new time structure representing the given seconds. 
 */
Time convertSecondsToTime(int s);

/**
 * @brief Converts and prints a given number of seconds to a long format.
 * 
 * Prints in the format DD:HH:MM:SS.
 * 
 * @param n [in] number of seconds to convert.
 */
void  printSecondsToDayandTime(int n);

/**
 * @brief Computes and returns the difference between two time structures.
 * 
 * Computes t1 - t2.
 * 
 * @param t1 [in] instance of time 
 * @param t2 [in] instance of time
 * 
 * @return time structure representing the difference between t1 and t2.
 */
Time timeDiff(Time t1, Time t2);