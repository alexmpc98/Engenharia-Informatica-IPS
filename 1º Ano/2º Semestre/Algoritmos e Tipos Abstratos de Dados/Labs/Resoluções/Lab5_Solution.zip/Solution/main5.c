#include <stdio.h>
#include <stdlib.h>

typedef struct array {
    int *numbers;
    int size;
} Array;

typedef struct array* PtArray;

int     fib(int n);
PtArray    fibArrayCreate(int n);
void    fibArrayPrint(PtArray arr);

void    fibArrayDestroy(PtArray *ptArray);
void    fibArrayExpand(PtArray arr);

int main() {

    int n;
    printf("Length of fib sequence?: ");
    scanf("%d", &n);

    PtArray v = fibArrayCreate(n);
    printf("Address of array = %p \n", v);
    fibArrayPrint(v);

    fibArrayExpand(v);
    fibArrayPrint(v);

    fibArrayDestroy(&v);
    printf("Address of array = %p \n", v);
    fibArrayPrint(v);

    return EXIT_SUCCESS;
}

void    fibArrayDestroy(PtArray *ptArr) {
    PtArray arr = *ptArr;

    if( arr == NULL ) return;

    free(arr->numbers);
    free(arr);

    *ptArr = NULL;
}

void    fibArrayExpand(PtArray arr) {
  
    if( arr == NULL || arr->numbers == NULL) return;

    int newSize = arr->size * 2;

    int *try = (int*) realloc(arr->numbers, newSize * sizeof(int) );
    
    // if cannot reallocate, do nothing, change nothing!
    if(try == NULL) return;

    //fill other values
    for(int i=arr->size; i<newSize; i++) {
        try[i] = fib(i+1);
    }

    //must change address stored at arr->number and size
    arr->numbers = try;
    arr->size = newSize;
}

int     fib(int n) {
    if(n <= 1) return 1;
    else if(n == 2) return 1;
    else return fib(n-1) + fib(n-2);
}

PtArray    fibArrayCreate(int n) {
    if(n < 1) return NULL;

    PtArray arr = (PtArray)malloc(sizeof(Array));
    arr->numbers = (int*)malloc( n * sizeof(int) );
    for(int i=0; i<n; i++) {
        arr->numbers[i] = fib(i+1);
    }
    arr->size = n;
    return arr;
}

void    fibArrayPrint(PtArray arr) {
    if(arr == NULL) {
        printf("(NULL)\n");
        return;
    }

    printf("{");
    for(int i=0; i<arr->size-1; i++) {
        printf("%d, ", arr->numbers[i] );
    }
    printf("%d}\n", arr->numbers[arr->size-1]);
}
