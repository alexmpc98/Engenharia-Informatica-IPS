#include <stdio.h>
#include <stdlib.h>

int     fib(int n);
int*    fibArrayCreate(int n);
void    fibArrayPrint(int *arr, int size);

void    fibArrayDestroy(int **arr);
void    fibArrayExpand(int **ptArr, int *size);

int main() {

    int n;
    printf("Length of fib sequence?: ");
    scanf("%d", &n);

    int *v = fibArrayCreate(n);
    printf("Address of array = %p \n", v);
    fibArrayPrint(v, n);

    fibArrayExpand(&v, &n);
    fibArrayPrint(v, n);

    fibArrayDestroy(&v);
    printf("Address of array = %p \n", v);
    fibArrayPrint(v, n);

    return EXIT_SUCCESS;
}

void    fibArrayDestroy(int **ptArr) {
    int *arr = *ptArr;

    if( arr == NULL ) return;

    free(arr);

    *ptArr = NULL;
}

void    fibArrayExpand(int **ptArr, int *size) {
    int *arr = *ptArr;
    
    if( arr == NULL || *size < 1) return;

    int newSize = (*size) * 2;

    int *try = (int*) realloc(arr, newSize * sizeof(int) );
    
    // if cannot reallocate, do nothing, change nothing!
    if(try == NULL) return;

    //fill other values
    for(int i=*size; i<newSize; i++) {
        try[i] = fib(i+1);
    }

    //must change address stored at *ptArr and size
    *ptArr = try;
    *size = newSize;
}

int     fib(int n) {
    if(n <= 1) return 1;
    else if(n == 2) return 1;
    else return fib(n-1) + fib(n-2);
}

int*    fibArrayCreate(int n) {
    if(n < 1) return NULL;

    int *arr = (int*)malloc( n * sizeof(int) );
    for(int i=0; i<n; i++) {
        arr[i] = fib(i+1);
    }
    return arr;
}

void    fibArrayPrint(int *arr, int size) {
    if(arr == NULL) {
        printf("(NULL)\n");
        return;
    }

    printf("{");
    for(int i=0; i<size-1; i++) {
        printf("%d, ", arr[i] );
    }
    printf("%d}\n", arr[size-1]);
}
