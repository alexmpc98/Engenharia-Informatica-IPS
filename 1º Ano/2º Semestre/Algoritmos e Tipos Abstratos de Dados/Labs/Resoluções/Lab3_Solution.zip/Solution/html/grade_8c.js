var grade_8c =
[
    [ "gradeArrayApproved", "grade_8c.html#a6fb51b3c97d305085695b79022469a83", null ],
    [ "gradeArrayIndexOfHighest", "grade_8c.html#a9c0f6d03a4cccd97b2e19da1d8897468", null ],
    [ "gradeArrayIndexOfLowest", "grade_8c.html#a66dc5072666cb9f97ff4275d82a26fb2", null ],
    [ "gradeArrayPrint", "grade_8c.html#ad49900bcc72d771e3a53a0a4ef3b459d", null ],
    [ "gradeArraySortByResult", "grade_8c.html#a4e023852ce37b2c3e128ff54c3aace88", null ],
    [ "gradeArrayStats", "grade_8c.html#a9be0439a7fdee21a12ae6b16524fc2a1", null ],
    [ "gradeCreate", "grade_8c.html#acafbbfc8006d2e6367317a95b967f833", null ],
    [ "gradePrint", "grade_8c.html#a8e9a23346a8ac879b18c4a5962cc23e2", null ],
    [ "resultExists", "grade_8c.html#a017756b455cb8c31a27c99127fd6d89c", null ],
    [ "studentSortByNumber", "grade_8c.html#aa9c3b81c6265f8506f09f36c159928e9", null ]
];