var searchData=
[
  ['name',['name',['../structstudent.html#add54048add4a86ffb81c5f21ba63fba5',1,'student']]],
  ['number',['number',['../structstudent.html#ab3bb5637a4a41bebea9ec0a152f979b0',1,'student']]]
];
