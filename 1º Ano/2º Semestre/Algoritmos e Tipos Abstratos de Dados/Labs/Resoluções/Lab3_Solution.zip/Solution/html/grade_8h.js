var grade_8h =
[
    [ "grade", "structgrade.html", "structgrade" ],
    [ "Grade", "grade_8h.html#af45e3b53f2d71fa8e57991bff21d6aec", null ],
    [ "gradeArrayApproved", "grade_8h.html#a6fb51b3c97d305085695b79022469a83", null ],
    [ "gradeArrayIndexOfHighest", "grade_8h.html#a9c0f6d03a4cccd97b2e19da1d8897468", null ],
    [ "gradeArrayIndexOfLowest", "grade_8h.html#a66dc5072666cb9f97ff4275d82a26fb2", null ],
    [ "gradeArrayPrint", "grade_8h.html#ad49900bcc72d771e3a53a0a4ef3b459d", null ],
    [ "gradeArraySortByResult", "grade_8h.html#a4e023852ce37b2c3e128ff54c3aace88", null ],
    [ "gradeArrayStats", "grade_8h.html#a9be0439a7fdee21a12ae6b16524fc2a1", null ],
    [ "gradeCreate", "grade_8h.html#acafbbfc8006d2e6367317a95b967f833", null ],
    [ "gradePrint", "grade_8h.html#a8e9a23346a8ac879b18c4a5962cc23e2", null ],
    [ "resultExists", "grade_8h.html#a017756b455cb8c31a27c99127fd6d89c", null ],
    [ "studentSortByNumber", "grade_8h.html#aa9c3b81c6265f8506f09f36c159928e9", null ]
];