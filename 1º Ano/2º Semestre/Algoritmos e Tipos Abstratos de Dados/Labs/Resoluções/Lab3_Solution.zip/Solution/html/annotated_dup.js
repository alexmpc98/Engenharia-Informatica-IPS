var annotated_dup =
[
    [ "grade", "structgrade.html", "structgrade" ],
    [ "student", "structstudent.html", "structstudent" ]
];