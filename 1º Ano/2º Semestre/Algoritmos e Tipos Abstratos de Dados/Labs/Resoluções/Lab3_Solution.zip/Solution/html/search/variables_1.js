var searchData=
[
  ['result',['result',['../structgrade.html#ac5f8b8ed08f4e11cf782073904460d7c',1,'grade']]]
];
