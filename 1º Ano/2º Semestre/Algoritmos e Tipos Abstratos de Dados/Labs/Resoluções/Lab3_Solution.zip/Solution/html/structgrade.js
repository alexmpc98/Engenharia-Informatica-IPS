var structgrade =
[
    [ "result", "structgrade.html#ac5f8b8ed08f4e11cf782073904460d7c", null ],
    [ "student", "structgrade.html#a2f297b944b36944bfd15bb08a5597550", null ]
];