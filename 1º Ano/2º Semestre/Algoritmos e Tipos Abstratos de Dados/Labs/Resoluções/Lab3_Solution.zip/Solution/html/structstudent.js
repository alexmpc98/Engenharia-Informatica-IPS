var structstudent =
[
    [ "name", "structstudent.html#add54048add4a86ffb81c5f21ba63fba5", null ],
    [ "number", "structstudent.html#ab3bb5637a4a41bebea9ec0a152f979b0", null ]
];