var searchData=
[
  ['grade',['grade',['../structgrade.html',1,'grade'],['../grade_8h.html#af45e3b53f2d71fa8e57991bff21d6aec',1,'Grade():&#160;grade.h']]],
  ['grade_2ec',['grade.c',['../grade_8c.html',1,'']]],
  ['grade_2eh',['grade.h',['../grade_8h.html',1,'']]],
  ['gradearrayapproved',['gradeArrayApproved',['../grade_8c.html#a6fb51b3c97d305085695b79022469a83',1,'gradeArrayApproved(Grade *gradeArr, int size):&#160;grade.c'],['../grade_8h.html#a6fb51b3c97d305085695b79022469a83',1,'gradeArrayApproved(Grade *gradeArr, int size):&#160;grade.c']]],
  ['gradearrayindexofhighest',['gradeArrayIndexOfHighest',['../grade_8c.html#a9c0f6d03a4cccd97b2e19da1d8897468',1,'gradeArrayIndexOfHighest(Grade *gradeArr, int size):&#160;grade.c'],['../grade_8h.html#a9c0f6d03a4cccd97b2e19da1d8897468',1,'gradeArrayIndexOfHighest(Grade *gradeArr, int size):&#160;grade.c']]],
  ['gradearrayindexoflowest',['gradeArrayIndexOfLowest',['../grade_8c.html#a66dc5072666cb9f97ff4275d82a26fb2',1,'gradeArrayIndexOfLowest(Grade *gradeArr, int size):&#160;grade.c'],['../grade_8h.html#a66dc5072666cb9f97ff4275d82a26fb2',1,'gradeArrayIndexOfLowest(Grade *gradeArr, int size):&#160;grade.c']]],
  ['gradearrayprint',['gradeArrayPrint',['../grade_8c.html#ad49900bcc72d771e3a53a0a4ef3b459d',1,'gradeArrayPrint(Grade *gradeArr, int size):&#160;grade.c'],['../grade_8h.html#ad49900bcc72d771e3a53a0a4ef3b459d',1,'gradeArrayPrint(Grade *gradeArr, int size):&#160;grade.c']]],
  ['gradearraysortbyresult',['gradeArraySortByResult',['../grade_8c.html#a4e023852ce37b2c3e128ff54c3aace88',1,'gradeArraySortByResult(Grade *gradeArr, int size):&#160;grade.c'],['../grade_8h.html#a4e023852ce37b2c3e128ff54c3aace88',1,'gradeArraySortByResult(Grade *gradeArr, int size):&#160;grade.c']]],
  ['gradearraystats',['gradeArrayStats',['../grade_8c.html#a9be0439a7fdee21a12ae6b16524fc2a1',1,'gradeArrayStats(Grade *gradeArr, int size):&#160;grade.c'],['../grade_8h.html#a9be0439a7fdee21a12ae6b16524fc2a1',1,'gradeArrayStats(Grade *gradeArr, int size):&#160;grade.c']]],
  ['gradecreate',['gradeCreate',['../grade_8c.html#acafbbfc8006d2e6367317a95b967f833',1,'gradeCreate(int number, char *name, float result):&#160;grade.c'],['../grade_8h.html#acafbbfc8006d2e6367317a95b967f833',1,'gradeCreate(int number, char *name, float result):&#160;grade.c']]],
  ['gradeprint',['gradePrint',['../grade_8c.html#a8e9a23346a8ac879b18c4a5962cc23e2',1,'gradePrint(Grade g):&#160;grade.c'],['../grade_8h.html#a8e9a23346a8ac879b18c4a5962cc23e2',1,'gradePrint(Grade g):&#160;grade.c']]]
];
