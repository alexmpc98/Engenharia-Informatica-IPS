var searchData=
[
  ['student',['student',['../structgrade.html#a2f297b944b36944bfd15bb08a5597550',1,'grade']]]
];
