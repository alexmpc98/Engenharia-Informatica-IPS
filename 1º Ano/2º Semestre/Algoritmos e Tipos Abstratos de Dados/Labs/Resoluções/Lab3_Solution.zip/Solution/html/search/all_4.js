var searchData=
[
  ['result',['result',['../structgrade.html#ac5f8b8ed08f4e11cf782073904460d7c',1,'grade']]],
  ['resultexists',['resultExists',['../grade_8c.html#a017756b455cb8c31a27c99127fd6d89c',1,'resultExists(Grade *gradeArr, int size, float value):&#160;grade.c'],['../grade_8h.html#a017756b455cb8c31a27c99127fd6d89c',1,'resultExists(Grade *gradeArr, int size, float value):&#160;grade.c']]]
];
