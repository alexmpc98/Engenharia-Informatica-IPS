var student_8h =
[
    [ "student", "structstudent.html", "structstudent" ],
    [ "Student", "student_8h.html#a8519285243ab361f62c99f432b9b497c", null ],
    [ "studentCreate", "student_8h.html#aca896f97995ef6ff95f7cbec4f5c72d4", null ]
];