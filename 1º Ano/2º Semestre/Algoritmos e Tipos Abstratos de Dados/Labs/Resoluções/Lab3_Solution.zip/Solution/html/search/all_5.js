var searchData=
[
  ['student',['student',['../structstudent.html',1,'student'],['../structgrade.html#a2f297b944b36944bfd15bb08a5597550',1,'grade::student()'],['../student_8h.html#a8519285243ab361f62c99f432b9b497c',1,'Student():&#160;student.h']]],
  ['student_2ec',['student.c',['../student_8c.html',1,'']]],
  ['student_2eh',['student.h',['../student_8h.html',1,'']]],
  ['studentcreate',['studentCreate',['../student_8c.html#aca896f97995ef6ff95f7cbec4f5c72d4',1,'studentCreate(int number, char *name):&#160;student.c'],['../student_8h.html#aca896f97995ef6ff95f7cbec4f5c72d4',1,'studentCreate(int number, char *name):&#160;student.c']]],
  ['studentsortbynumber',['studentSortByNumber',['../grade_8c.html#aa9c3b81c6265f8506f09f36c159928e9',1,'studentSortByNumber(Grade *gradeArr, int size):&#160;grade.c'],['../grade_8h.html#aa9c3b81c6265f8506f09f36c159928e9',1,'studentSortByNumber(Grade *gradeArr, int size):&#160;grade.c']]]
];
