/**
 * @file main.c
 * @author João Capinha
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define ELEMENTS 10

//Nivel 1
void randomArray(int *intArray, int size);
void intArrayPrint(int *intArray, int size);
void arraySort(int *intArray, int size);

//Nivel 2
int orderedBinarySearch(int val, int *arr, int start, int end);

int main()
{
    //Nivel 1
    int intArray[ELEMENTS];
    randomArray(intArray, ELEMENTS);

    printf("\nVetor ordenado de forma crescente:\n");
    arraySort(intArray, ELEMENTS);
    intArrayPrint(intArray, ELEMENTS);

    //Nivel 2
    int valueSearch;
    printf("\nInsira um valor a procurar no vetor: ");
    scanf("%d", &valueSearch);
    int index = orderedBinarySearch(valueSearch, intArray, 0, ELEMENTS);
    (index != -1) ? printf("\nValor %d encontrado na posição %d do vetor", valueSearch, index) : printf("\nValor não encontrado no vetor");

    return EXIT_SUCCESS;
}

/**
 * @brief Generate random value in [0,99] for all positions array.
 * 
 * @param intArray  The integer's array.
 * @param size      The size of the array.
 */
void randomArray(int *intArray, int size)
{
    srand(time(0));
    for (int i = 0; i < size; i++)
    {
        intArray[i] = (rand() % (100));
    }
}

/**
 * @brief Print all values in integer's array.
 * 
 * @param intArray  The integer's array.
 * @param size      The size of the array.
 */
void intArrayPrint(int *intArray, int size)
{
    for (int i = 0; i < size; i++)
    {
        printf(" %d", intArray[i]);
    }
    printf("\n");
}

/**
 * @brief Sorts int values.
 * Algorithm: Bubble Sort.
 * 
 * @param intArray  The integer's array.
 * @param size      The size of the array.
 */
void arraySort(int *intArray, int size)
{
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size - 1; j++)
        {
            if (intArray[j] > intArray[j + 1])
            {
                int aux = intArray[j];
                intArray[j] = intArray[j + 1];
                intArray[j + 1] = aux;
            }
        }
    }
}

/**
 * @brief binary Search Algorithm.
 * 
 * @param val   integer to search
 * @param arr   ordered (ascending) array of integers.
 * @param start start index for arr, natural number.
 * @param end   end index for arr, natural number.
 * @return int  arr index of 'val'; -1 if not found - integer.
 */
int orderedBinarySearch(int val, int *arr, int start, int end)
{
    int mid = (start + end) / 2;
    if (start > end) //caso base 1
    {
        return -1;
    }
    else if (arr[mid] == val) //caso base 2
    {
        return mid;
    }
    else if (arr[mid] > val)
    {
        orderedBinarySearch(val, arr, start, mid - 1);
    }
    else
    {
        orderedBinarySearch(val, arr, mid + 1, end);
    }
}