var main__4__5_8c =
[
    [ "ELEMENTS", "main__4__5_8c.html#a7feab374ee9fd4141cb5be6fe4339a7f", null ],
    [ "main", "main__4__5_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "stockRecursiveBinarySearch", "main__4__5_8c.html#aad31afa940d275bcda6fd3db2301e76d", null ]
];