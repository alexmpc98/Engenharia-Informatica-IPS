var searchData=
[
  ['stock',['stock',['../structstock.html',1,'stock'],['../stock_8h.html#a31150008419cf61979226a54c5d93076',1,'Stock():&#160;stock.h']]],
  ['stock_2ec',['stock.c',['../stock_8c.html',1,'']]],
  ['stock_2eh',['stock.h',['../stock_8h.html',1,'']]],
  ['stockarrayprint',['stockArrayPrint',['../stock_8c.html#abfa4c9e91a4be88838e3d4ce5a091ad7',1,'stockArrayPrint(Stock *stockArr, int size):&#160;stock.c'],['../stock_8h.html#abfa4c9e91a4be88838e3d4ce5a091ad7',1,'stockArrayPrint(Stock *stockArr, int size):&#160;stock.c']]],
  ['stockcreate',['stockCreate',['../stock_8c.html#a368de37ad329ee3868369eb34648fe29',1,'stockCreate(char *designation, int reference, float price, int quantity):&#160;stock.c'],['../stock_8h.html#a368de37ad329ee3868369eb34648fe29',1,'stockCreate(char *designation, int reference, float price, int quantity):&#160;stock.c']]],
  ['stockiterativebinarysearch',['stockIterativeBinarySearch',['../main5_8c.html#a10979e0358a25ad5f4db8fed2cc304b4',1,'main5.c']]],
  ['stockprint',['stockPrint',['../stock_8c.html#ac1a62f3305c4b1360a93ac5e5ab071ac',1,'stockPrint(Stock s):&#160;stock.c'],['../stock_8h.html#ac1a62f3305c4b1360a93ac5e5ab071ac',1,'stockPrint(Stock s):&#160;stock.c']]]
];
