var structproduct =
[
    [ "designation", "structproduct.html#aac7b88b607cdcd5e677c28e28a0c2e89", null ],
    [ "price", "structproduct.html#a115266f23f93c7cf56bb27ee6bffb5f3", null ],
    [ "reference", "structproduct.html#a128bb2f63c89213d08c2bd36adab1655", null ]
];