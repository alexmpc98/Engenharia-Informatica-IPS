var searchData=
[
  ['designation',['designation',['../structproduct.html#aac7b88b607cdcd5e677c28e28a0c2e89',1,'product']]]
];
