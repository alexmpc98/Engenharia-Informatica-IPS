var stock_8h =
[
    [ "product", "structproduct.html", "structproduct" ],
    [ "stock", "structstock.html", "structstock" ],
    [ "Product", "stock_8h.html#a15cd8fa329a12865d9fee02614ede4bf", null ],
    [ "Stock", "stock_8h.html#a31150008419cf61979226a54c5d93076", null ],
    [ "stockArrayPrint", "stock_8h.html#abfa4c9e91a4be88838e3d4ce5a091ad7", null ],
    [ "stockCreate", "stock_8h.html#a368de37ad329ee3868369eb34648fe29", null ],
    [ "stockPrint", "stock_8h.html#ac1a62f3305c4b1360a93ac5e5ab071ac", null ]
];