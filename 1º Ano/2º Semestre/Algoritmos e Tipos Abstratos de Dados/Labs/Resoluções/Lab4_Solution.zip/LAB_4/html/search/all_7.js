var searchData=
[
  ['quantity',['quantity',['../structstock.html#a5c4869d112feca36272c1899cbf03a3f',1,'stock']]]
];
