var searchData=
[
  ['price',['price',['../structproduct.html#a115266f23f93c7cf56bb27ee6bffb5f3',1,'product']]],
  ['product',['product',['../structstock.html#abb671b80c0fcfa6f23934fe0e0d4bf39',1,'stock']]]
];
