var annotated_dup =
[
    [ "product", "structproduct.html", "structproduct" ],
    [ "stock", "structstock.html", "structstock" ]
];