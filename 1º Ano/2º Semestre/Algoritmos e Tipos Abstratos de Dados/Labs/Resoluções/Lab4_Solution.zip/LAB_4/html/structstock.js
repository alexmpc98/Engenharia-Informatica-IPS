var structstock =
[
    [ "product", "structstock.html#abb671b80c0fcfa6f23934fe0e0d4bf39", null ],
    [ "quantity", "structstock.html#a5c4869d112feca36272c1899cbf03a3f", null ]
];