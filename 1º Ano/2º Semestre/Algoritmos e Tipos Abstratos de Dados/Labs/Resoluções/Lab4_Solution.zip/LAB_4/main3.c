/**
 * @file main_3.c
 * @author João Capinha
 */
#include <stdio.h>
#include <stdlib.h>

int intIterativeBinarySearch(int val, char *arr, int start, int end);

int main()
{
    // Nivel 3
    char alphabet[26] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
    
    int index = intIterativeBinarySearch('r', alphabet, 0, 26);
    (index != -1) ? printf("\nLetra '%c' encontrada na posição %d do alfabeto\n", 'r', index+1) : printf("\nValor não encontrado no vetor");

    return EXIT_SUCCESS;
}

/**
 * @brief binary Search Algorithm.
 * 
 * @param val   integer to search.
 * @param arr   ordered (ascending) array of chars.
 * @param start start index for arr, natural number.
 * @param end   end index for arr, natural number.
 * @return int  arr index of 'val'; -1 if not found - integer.
 */
int intIterativeBinarySearch(int val, char *arr, int start, int end)
{
    int mid;
    while (start <= end)
    {
        mid = (start + end) / 2;
        if (arr[mid] == val)
        {
            return mid;
        }
        else if (arr[mid] > val)
        {
            end = mid - 1;
        }
        else
        {
            start = mid + 1;
        }
    }
    return -1;
}