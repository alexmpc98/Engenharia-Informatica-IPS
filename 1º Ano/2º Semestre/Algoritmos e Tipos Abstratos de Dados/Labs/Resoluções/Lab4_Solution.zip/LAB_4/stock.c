/**
 * @file stock.c
 * @author Joao Capinha
 */
#include <stdio.h>
#include <string.h>

#include "stock.h"

Stock stockCreate(char *designation, int reference, float price, int quantity)
{
    Product p;
    p.reference = reference;
    p.price = price;
    strcpy(p.designation, designation);
    Stock s;
    s.product = p;
    s.quantity = quantity;
    return s;
}

/**
 * @brief Print information about a specific stock.
 * 
 * The format is "Product[designation] - ref: [reference] - price: [price]€ ], qtt: [quantity]".
 * 
 * @param s The stock to be printed.
 */
void stockPrint(Stock s)
{
    printf("Product[ %-15s - ref: %9d - price: %04.2f€ ], qtt: %2d\n", s.product.designation, s.product.reference, s.product.price, s.quantity);
}

/**
 * @brief Print all stock in stock's array.
 * 
 * @param stockArr  The stock's array.
 * @param size      The size of the array.
 */
void stockArrayPrint(Stock *stockArr, int size)
{
    printf("\nAll products in stock:\n");
    for (int i = 0; i < size; i++)
    {
        printf("\t");
        stockPrint(stockArr[i]);
    }
}