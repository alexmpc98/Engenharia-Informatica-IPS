/**
 * @file main.c
 * @author João Capinha
 */
#include <stdio.h>
#include <stdlib.h>

#include "stock.h"
#define ELEMENTS 10

int stockIterativeBinarySearch(int val, Stock *arr, int start, int end);

int main()
{
    // Nivel 4
    Stock stock[ELEMENTS] = {stockCreate("Cerveja", 112348654, 0.90, 30),
                             stockCreate("Cafe", 126789345, 0.40, 25),
                             stockCreate("Agua", 306982361, 0.50, 52),
                             stockCreate("Limonada", 401872229, 1.50, 3),
                             stockCreate("Cha", 500034544, 0.90, 1),
                             stockCreate("Vinho", 521222345, 1.30, 16),
                             stockCreate("Sumo laranja", 603481993, 2.10, 14),
                             stockCreate("Leite", 706787878, 0.60, 8),
                             stockCreate("Galao", 800045663, 0.85, 15),
                             stockCreate("Agua com gas", 910226773, 1.65, 22)};
    stockArrayPrint(stock, ELEMENTS);

    // Nivel 5
    int refSearch = 603481993;
    int index = stockIterativeBinarySearch(refSearch, stock, 0, ELEMENTS);
    (index != -1) ? printf("\nProduto com referência %d encontrado em stock\n\t- Existem disponiveis %d unidades\n", refSearch, stock[index].quantity) : printf("\nProduto não encontrado em stock");

    return EXIT_SUCCESS;
}

/**
 * @brief binary Search Algorithm. Search reference in stock's array
 * 
 * @param val   integer to search
 * @param arr   ordered (ascending) array of stock.
 * @param start start index for arr, natural number.
 * @param end   end index for arr, natural number.
 * @return int  arr index of 'val'; -1 if not found - integer.
 */
int stockIterativeBinarySearch(int val, Stock *arr, int start, int end)
{
    int mid;
    while (start <= end)
    {
        mid = (start + end) / 2;
        if (arr[mid].product.reference == val)
        {
            return mid;
        }
        else if (arr[mid].product.reference > val)
        {
            end = mid - 1;
        }
        else
        {
            start = mid + 1;
        }
    }
    return -1;
}