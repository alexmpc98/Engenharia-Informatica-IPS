/**
 * @file main.c
 * @author João Capinha
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define ELEMENTS 10
//Nivel 1
void randomArray(int *intArray, int size);
void intArrayPrint(int *intArray, int size);
void arraySort(int *intArray, int size);

int main()
{
    //Nivel 1
    int intArray[ELEMENTS];
    printf("Vetor gerado aleatoriamente:\n");
    randomArray(intArray, ELEMENTS);
    intArrayPrint(intArray, ELEMENTS);

    printf("\nVetor ordenado de forma crescente:\n");
    arraySort(intArray, ELEMENTS);
    intArrayPrint(intArray, ELEMENTS);

    return EXIT_SUCCESS;
}

/**
 * @brief Generate random value in [0,99] for all positions array.
 * 
 * @param intArray  The integer's array.
 * @param size      The size of the array.
 */
void randomArray(int *intArray, int size)
{
    srand(time(0));
    for (int i = 0; i < size; i++)
    {
        intArray[i] = (rand() % (100));
    }
}

/**
 * @brief Print all values in integer's array.
 * 
 * @param intArray  The integer's array.
 * @param size      The size of the array.
 */
void intArrayPrint(int *intArray, int size)
{
    for (int i = 0; i < size; i++)
    {
        printf(" %d", intArray[i]);
    }
    printf("\n");
}

/**
 * @brief Sorts int values.
 * Algorithm: Bubble Sort.
 * 
 * @param intArray  The integer's array.
 * @param size      The size of the array.
 */
void arraySort(int *intArray, int size)
{
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size - 1; j++)
        {
            if (intArray[j] > intArray[j + 1])
            {
                int aux = intArray[j];
                intArray[j] = intArray[j + 1];
                intArray[j + 1] = aux;
            }
        }
    }
}