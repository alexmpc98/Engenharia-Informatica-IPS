/**
 * @file main.c
 * @author João Capinha
 */
#include <stdio.h>
#include <stdlib.h>

#include "stock.h"
#define ELEMENTS 10

int main()
{
    // Nivel 4
    Stock stock[ELEMENTS] = {stockCreate("Cerveja", 112348654, 0.90, 30),
                             stockCreate("Cafe", 126789345, 0.40, 25),
                             stockCreate("Agua", 306982361, 0.50, 52),
                             stockCreate("Limonada", 401872229, 1.50, 3),
                             stockCreate("Cha", 500034544, 0.90, 1),
                             stockCreate("Vinho", 521222345, 1.30, 16),
                             stockCreate("Sumo laranja", 603481993, 2.10, 14),
                             stockCreate("Leite", 706787878, 0.60, 8),
                             stockCreate("Galao", 800045663, 0.85, 15),
                             stockCreate("Agua com gas", 910226773, 1.65, 22)};
    stockArrayPrint(stock, ELEMENTS);

    return EXIT_SUCCESS;
}