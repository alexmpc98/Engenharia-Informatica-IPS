#pragma once

/**
 * @brief Definition of type struct product. Represents a Product.
 * 
 */
typedef struct product
{
    char designation[20];
    int reference;
    float price;
} Product;

/**
 * @brief Definition of type struct stock. Represents a Product's stock.
 * 
 */
typedef struct stock
{
    Product product;
    int quantity;
} Stock;

Stock stockCreate(char *designation, int reference, float price, int quantity);

/**
 * @brief Print information about a specific stock.
 * 
 * The format is "Product[designation] - ref: [reference] - price: [price]€ ], qtt: [quantity]".
 * 
 * @param s The stock to be printed.
 */
void stockPrint(Stock s);

/**
 * @brief Print all stock in stock's array.
 * 
 * @param stockArr  The stock's array.
 * @param size      The size of the array.
 */
void stockArrayPrint(Stock *stockArr, int size);