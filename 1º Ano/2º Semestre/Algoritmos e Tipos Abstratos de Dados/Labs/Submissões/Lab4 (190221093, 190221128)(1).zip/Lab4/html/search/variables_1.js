var searchData=
[
  ['price',['price',['../structProduct.html#ad1fd6ee6c8653bf81898668b1d01b05d',1,'Product']]],
  ['product',['product',['../structStock.html#a4d85df3f8acc414e3cd5d89626ce8953',1,'Stock']]]
];
