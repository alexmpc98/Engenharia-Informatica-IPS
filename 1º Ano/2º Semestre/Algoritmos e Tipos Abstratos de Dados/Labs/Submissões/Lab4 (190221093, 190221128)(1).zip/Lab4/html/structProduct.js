var structProduct =
[
    [ "designation", "structProduct.html#aa8b69cec81eb9f28a9a1b36b39ed582e", null ],
    [ "price", "structProduct.html#ad1fd6ee6c8653bf81898668b1d01b05d", null ],
    [ "reference", "structProduct.html#abe7b7387b699062b4ac9b7123f18ae70", null ]
];