var annotated_dup =
[
    [ "Product", "structProduct.html", "structProduct" ],
    [ "Stock", "structStock.html", "structStock" ]
];