var structStock =
[
    [ "product", "structStock.html#a4d85df3f8acc414e3cd5d89626ce8953", null ],
    [ "quantity", "structStock.html#ae8cab0798008c85852ce3d66f061f30a", null ]
];