var files =
[
    [ "main1.c", "main1_8c.html", "main1_8c" ],
    [ "main2.c", "main2_8c.html", "main2_8c" ],
    [ "main3.c", "main3_8c.html", "main3_8c" ],
    [ "main4.c", "main4_8c.html", "main4_8c" ],
    [ "main5.c", "main5_8c.html", "main5_8c" ],
    [ "stock.c", "stock_8c.html", "stock_8c" ],
    [ "stock.h", "stock_8h.html", "stock_8h" ]
];