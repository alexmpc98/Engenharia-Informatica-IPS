var indexSectionsWithContent =
{
  0: "abdimopqrs",
  1: "ps",
  2: "ms",
  3: "abimors",
  4: "dpqr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

