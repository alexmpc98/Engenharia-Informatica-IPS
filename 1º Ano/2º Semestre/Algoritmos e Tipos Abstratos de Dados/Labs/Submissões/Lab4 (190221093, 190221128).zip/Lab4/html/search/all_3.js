var searchData=
[
  ['intarrayprint',['intArrayPrint',['../main1_8c.html#ae7149ad020619c32653c97f7a25d259b',1,'intArrayPrint(int *intArray, int size):&#160;main1.c'],['../main2_8c.html#ae7149ad020619c32653c97f7a25d259b',1,'intArrayPrint(int *intArray, int size):&#160;main2.c']]]
];
