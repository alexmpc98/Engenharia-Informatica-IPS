var searchData=
[
  ['stockarrayprint',['stockArrayPrint',['../stock_8c.html#abfa4c9e91a4be88838e3d4ce5a091ad7',1,'stockArrayPrint(Stock *stockArr, int size):&#160;stock.c'],['../stock_8h.html#abfa4c9e91a4be88838e3d4ce5a091ad7',1,'stockArrayPrint(Stock *stockArr, int size):&#160;stock.c']]],
  ['stockcreate',['stockCreate',['../stock_8c.html#a368de37ad329ee3868369eb34648fe29',1,'stockCreate(char *designation, int reference, float price, int quantity):&#160;stock.c'],['../stock_8h.html#a368de37ad329ee3868369eb34648fe29',1,'stockCreate(char *designation, int reference, float price, int quantity):&#160;stock.c']]],
  ['stockprint',['stockPrint',['../stock_8c.html#ac1a62f3305c4b1360a93ac5e5ab071ac',1,'stockPrint(Stock s):&#160;stock.c'],['../stock_8h.html#ac1a62f3305c4b1360a93ac5e5ab071ac',1,'stockPrint(Stock s):&#160;stock.c']]]
];
