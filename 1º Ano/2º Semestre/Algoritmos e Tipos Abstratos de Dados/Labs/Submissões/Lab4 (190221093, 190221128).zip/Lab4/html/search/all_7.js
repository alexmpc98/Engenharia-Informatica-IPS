var searchData=
[
  ['quantity',['quantity',['../structStock.html#ae8cab0798008c85852ce3d66f061f30a',1,'Stock']]]
];
