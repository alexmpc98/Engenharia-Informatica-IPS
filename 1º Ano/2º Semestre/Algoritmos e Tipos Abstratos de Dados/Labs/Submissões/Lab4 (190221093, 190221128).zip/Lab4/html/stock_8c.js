var stock_8c =
[
    [ "stockArrayPrint", "stock_8c.html#abfa4c9e91a4be88838e3d4ce5a091ad7", null ],
    [ "stockCreate", "stock_8c.html#a368de37ad329ee3868369eb34648fe29", null ],
    [ "stockPrint", "stock_8c.html#ac1a62f3305c4b1360a93ac5e5ab071ac", null ]
];