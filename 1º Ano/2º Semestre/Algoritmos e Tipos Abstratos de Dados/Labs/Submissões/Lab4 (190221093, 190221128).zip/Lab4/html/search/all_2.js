var searchData=
[
  ['designation',['designation',['../structProduct.html#aa8b69cec81eb9f28a9a1b36b39ed582e',1,'Product']]]
];
