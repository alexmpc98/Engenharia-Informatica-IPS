var stock_8h =
[
    [ "Product", "structProduct.html", "structProduct" ],
    [ "Stock", "structStock.html", "structStock" ],
    [ "stockArrayPrint", "stock_8h.html#abfa4c9e91a4be88838e3d4ce5a091ad7", null ],
    [ "stockCreate", "stock_8h.html#a368de37ad329ee3868369eb34648fe29", null ],
    [ "stockPrint", "stock_8h.html#ac1a62f3305c4b1360a93ac5e5ab071ac", null ]
];