var searchData=
[
  ['size',['size',['../structqueueImpl.html#a8b3286de1bef58f2c551d77257ff25d9',1,'queueImpl::size()'],['../structstackImpl.html#a11e47c570512de8a5b32531ffce1a266',1,'stackImpl::size()']]]
];
