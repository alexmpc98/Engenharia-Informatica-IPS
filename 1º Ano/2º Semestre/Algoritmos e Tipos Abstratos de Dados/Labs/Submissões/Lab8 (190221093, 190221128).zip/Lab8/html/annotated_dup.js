var annotated_dup =
[
    [ "node", "structnode.html", "structnode" ],
    [ "queueImpl", "structqueueImpl.html", "structqueueImpl" ],
    [ "stackImpl", "structstackImpl.html", "structstackImpl" ]
];