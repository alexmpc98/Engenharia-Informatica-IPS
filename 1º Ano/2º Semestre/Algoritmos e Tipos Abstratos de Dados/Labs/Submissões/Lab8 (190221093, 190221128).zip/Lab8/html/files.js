var files =
[
    [ "main3.c", "main3_8c.html", "main3_8c" ],
    [ "main4.c", "main4_8c.html", "main4_8c" ],
    [ "main5.c", "main5_8c.html", "main5_8c" ],
    [ "queue.h", "queue_8h.html", "queue_8h" ],
    [ "queueArrayList.c", "queueArrayList_8c.html", "queueArrayList_8c" ],
    [ "queueElem.c", "queueElem_8c.html", "queueElem_8c" ],
    [ "queueElem.h", "queueElem_8h.html", "queueElem_8h" ],
    [ "queueLinkedList.c", "queueLinkedList_8c.html", "queueLinkedList_8c" ],
    [ "stack.h", "stack_8h.html", "stack_8h" ],
    [ "stackArrayList.c", "stackArrayList_8c.html", "stackArrayList_8c" ],
    [ "stackElem.c", "stackElem_8c.html", "stackElem_8c" ],
    [ "stackElem.h", "stackElem_8h.html", "stackElem_8h" ],
    [ "stackLinkedList.c", "stackLinkedList_8c.html", "stackLinkedList_8c" ]
];