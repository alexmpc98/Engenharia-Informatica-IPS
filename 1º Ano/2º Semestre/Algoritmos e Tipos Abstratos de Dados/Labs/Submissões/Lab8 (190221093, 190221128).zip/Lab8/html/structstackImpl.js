var structstackImpl =
[
    [ "capacity", "structstackImpl.html#ac1c66a7e449093279040155cc5097fae", null ],
    [ "elements", "structstackImpl.html#ae0d60678fb421c0d3179cc5babd16e49", null ],
    [ "header", "structstackImpl.html#a190df7e697de8c62cbc0dfe33afd5ba7", null ],
    [ "size", "structstackImpl.html#a11e47c570512de8a5b32531ffce1a266", null ],
    [ "trailer", "structstackImpl.html#a3f618fd86a2c41eb3d6b272763c04023", null ]
];