var searchData=
[
  ['node',['Node',['../queueLinkedList_8c.html#aba087cc5af103c72c4e5864cc5622196',1,'Node():&#160;queueLinkedList.c'],['../stackLinkedList_8c.html#aba087cc5af103c72c4e5864cc5622196',1,'Node():&#160;stackLinkedList.c']]]
];
