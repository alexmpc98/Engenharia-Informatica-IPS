var structnode =
[
    [ "element", "structnode.html#a737410ace5133fa67140e01881320f61", null ],
    [ "element", "structnode.html#a13b1a1146103f1227d8c2e72a7e91e56", null ],
    [ "next", "structnode.html#a3b6e2d9364cf6b0c1559d67c4a26d737", null ],
    [ "prev", "structnode.html#ae4cdd22c9dcfb8158262ab2519dc43b4", null ]
];