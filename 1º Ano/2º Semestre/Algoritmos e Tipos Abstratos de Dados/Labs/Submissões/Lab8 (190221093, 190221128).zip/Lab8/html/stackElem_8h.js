var stackElem_8h =
[
    [ "StackElem", "stackElem_8h.html#adaeea3d5d50845f8145949ca9bde2a21", null ],
    [ "stackElemPrint", "stackElem_8h.html#a7c3b3cc33b0896e4b0dea95af6cfe7c7", null ]
];