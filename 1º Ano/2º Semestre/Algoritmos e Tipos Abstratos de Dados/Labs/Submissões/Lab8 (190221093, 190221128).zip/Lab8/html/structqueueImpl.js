var structqueueImpl =
[
    [ "capacity", "structqueueImpl.html#a454546655921e06e0a1a98a294cb0665", null ],
    [ "elements", "structqueueImpl.html#a97915cd3539c1788fb2be8613cc61f73", null ],
    [ "header", "structqueueImpl.html#ac519c0266826556397d14d9b686fae19", null ],
    [ "size", "structqueueImpl.html#a8b3286de1bef58f2c551d77257ff25d9", null ],
    [ "trailer", "structqueueImpl.html#a279451f7ce71e82d7a096cd683c7370b", null ]
];