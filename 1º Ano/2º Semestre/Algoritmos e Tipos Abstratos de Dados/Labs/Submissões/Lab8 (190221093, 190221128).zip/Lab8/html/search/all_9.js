var searchData=
[
  ['trailer',['trailer',['../structqueueImpl.html#a279451f7ce71e82d7a096cd683c7370b',1,'queueImpl::trailer()'],['../structstackImpl.html#a3f618fd86a2c41eb3d6b272763c04023',1,'stackImpl::trailer()']]]
];
