var searchData=
[
  ['stackimpl',['stackImpl',['../structstackImpl.html',1,'']]]
];
