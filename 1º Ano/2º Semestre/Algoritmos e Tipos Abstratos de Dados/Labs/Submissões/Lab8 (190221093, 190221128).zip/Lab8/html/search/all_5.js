var searchData=
[
  ['next',['next',['../structnode.html#a3b6e2d9364cf6b0c1559d67c4a26d737',1,'node']]],
  ['node',['node',['../structnode.html',1,'node'],['../queueLinkedList_8c.html#aba087cc5af103c72c4e5864cc5622196',1,'Node():&#160;queueLinkedList.c'],['../stackLinkedList_8c.html#aba087cc5af103c72c4e5864cc5622196',1,'Node():&#160;stackLinkedList.c']]]
];
