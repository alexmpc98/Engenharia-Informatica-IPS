var searchData=
[
  ['stackelem',['StackElem',['../stackElem_8h.html#adaeea3d5d50845f8145949ca9bde2a21',1,'stackElem.h']]],
  ['stackimpl',['StackImpl',['../stackArrayList_8c.html#a852cbceb4a86fe509f5b95de4b6b8a77',1,'StackImpl():&#160;stackArrayList.c'],['../stackLinkedList_8c.html#a852cbceb4a86fe509f5b95de4b6b8a77',1,'StackImpl():&#160;stackLinkedList.c']]]
];
