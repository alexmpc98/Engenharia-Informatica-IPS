var searchData=
[
  ['header',['header',['../structqueueImpl.html#ac519c0266826556397d14d9b686fae19',1,'queueImpl::header()'],['../structstackImpl.html#a190df7e697de8c62cbc0dfe33afd5ba7',1,'stackImpl::header()']]]
];
