var searchData=
[
  ['capacity',['capacity',['../structqueueImpl.html#a454546655921e06e0a1a98a294cb0665',1,'queueImpl::capacity()'],['../structstackImpl.html#ac1c66a7e449093279040155cc5097fae',1,'stackImpl::capacity()']]]
];
