var searchData=
[
  ['posfix_5fnotation_2etxt',['posfix_notation.txt',['../posfix__notation_8txt.html',1,'']]],
  ['prefix_5fnotation_2etxt',['prefix_notation.txt',['../prefix__notation_8txt.html',1,'']]],
  ['prev',['prev',['../structnode.html#ae4cdd22c9dcfb8158262ab2519dc43b4',1,'node']]],
  ['ptnode',['PtNode',['../queueLinkedList_8c.html#afa9af1c2482b2c375481b34358a79c58',1,'PtNode():&#160;queueLinkedList.c'],['../stackLinkedList_8c.html#afa9af1c2482b2c375481b34358a79c58',1,'PtNode():&#160;stackLinkedList.c']]],
  ['ptqueue',['PtQueue',['../queue_8h.html#a2b3e630355bd2793ace14b451f8e1a4a',1,'queue.h']]],
  ['ptstack',['PtStack',['../stack_8h.html#a70fd0117d0ab4a0d6e5d337bc13fa37c',1,'stack.h']]]
];
