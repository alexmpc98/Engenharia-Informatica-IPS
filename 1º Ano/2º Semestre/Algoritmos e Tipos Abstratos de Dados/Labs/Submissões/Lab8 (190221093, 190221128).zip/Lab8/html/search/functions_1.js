var searchData=
[
  ['evaluatepostfixexpression',['evaluatePostfixExpression',['../main3_8c.html#a1463f78ba4ff01db80beb4bc28a5c2ee',1,'evaluatePostfixExpression(char *expression, int *result):&#160;main3.c'],['../main5_8c.html#a1463f78ba4ff01db80beb4bc28a5c2ee',1,'evaluatePostfixExpression(char *expression, int *result):&#160;main5.c']]]
];
