var stackElem_8c =
[
    [ "stackElemPrint", "stackElem_8c.html#a7c3b3cc33b0896e4b0dea95af6cfe7c7", null ]
];