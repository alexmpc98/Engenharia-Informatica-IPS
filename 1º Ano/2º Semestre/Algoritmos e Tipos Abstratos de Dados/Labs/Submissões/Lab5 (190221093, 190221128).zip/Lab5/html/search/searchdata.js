var indexSectionsWithContent =
{
  0: "afmnps",
  1: "a",
  2: "m",
  3: "fm",
  4: "ns",
  5: "ap"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs"
};

