var structarray =
[
    [ "numbers", "structarray.html#a0cf57cbacd52123bae32459f1ffd6a1e", null ],
    [ "size", "structarray.html#ad825291dd9ac471f4d79ed83238d80b2", null ]
];