var searchData=
[
  ['algorithm',['Algorithm',['../pseudocode_8txt.html#a273a777a587a735c66efbfdebce10d91',1,'pseudocode.txt']]],
  ['array',['array',['../pseudocode_8txt.html#a6bf0b1ba9fc7d79df1bfac0fadd42e39',1,'pseudocode.txt']]]
];
