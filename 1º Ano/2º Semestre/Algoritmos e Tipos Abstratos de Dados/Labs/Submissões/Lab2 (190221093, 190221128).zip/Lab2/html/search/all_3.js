var searchData=
[
  ['lineares',['lineares',['../pseudocode_8txt.html#a07ec118f68d77c11d6e31fb68bedda37',1,'pseudocode.txt']]]
];
