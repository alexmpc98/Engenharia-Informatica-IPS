var vector_8c =
[
    [ "existOrthogonals", "vector_8c.html#a49fed5da93753d896dbc5df413e2f357", null ],
    [ "vectorCreate", "vector_8c.html#ad46f42ec6c1ac10d858681d5a364a6fa", null ],
    [ "vectorDotProduct", "vector_8c.html#adb367586a5f1c199ac8e60c2cdbeaa2b", null ],
    [ "vectorLength", "vector_8c.html#a591677feeb85cb5a84dd9008b8cf901c", null ],
    [ "vectorPrint", "vector_8c.html#a545adad6b489528840c6a11131f8d658", null ]
];