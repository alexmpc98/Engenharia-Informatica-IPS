var structVector =
[
    [ "x", "structVector.html#a6bd76336af82fac1ba5c3e0b5e4060df", null ],
    [ "y", "structVector.html#a23dd3816f60a6c3bc9af4971088eb2fd", null ]
];