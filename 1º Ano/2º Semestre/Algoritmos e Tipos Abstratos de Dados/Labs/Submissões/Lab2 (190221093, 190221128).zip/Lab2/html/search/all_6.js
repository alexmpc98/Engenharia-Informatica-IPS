var searchData=
[
  ['pseudocode_2etxt',['pseudocode.txt',['../pseudocode_8txt.html',1,'']]]
];
