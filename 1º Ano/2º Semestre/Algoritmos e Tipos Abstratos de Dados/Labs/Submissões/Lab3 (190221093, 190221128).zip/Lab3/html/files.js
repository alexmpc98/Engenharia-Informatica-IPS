var files =
[
    [ "grade.c", "grade_8c.html", "grade_8c" ],
    [ "grade.h", "grade_8h.html", "grade_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "student.c", "student_8c.html", "student_8c" ],
    [ "student.h", "student_8h.html", "student_8h" ]
];