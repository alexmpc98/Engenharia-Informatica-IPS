var searchData=
[
  ['approvation',['approvation',['../grade_8c.html#a5b1ba8ff2456b1d2968fd5de36af03eb',1,'approvation(float result):&#160;grade.c'],['../grade_8h.html#a5b1ba8ff2456b1d2968fd5de36af03eb',1,'approvation(float result):&#160;grade.c']]]
];
