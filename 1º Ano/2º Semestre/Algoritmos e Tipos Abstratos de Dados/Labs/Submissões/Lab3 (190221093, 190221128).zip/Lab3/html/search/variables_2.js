var searchData=
[
  ['student',['student',['../structGrade.html#a3b70b05c7ee0deb92b5d89dbb50d8453',1,'Grade']]],
  ['studentnumber',['studentNumber',['../structStudent.html#a07ed4c2ff7e988a0146263bf6e94adf7',1,'Student']]]
];
