var searchData=
[
  ['studentcreate',['studentCreate',['../student_8c.html#aca896f97995ef6ff95f7cbec4f5c72d4',1,'studentCreate(int number, char *name):&#160;student.c'],['../student_8h.html#aca896f97995ef6ff95f7cbec4f5c72d4',1,'studentCreate(int number, char *name):&#160;student.c']]]
];
