var structStudent =
[
    [ "name", "structStudent.html#a7bff7ff985757c54c997bd970bbb63c8", null ],
    [ "studentNumber", "structStudent.html#a07ed4c2ff7e988a0146263bf6e94adf7", null ]
];