var searchData=
[
  ['result',['result',['../structGrade.html#a954eada72e28ced7ffd85d857fecefe6',1,'Grade']]]
];
