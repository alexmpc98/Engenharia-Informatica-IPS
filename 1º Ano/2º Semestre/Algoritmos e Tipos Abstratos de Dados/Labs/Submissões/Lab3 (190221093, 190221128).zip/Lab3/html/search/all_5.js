var searchData=
[
  ['student',['Student',['../structStudent.html',1,'Student'],['../structGrade.html#a3b70b05c7ee0deb92b5d89dbb50d8453',1,'Grade::student()']]],
  ['student_2ec',['student.c',['../student_8c.html',1,'']]],
  ['student_2eh',['student.h',['../student_8h.html',1,'']]],
  ['studentcreate',['studentCreate',['../student_8c.html#aca896f97995ef6ff95f7cbec4f5c72d4',1,'studentCreate(int number, char *name):&#160;student.c'],['../student_8h.html#aca896f97995ef6ff95f7cbec4f5c72d4',1,'studentCreate(int number, char *name):&#160;student.c']]],
  ['studentnumber',['studentNumber',['../structStudent.html#a07ed4c2ff7e988a0146263bf6e94adf7',1,'Student']]]
];
