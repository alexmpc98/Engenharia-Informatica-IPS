var searchData=
[
  ['name',['name',['../structStudent.html#a7bff7ff985757c54c997bd970bbb63c8',1,'Student']]]
];
