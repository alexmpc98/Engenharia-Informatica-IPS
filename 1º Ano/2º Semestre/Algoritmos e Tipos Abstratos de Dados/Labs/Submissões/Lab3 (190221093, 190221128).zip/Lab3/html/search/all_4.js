var searchData=
[
  ['result',['result',['../structGrade.html#a954eada72e28ced7ffd85d857fecefe6',1,'Grade']]],
  ['resultexists',['resultExists',['../grade_8c.html#a017756b455cb8c31a27c99127fd6d89c',1,'resultExists(Grade *gradeArr, int size, float value):&#160;grade.c'],['../grade_8h.html#a017756b455cb8c31a27c99127fd6d89c',1,'resultExists(Grade *gradeArr, int size, float value):&#160;grade.c']]]
];
