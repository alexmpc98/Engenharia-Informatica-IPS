var structGrade =
[
    [ "result", "structGrade.html#a954eada72e28ced7ffd85d857fecefe6", null ],
    [ "student", "structGrade.html#a3b70b05c7ee0deb92b5d89dbb50d8453", null ]
];