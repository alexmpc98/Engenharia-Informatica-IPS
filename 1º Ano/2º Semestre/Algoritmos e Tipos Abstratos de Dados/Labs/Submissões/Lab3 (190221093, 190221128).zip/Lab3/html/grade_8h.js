var grade_8h =
[
    [ "Grade", "structGrade.html", "structGrade" ],
    [ "approvation", "grade_8h.html#a5b1ba8ff2456b1d2968fd5de36af03eb", null ],
    [ "getMajorGrade", "grade_8h.html#aefc3799c3fefd9624e7e28c4cfd862dc", null ],
    [ "getMinorGrade", "grade_8h.html#a91446c52f721a828c810adf8d197d669", null ],
    [ "getNumberApproved", "grade_8h.html#a3e22919fa19a3db8494b9b4f38c82feb", null ],
    [ "gradeArrayPrint", "grade_8h.html#ad49900bcc72d771e3a53a0a4ef3b459d", null ],
    [ "gradeArrayStats", "grade_8h.html#a9be0439a7fdee21a12ae6b16524fc2a1", null ],
    [ "gradeArrSortByNumber", "grade_8h.html#a272d6933d9bb47876a2f9b30310260e6", null ],
    [ "gradeArrSortByResult", "grade_8h.html#aa4196007816bc419cb4738c0ba905a07", null ],
    [ "gradeCreate", "grade_8h.html#acafbbfc8006d2e6367317a95b967f833", null ],
    [ "gradePrint", "grade_8h.html#a8e9a23346a8ac879b18c4a5962cc23e2", null ],
    [ "resultExists", "grade_8h.html#a017756b455cb8c31a27c99127fd6d89c", null ]
];