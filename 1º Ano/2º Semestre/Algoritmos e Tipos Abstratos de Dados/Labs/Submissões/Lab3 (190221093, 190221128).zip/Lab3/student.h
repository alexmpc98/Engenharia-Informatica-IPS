typedef struct {
     int studentNumber;
     char* name;
} Student;

Student studentCreate(int number, char* name);
