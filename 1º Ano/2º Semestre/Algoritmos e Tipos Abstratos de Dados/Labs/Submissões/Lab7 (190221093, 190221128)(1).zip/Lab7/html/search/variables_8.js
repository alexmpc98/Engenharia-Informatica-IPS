var searchData=
[
  ['total_5fscore',['total_score',['../structkahootReport.html#a2a24b841d40e7ae651c15869d75ca3fe',1,'kahootReport']]],
  ['trailer',['trailer',['../structlistImpl.html#a770086650ddb22546c1182b0a8d33ca3',1,'listImpl']]]
];
