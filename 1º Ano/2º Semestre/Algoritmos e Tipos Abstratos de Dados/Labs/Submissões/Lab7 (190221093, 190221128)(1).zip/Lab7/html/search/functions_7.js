var searchData=
[
  ['totalaveragescore',['totalAverageScore',['../main4_8c.html#a8b4a3d6c96b8fb5b642559d9d6c0c961',1,'main4.c']]]
];
