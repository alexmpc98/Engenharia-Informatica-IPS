var searchData=
[
  ['kahoot_2ec',['kahoot.c',['../kahoot_8c.html',1,'']]],
  ['kahoot_2eh',['kahoot.h',['../kahoot_8h.html',1,'']]],
  ['kahootreport',['kahootReport',['../structkahootReport.html',1,'kahootReport'],['../kahoot_8h.html#aaf6e7a53da1e60650a9a624cab1d5701',1,'KahootReport():&#160;kahoot.h']]],
  ['kahootreportcreate',['KahootReportCreate',['../kahoot_8c.html#a3f30600aea56ea7e6c912951460cff6e',1,'KahootReportCreate(int week, int rank, char nickname[50], int total_score, int correct_answers, int incorrect_answers):&#160;kahoot.c'],['../kahoot_8h.html#a3f30600aea56ea7e6c912951460cff6e',1,'KahootReportCreate(int week, int rank, char nickname[50], int total_score, int correct_answers, int incorrect_answers):&#160;kahoot.c']]],
  ['kahootreportprint',['KahootReportPrint',['../kahoot_8c.html#aa42fcc047e9d5c860e1fe08cebe88d9f',1,'KahootReportPrint(KahootReport kr):&#160;kahoot.c'],['../kahoot_8h.html#aa42fcc047e9d5c860e1fe08cebe88d9f',1,'KahootReportPrint(KahootReport kr):&#160;kahoot.c']]]
];
