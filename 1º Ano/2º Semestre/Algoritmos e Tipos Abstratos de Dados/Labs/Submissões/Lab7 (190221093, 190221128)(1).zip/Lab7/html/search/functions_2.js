var searchData=
[
  ['kahootreportcreate',['KahootReportCreate',['../kahoot_8c.html#a3f30600aea56ea7e6c912951460cff6e',1,'KahootReportCreate(int week, int rank, char nickname[50], int total_score, int correct_answers, int incorrect_answers):&#160;kahoot.c'],['../kahoot_8h.html#a3f30600aea56ea7e6c912951460cff6e',1,'KahootReportCreate(int week, int rank, char nickname[50], int total_score, int correct_answers, int incorrect_answers):&#160;kahoot.c']]],
  ['kahootreportprint',['KahootReportPrint',['../kahoot_8c.html#aa42fcc047e9d5c860e1fe08cebe88d9f',1,'KahootReportPrint(KahootReport kr):&#160;kahoot.c'],['../kahoot_8h.html#aa42fcc047e9d5c860e1fe08cebe88d9f',1,'KahootReportPrint(KahootReport kr):&#160;kahoot.c']]]
];
