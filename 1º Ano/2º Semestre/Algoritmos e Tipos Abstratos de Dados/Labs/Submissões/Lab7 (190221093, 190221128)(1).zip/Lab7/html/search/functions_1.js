var searchData=
[
  ['importkahootfromfile',['importKahootFromFile',['../utils_8c.html#aeaec0f666997c962c3950e22b817bf86',1,'importKahootFromFile(char *filename, PtList *listKR):&#160;utils.c'],['../utils_8h.html#aeaec0f666997c962c3950e22b817bf86',1,'importKahootFromFile(char *filename, PtList *listKR):&#160;utils.c']]]
];
