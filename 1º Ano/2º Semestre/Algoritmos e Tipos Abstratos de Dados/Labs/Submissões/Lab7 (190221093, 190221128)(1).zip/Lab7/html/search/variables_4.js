var searchData=
[
  ['next',['next',['../structnode.html#a3b6e2d9364cf6b0c1559d67c4a26d737',1,'node']]],
  ['nickname',['nickname',['../structkahootReport.html#a570c0be48093773c06efebe9712df373',1,'kahootReport']]]
];
