var structkahootReport =
[
    [ "correct_answers", "structkahootReport.html#a384996056a5db3c717fb55ec82454b87", null ],
    [ "incorrect_answers", "structkahootReport.html#abaeaf6b5ee01503c19a0d9058fa3fd40", null ],
    [ "nickname", "structkahootReport.html#a570c0be48093773c06efebe9712df373", null ],
    [ "rank", "structkahootReport.html#af78cd187c643065d03a5c3c2a0fba791", null ],
    [ "total_score", "structkahootReport.html#a2a24b841d40e7ae651c15869d75ca3fe", null ],
    [ "week", "structkahootReport.html#afbd2a3744320b4a015e18175dcfa1fbf", null ]
];