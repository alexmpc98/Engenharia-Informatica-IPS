var searchData=
[
  ['capacity',['capacity',['../structlistImpl.html#a9190d1fb912ff1290eee955654dd9117',1,'listImpl']]],
  ['correct_5fanswers',['correct_answers',['../structkahootReport.html#a384996056a5db3c717fb55ec82454b87',1,'kahootReport']]]
];
