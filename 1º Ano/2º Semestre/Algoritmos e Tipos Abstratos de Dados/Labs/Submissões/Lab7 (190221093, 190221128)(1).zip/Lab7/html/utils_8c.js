var utils_8c =
[
    [ "importKahootFromFile", "utils_8c.html#aeaec0f666997c962c3950e22b817bf86", null ],
    [ "sortByAlphabeticalOrder", "utils_8c.html#afe526e1011a413be1d4d89fc1cfbde76", null ],
    [ "sortByWeekAscendingOrder", "utils_8c.html#a1a1bf0bf186545dcb075c893e9b1740b", null ],
    [ "split", "utils_8c.html#ab383150b853d46993033b8f5cecf2073", null ]
];