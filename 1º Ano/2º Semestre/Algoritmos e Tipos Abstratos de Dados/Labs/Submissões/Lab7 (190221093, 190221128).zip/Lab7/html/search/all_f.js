var searchData=
[
  ['week',['week',['../structkahootReport.html#afbd2a3744320b4a015e18175dcfa1fbf',1,'kahootReport']]]
];
