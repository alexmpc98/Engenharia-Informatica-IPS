var kahoot_8h =
[
    [ "kahootReport", "structkahootReport.html", "structkahootReport" ],
    [ "KahootReport", "kahoot_8h.html#aaf6e7a53da1e60650a9a624cab1d5701", null ],
    [ "KahootReportCreate", "kahoot_8h.html#a3f30600aea56ea7e6c912951460cff6e", null ],
    [ "KahootReportPrint", "kahoot_8h.html#aa42fcc047e9d5c860e1fe08cebe88d9f", null ]
];