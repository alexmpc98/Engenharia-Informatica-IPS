var main4_8c =
[
    [ "getQuestions", "main4_8c.html#a240eee4545f16a438b848f2930712321", null ],
    [ "main", "main4_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "totalAverageScore", "main4_8c.html#a8b4a3d6c96b8fb5b642559d9d6c0c961", null ]
];