var searchData=
[
  ['prev',['prev',['../structnode.html#ae4cdd22c9dcfb8158262ab2519dc43b4',1,'node']]]
];
