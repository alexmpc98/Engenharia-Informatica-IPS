var searchData=
[
  ['prev',['prev',['../structnode.html#ae4cdd22c9dcfb8158262ab2519dc43b4',1,'node']]],
  ['ptlist',['PtList',['../list_8h.html#a39f79d75aefe285077489fdab3a43d76',1,'list.h']]],
  ['ptnode',['PtNode',['../listLinkedList_8c.html#afa9af1c2482b2c375481b34358a79c58',1,'listLinkedList.c']]]
];
