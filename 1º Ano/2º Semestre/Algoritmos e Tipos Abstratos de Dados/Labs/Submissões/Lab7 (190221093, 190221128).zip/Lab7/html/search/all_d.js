var searchData=
[
  ['timestamp_5ft',['timestamp_t',['../main5_8c.html#a29217083807c6b153656eda1a04f306d',1,'main5.c']]],
  ['total_5fscore',['total_score',['../structkahootReport.html#a2a24b841d40e7ae651c15869d75ca3fe',1,'kahootReport']]],
  ['totalaveragescore',['totalAverageScore',['../main4_8c.html#a8b4a3d6c96b8fb5b642559d9d6c0c961',1,'main4.c']]],
  ['trailer',['trailer',['../structlistImpl.html#a770086650ddb22546c1182b0a8d33ca3',1,'listImpl']]]
];
