var kahoot_8c =
[
    [ "KahootReportCreate", "kahoot_8c.html#a3f30600aea56ea7e6c912951460cff6e", null ],
    [ "KahootReportPrint", "kahoot_8c.html#aa42fcc047e9d5c860e1fe08cebe88d9f", null ]
];