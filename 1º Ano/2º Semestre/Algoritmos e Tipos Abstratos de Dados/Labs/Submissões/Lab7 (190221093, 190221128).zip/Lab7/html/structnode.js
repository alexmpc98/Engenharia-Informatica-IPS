var structnode =
[
    [ "element", "structnode.html#ad829a13d57f69f5739780e62966752d4", null ],
    [ "next", "structnode.html#a3b6e2d9364cf6b0c1559d67c4a26d737", null ],
    [ "prev", "structnode.html#ae4cdd22c9dcfb8158262ab2519dc43b4", null ]
];