var searchData=
[
  ['getquestions',['getQuestions',['../main4_8c.html#a240eee4545f16a438b848f2930712321',1,'main4.c']]]
];
