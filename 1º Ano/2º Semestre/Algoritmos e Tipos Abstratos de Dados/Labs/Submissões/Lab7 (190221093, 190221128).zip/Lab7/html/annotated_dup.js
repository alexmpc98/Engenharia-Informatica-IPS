var annotated_dup =
[
    [ "kahootReport", "structkahootReport.html", "structkahootReport" ],
    [ "listImpl", "structlistImpl.html", "structlistImpl" ],
    [ "node", "structnode.html", "structnode" ]
];