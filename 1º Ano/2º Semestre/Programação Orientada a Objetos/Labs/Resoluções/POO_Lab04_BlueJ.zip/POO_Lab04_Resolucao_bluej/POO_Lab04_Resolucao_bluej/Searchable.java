public interface Searchable
{
        boolean search(String text);
}
