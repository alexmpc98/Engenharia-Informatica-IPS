import java.util.ArrayList;

/**
 * Class that represents a User of type Teacher.
 *
 * @author POO
 * @version 2020/04/01
 */
public class Teacher extends User {

    private ArrayList<String> courseUnits;

    public Teacher(String username, String password) {
        super(username, password);
        this.courseUnits = new ArrayList<>();
    }

    @Override
    public String getInfo() {
        StringBuilder st = new StringBuilder("\nProfessor:");
        st.append("\n\tUsername: " + getUsername());
        st.append("\n\tAutenticado: " + booleanToString(isAuthenticated()));
        if (!courseUnits.isEmpty()) {
            st.append("\n\tProfessor de:"
                    + courseUnitsList());
        }
        return st.toString();
    }

    /**
     * Method that adds a course unit to list.
     *
     * @param courseUnit unit to add
     */
    public void addCourseUnit(String courseUnit) {
        if (courseUnit != null && !courseUnit.trim().isEmpty()) {
            this.courseUnits.add(courseUnit);
        }
    }

    /**
     * Auxiliar method that lists the values of courses units list.
     *
     * @return String - list of course units
     */
    private String courseUnitsList() {
        String list = "";
        for (String course : courseUnits) {
            list += "\n\t\t- " + course;
        }
        return list;
    }

}
