
import java.util.Date;

/**
 * Esta classe é usada para testar o código do projeto.
 * Para isso deve-se executar o método estático run
 * 
 * @author POO 2019/2020
 * @version abr/2020
 */
public class Program {

    public static void run() {
      // Nivel 1
        Teacher user1 = new Teacher("pedro.guerra", "123");

        Teacher user2 = new Teacher("ana.marques", "qwerty");
        user2.addCourseUnit("Programação Orientada por Objetos");
        user2.addCourseUnit("Introdução à Programaçao");

        Student user3 = new Student("rita.martins", "abcd", "Licenciatura em Engenharia Informática");

        // Nivel 2
        Post postMessage = new MessagePost("Ola a todos!");
        Post postPhoto = new MessagePost("Brevemente cartaz da semana academica!");
        Post postEvent1 = new EventPost("Seminário de POO", new Date(2019, 2, 23, 10, 30), "ESTSetubal");
        Post postEvent2 = new EventPost("ENEI - Encontro Nacional de E.I.", new Date(2020, 1, 23, 8, 30), "Braga");

        // Nivel 3
        SocialNetwork network = new SocialNetwork();

        network.addUser(user1);
        network.addUser(user3);
        network.addUser(user2);

        network.loginSession("pedro.guerra", "123");
        //network.logoutSession();
        network.listUsers();

        // Nivel 4
        network.publishPost(postMessage);
        network.publishPost(postPhoto);
        network.publishPost(postEvent1);
        network.publishPost(postEvent2);

        network.showFeed();

        // Nivel 5
        network.searchFor("acad");

        network.showNotifications();  
    }
    
}