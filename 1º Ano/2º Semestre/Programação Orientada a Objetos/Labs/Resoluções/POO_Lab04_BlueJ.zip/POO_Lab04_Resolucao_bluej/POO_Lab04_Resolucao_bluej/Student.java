/**
 * Class that represents a User of type Student.
 *
 * @author POO
 * @version 2020/04/01
 */
public class Student extends User {

    private String course;

    public Student(String username, String password, String course) {
        super(username, password);
        this.course = course;
    }

    @Override
    public String getInfo() {
        StringBuilder st = new StringBuilder("\nEstudante:");
        st.append("\n\tUsername: " + getUsername());
        st.append("\n\tAutenticado: " + booleanToString(isAuthenticated()));
        st.append("\n\tEstudante do curso " + course);
        return st.toString();
    }

}