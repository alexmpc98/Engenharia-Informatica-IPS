
public interface Notifiable
{
        void showNotication();
}
