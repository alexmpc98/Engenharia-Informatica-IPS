import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Abstract class that represents a generic Post.
 *
 * @author POO
 * @version 2020/04/01
 */
public abstract class Post implements Searchable {

    private User author;
    private final long timestamp;
    private boolean visible;

    public Post() {
        this.author = null;
        this.timestamp = System.currentTimeMillis();
        this.visible = true;
    }

    public abstract void show();

    protected String getDataFormated() {
        Date date = new Date(timestamp);
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yy  HH:mm");
        return dateFormat.format(date);
    }

    public User getAuthor() {
        return author;
    }

    public void setAuthor(User author) {
        this.author = author;
    }

    public boolean isVisible() {
        return visible;
    }

}
