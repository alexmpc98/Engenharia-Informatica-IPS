import java.util.ArrayList;

/**
 * Class that represents a Academic Social Network and its interaction.
 *
 * @author POO
 * @version 2020/04/01
 */
public class SocialNetwork {

    private ArrayList<User> users;
    private ArrayList<Post> posts;

    private User authenticatedUser;

    public SocialNetwork() {
        this.users = new ArrayList();
        this.posts = new ArrayList();
        this.authenticatedUser = null;
    }

    /**
     * Method responsible for printing the header.
     */
    private void showHeader() {
        System.out.println("\n\n*****************************************");
        System.out.println("*       ACADEMIC SOCIAL NETWORK         *");
        System.out.println("*****************************************");
    }

    /**
     * Method that allows to insert a new User. Only allows one User with the
     * same username.
     *
     * @param user
     */
    public void addUser(User user) {
        boolean exist = false;
        for (User u : users) {
            if (u.getUsername().equals(user.getUsername())) {
                exist = false;
                System.out.println("Utilizador já existente...");
            }
        }
        if (!exist) {
            users.add(user);
            System.out.println("Utilizador criado com sucesso!");
        }
    }

    /**
     * List all information about the users.
     */
    public void listUsers() {
        showHeader();
        System.out.println("*                USERS                  *");
        System.out.println("*****************************************");

        for (User user : users) {
            System.out.println(user.getInfo());
        }
    }

    /**
     * Search in the users list for a specific user and tries to login.
     *
     * @param username
     * @param password
     */
    public void loginSession(String username, String password) {
        boolean findUser = false;

        for (User user : users) {
            if (user.getUsername().equals(username)) {
                findUser = true;
                if (!user.isAuthenticated()) {
                    if (user.getPassword().equals(password)) {
                        user.setAuthenticated(true);
                        System.out.println("\nUtilizador autenticado com sucesso!");
                        this.authenticatedUser = user;
                    } else {
                        System.out.println("Password errada...");
                    }
                } else {
                    System.out.println("Utilizador já se encontra autenticado!");
                }
            }
        }

        if (!findUser) {
            System.out.println("Utilizador não existe...");
        } else {
            System.out.println("Bem vindo " + this.authenticatedUser.getUsername().toUpperCase() + "!");
        }
    }

    /**
     * Logout the users session.
     */
    public void logoutSession() {
        if (authenticatedUser != null) {
            authenticatedUser.setAuthenticated(false);
            authenticatedUser = null;
        } else {
            System.out.println("Nenhum utilizador autenticado!");
        }
    }

    /**
     * Responsible method for a post. Only authenticated users can post.
     *
     * @param post
     */
    public void publishPost(Post post) {
        if (authenticatedUser != null) {
            post.setAuthor(authenticatedUser);
            posts.add(post);
            System.out.println("Post adiocionado com sucesso por " + authenticatedUser.getUsername().toUpperCase());
        } else {
            System.out.println("Nenhum utilizador autenticado!");
        }
    }

    /**
     * Presents all the posts.
     */
    public void showFeed() {
        showHeader();
        System.out.println("*                 FEED                  *");
        System.out.println("*****************************************");
        for (Post post : posts) {
            if (post.isVisible()) {
                post.show();
            }
        }
    }

    /**
     * Presents all notifications.
     */
    public void showNotifications() {
        showHeader();
        System.out.println("*             NOTIFICATIONS             *");
        System.out.println("*****************************************");
        ArrayList<Notifiable> results = new ArrayList<Notifiable>();

        posts.stream()
                .filter(p -> p instanceof Notifiable)
                .forEach(p -> results.add((Notifiable) p));

        for (Notifiable n : results) {
            n.showNotication();
        }
    }

    /**
     * Search in all Searchable posts about a specific content.
     *
     * @param text
     */
    public void searchFor(String text) {
        ArrayList<Searchable> results = new ArrayList<Searchable>();
        posts.stream()
                .filter(p -> p instanceof Searchable)
                .forEach(p -> results.add((Searchable) p));

        if (results.size() != 0) {

            for (Searchable s : results) {
                if (!(s instanceof Post)) {
                    continue;
                }
                Post post = (Post) s;
                if (post.search(text)) {
                    System.out.println("\nThe term '" + text + "' was found in:");
                    post.show();
                }
            }
        } else {
            System.out.println("\nTerm '" + text + "' not found.");
        }
    }

}
