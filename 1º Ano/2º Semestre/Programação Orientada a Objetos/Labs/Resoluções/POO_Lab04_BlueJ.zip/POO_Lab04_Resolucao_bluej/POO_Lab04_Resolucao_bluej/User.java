/**
 * Abstract class that represents a generic network User.
 *
 * @author POO
 * @version 2020/04/01
 */
public abstract class User {

    private String username;
    private String password;
    private boolean authenticated;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
        this.authenticated = false;
    }

    /**
     * Method that shows all information about a specific User.
     *
     * @return
     */
    public abstract String getInfo();

    /**
     *
     * @param value
     * @return
     */
    protected String booleanToString(boolean value) {
        return (value) ? "Sim" : "Não";
    }

    public String getUsername() {
        return username;
    }

    public boolean isAuthenticated() {
        return authenticated;
    }

    public String getPassword() {
        return password;
    }

    public void setAuthenticated(boolean authenticated) {
        this.authenticated = authenticated;
    }

}
