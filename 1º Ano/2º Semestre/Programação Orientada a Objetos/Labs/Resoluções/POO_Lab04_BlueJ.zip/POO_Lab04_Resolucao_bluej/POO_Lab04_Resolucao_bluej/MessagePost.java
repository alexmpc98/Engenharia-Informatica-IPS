/**
 * Class that represents a textual Post.
 *
 * @author POO
 * @version 2020/04/01
 */
public class MessagePost extends Post {

    private String message;

    public MessagePost(String message) {
        this.message = message;
    }

    @Override
    public void show() {
        System.out.println("\n|****************************************");
        System.out.println("| Author: " + getAuthor().getUsername());
        System.out.println("| Date: " + getDataFormated());
        System.out.println("|");
        System.out.println("| Message:\n| " + message);
        System.out.println("*****************************************");
    }

    @Override
    public boolean search(String text) {
        return (message.contains(text) || getAuthor().getUsername().contains(text));
    }

}
