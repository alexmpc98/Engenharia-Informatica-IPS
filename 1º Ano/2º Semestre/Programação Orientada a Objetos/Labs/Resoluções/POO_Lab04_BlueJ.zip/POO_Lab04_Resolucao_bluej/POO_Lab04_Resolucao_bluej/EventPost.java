import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Class that represents a Post with information about Event.
 *
 * @author POO
 * @version 2020/04/01
 */
public class EventPost extends Post implements Notifiable, Searchable {

    private String description;
    private Date date;
    private String location;

    public EventPost(String description, Date date, String location) {
        //super(author);
        this.description = description;
        this.date = date;
        this.location = location;
    }

    @Override
    public void show() {
        System.out.println("\n|****************************************");
        System.out.println("| Author: " + getAuthor().getUsername());
        System.out.println("| Date: " + getDataFormated());
        System.out.println("|");
        System.out.println("| Event:");
        System.out.println("| " + description);
        System.out.println("|");
        System.out.println("| " + getDate() + "  |\t" + location);
        System.out.println("*****************************************");
    }

    @Override
    public void showNotication() {
        System.out.println("| Evento: " + description);
        System.out.println("| Em: " + getDate() + ", " + location);
        System.out.println("*****************************************");
    }

    @Override
    public boolean search(String text) {
        return (description.contains(text) || location.contains(text) || getAuthor().getUsername().contains(text));
    }

    public String getDate() {
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yy  HH:mm");
        return dateFormat.format(date);
    }

}
