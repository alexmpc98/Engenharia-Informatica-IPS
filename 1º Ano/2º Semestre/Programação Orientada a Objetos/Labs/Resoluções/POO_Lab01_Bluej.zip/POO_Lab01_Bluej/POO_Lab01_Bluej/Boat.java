import java.util.ArrayList;
import java.util.Random;

/**
 * Embarcação tripulada de pesca
 *
 * @author POO 2019/2020
 * @version Mar/2020
 */
public class Boat {

    private static final int MAX_TANKS = 6;
    private int numberOfFishermen;
    private String name;
    private ArrayList<Tank> tanks;
    private BoatStatus status;

    public Boat(int numberOfFishermen, String name, int tankQuantity) {
        this.numberOfFishermen = (numberOfFishermen > 0 && numberOfFishermen <= 10) ? numberOfFishermen : 3;
        this.name = (name != null && !name.isEmpty()) ? name : "desconhecido";
        this.status = BoatStatus.MOORED;

        this.tanks = new ArrayList<>();
        tankQuantity = (tankQuantity <= MAX_TANKS) ? tankQuantity : MAX_TANKS;
        for (int i = 0; i < tankQuantity; i++) {
            tanks.add(new Tank(tanks.size() + 1));
        }
    }

    /**
     * Metodo que instala um novo tanque, se a embarcação assim o permitir
     */
    public void installTank() {
        if (tanks.size() < MAX_TANKS) {
            tanks.add(new Tank(tanks.size() + 1));
            System.out.println("Tanque inserido com sucesso no barco " + name);
        } else {
            System.out.println("Barco " + name + " não permite a inserção de mais tanques");
        }
    }

    /**
     * Metodo que inicia o processo de pesca e lançamento das redes. Um barco
     * pode iniciar a pesca assim que sai do porto
     */
    public void startFishing() {
        if (status != BoatStatus.FISHING) {
            status = BoatStatus.FISHING;
        } else {
            System.out.println("O Barco " + name + " já se encontra a pescar");
        }
    }

    /**
     * Metodo que retorna um barco ao porto. O barco só pode retornar se tiver
     * as redes recolhidas
     */
    public void returnToPort() {
        if (status == BoatStatus.SAILING) {
            status = BoatStatus.MOORED;
        } else {
            System.out.println("O Barco " + name + " não pode retornar");
        }
    }

    /**
     * Metodo que simula o recolher das redes. Ao retirar as redes gera um valor
     * aleatorio de peixe pescado (kg). Esta quantidade vai ser distribuida por
     * todos os tanques enquanto houver espaço disponivel.
     */
    public void collect() {
        Random rd = new Random();
        if (status == BoatStatus.FISHING) {
            status = BoatStatus.SAILING;
            int fishQuantityTotal = rd.nextInt(20001);

            int fishQuantity = fishQuantityTotal;
            for (Tank tank : tanks) {
                fishQuantity = tank.insert(fishQuantity);
            }

            if (fishQuantity != 0) {
                System.out.println("A capacidade máxima do barco " + name + " foi ultrapassada");
            } else {
                System.out.println(fishQuantityTotal + "kg de peixe foram adicionados com sucesso ao barco " + name);
            }
        } else {
            System.out.println("O Barco " + name + " não se encontra em pesca");
        }
    }

    /**
     * Metodo que devolve a quantidade total de peixe existente em todos os
     * tanques da embarcação
     *
     * @return int - total de peixe
     */
    public int getTotalFish() {
        int quantity = 0;
        for (Tank tank : tanks) {
            quantity += tank.getCurrentQuantity();
        }
        return quantity;
    }

    public int getNumberOfFishermen() {
        return numberOfFishermen;
    }

    public BoatStatus getStatus() {
        return status;
    }

    @Override
    public String toString() {
        StringBuilder st = new StringBuilder("\n");
        st.append("Barco: ").append(name);
        st.append("\n\t- ").append(numberOfFishermen).append(" tripulantes");
        st.append("\n\tTanques:");
        for (Tank tank : tanks) {
            st.append(tank.toString());
        }
        st.append("\n\tCapacidade: ").append(getTotalFish()).append("/").append(tanks.size() * 5000);
        return st.toString();
    }

}
