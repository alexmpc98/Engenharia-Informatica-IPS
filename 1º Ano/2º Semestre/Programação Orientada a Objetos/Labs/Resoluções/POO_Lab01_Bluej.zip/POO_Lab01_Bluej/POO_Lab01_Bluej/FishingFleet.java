import java.util.HashMap;

/**
 * Empresa detentora de uma frota de embarcações de pesca
 *
 * @author POO 2019/2020
 * @version Mar/2020
 */
public class FishingFleet {

    private static final double COST_PER_BOAT = 1200.0;
    private static final double COST_PER_WORKER = 60.5;
    private static final double GAIN_PER_KG = 1.2;
    private HashMap<String, Boat> boats;
    private String companyName;

    public FishingFleet(String companyName) {
        this.companyName = (companyName != null && !companyName.isEmpty()) ? companyName : "desconhecido";
        boats = new HashMap<>();
    }

    /**
     * Metodo que regista um barco com uma chave sequencial
     *
     * @param boat - barco a registar
     */
    public void registerBoat(Boat boat) {
        if (boat != null) {
            boats.put("B" + (boats.size() + 1), boat);
        }
    }

    /**
     * Metodo que lista os barcos da frota
     */
    public void listBoats() {
        StringBuilder st = new StringBuilder("\nBarcos:");
        for (String key : boats.keySet()) {
            st.append("\n\t- " + key);
        }
        System.out.println(st.toString());
    }

    /**
     * Metodo que chama ao porto todos os barcos ativos
     */
    public void returnBoats() {
        for (Boat boat : boats.values()) {
            if (boat.getStatus() != BoatStatus.MOORED) {
                boat.returnToPort();
            }
        }
    }

    /**
     * Metodo que chama ao porto um barco especifico
     *
     * @param key
     */
    public void returnBoat(String key) {
        if (key == null || !boats.containsKey(key)) {
            return;
        }
        if (boats.get(key).getStatus() != BoatStatus.MOORED) {
            boats.get(key).returnToPort();
        }
    }

    /**
     * Metodo que envia para pesca um barco especifico
     *
     * @param key
     */
    public void sendBoat(String key) {
        if (key == null || !boats.containsKey(key)) {
            return;
        }
        if (boats.get(key).getStatus() == BoatStatus.MOORED) {
            boats.get(key).startFishing();
        }
    }

    /**
     * Metodo que recolhe as redes de um barco especifico
     *
     * @param key
     */
    public void collectBoat(String key) {
        if (boats.get(key).getStatus() == BoatStatus.FISHING) {
            boats.get(key).collect();
        }
    }

    /**
     * Metodo que retorna o total de trabalhadores em todas as embarcações
     *
     * @return
     */
    private int getTotalWorkers() {
        int workers = 0;
        for (Boat boat : boats.values()) {
            workers += boat.getNumberOfFishermen();
        }
        return workers;
    }

    /**
     * Metodo que calcula o custo atual de toda a frota ativa
     *
     * @return custo atual
     */
    private double getCurrentCost() {
        int totalBoatsFishing = 0;
        int totalWorkersFishing = 0;
        for (Boat boat : boats.values()) {
            if (boat.getStatus() != BoatStatus.MOORED) {
                totalBoatsFishing++;
                totalWorkersFishing += boat.getNumberOfFishermen();
            }
        }
        return (totalBoatsFishing * COST_PER_BOAT) + totalWorkersFishing * COST_PER_WORKER;
    }

    /**
     * Metodo que calcula o lucro atual obtido de toda a frota ativa
     *
     * @return lucro atual
     */
    private double getCurrentGain() {
        int totalKg = 0;
        for (Boat boat : boats.values()) {
            if (boat.getStatus() != BoatStatus.MOORED) {
                totalKg += boat.getTotalFish();
            }
        }
        return totalKg * GAIN_PER_KG;
    }

    @Override
    public String toString() {
        StringBuilder st = new StringBuilder("\n********************************************************");
        st.append("\nEmpresa: ").append(companyName);
        st.append("\nNº de trabalhadores: ").append(getTotalWorkers());
        st.append("\nNº de embarcações: ").append(boats.size());

        st.append("\n\nEmbarcações:");
        for (Boat boat : boats.values()) {
            st.append(boat.toString());
        }

        st.append("\n\nContabilidade:");
        st.append("\n\t- Despesa atual estimada: ").append(getCurrentCost()).append("€");
        st.append("\n\t- Lucro atual estimado: ").append(getCurrentGain()).append("€");
        st.append("\n\t- Balanço atual: ").append(getCurrentGain() - getCurrentCost()).append("€");

        return st.toString();

    }

}
