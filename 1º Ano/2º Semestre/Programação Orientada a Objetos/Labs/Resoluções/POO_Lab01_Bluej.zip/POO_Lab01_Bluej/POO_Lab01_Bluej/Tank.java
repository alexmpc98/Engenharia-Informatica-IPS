/**
 * Tanque de armazenamento que suporta uma quantidade máxima de peixe pescado
 *
 * @author POO 2019/2020
 * @version Mar/2020
 */
public class Tank {

    private static final int MAX_QUANTITY = 5000;
    private int id;
    private int currentQuantity;

    public Tank(int id) {
        this.id = id;
        this.currentQuantity = 0;
    }

    /**
     * Metodo que verifica se um tanque se encontra cheio
     *
     * @return
     */
    public boolean isFull() {
        return (currentQuantity == MAX_QUANTITY);
    }

    /**
     * Metodo que no caso de existir espaço disponivel no tanque insere a
     * quantidade recebida. Caso contrario, devolve a quantidade que não foi
     * posivel de inserir.
     *
     * @param quantity
     * @return
     */
    public int insert(int quantity) {

        if (quantity <= 0) {
            return MAX_QUANTITY - currentQuantity;
        }

        int totalQuantity = currentQuantity + quantity;
        if (totalQuantity <= MAX_QUANTITY) {
            currentQuantity = totalQuantity;  
            return MAX_QUANTITY - currentQuantity;
        }

        currentQuantity = MAX_QUANTITY;
        return totalQuantity - MAX_QUANTITY;
    }

    /**
     * Metodo que esvazia um tanque
     */
    public void empty() {
        currentQuantity = 0;
    }

    public int getCurrentQuantity() {
        return currentQuantity;
    }

    @Override
    public String toString() {
        StringBuilder st = new StringBuilder("\n\t\t- Tanque ").append(id).append(": ").append(currentQuantity).append(" kg");
        return st.toString();
    }
}
