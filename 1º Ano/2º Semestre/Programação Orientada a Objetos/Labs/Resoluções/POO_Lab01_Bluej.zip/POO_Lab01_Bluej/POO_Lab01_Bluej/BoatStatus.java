/**
 * Enumeration class Status - valores possíveis para o estado de uma embarcação
 *
 * @author POO 2019/2020
 * @version Mar/2020
 */
public enum BoatStatus {
    FISHING, MOORED, SAILING;

    @Override
    public String toString() {
        switch (this) {
            case FISHING:
                return "A pescar";
            case MOORED:
                return "Atracado";
            case SAILING:
                return "A navegar";
            default:
                return "";
        }
    }

}
