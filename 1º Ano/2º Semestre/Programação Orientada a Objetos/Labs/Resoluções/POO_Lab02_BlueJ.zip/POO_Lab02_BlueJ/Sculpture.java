
/**
 * Escultura do museu
 *
 * @author POO 2019/2020
 * @version mar/2020
 */
//NIVEL 3
public class Sculpture extends WorkOfArt {

    private String material;

    public Sculpture() {
        super();
        this.material = "Não especificado";
    }

    public Sculpture(String artist, String name, String material) {
        super(artist, name);
        this.material = (material != null) ? material : "Não especificado";
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        if (material != null) {
            this.material = material;
        }
    }

    @Override
    public String toString() {
        return "Escultura:\n" + super.toString() + "\nMaterial - " + material + "\n";
    }
}