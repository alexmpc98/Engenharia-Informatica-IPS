
/**
 * Sala do museu
 *
 * @author POO 2019/2020
 * @version mar/2020
 */
//NIVEL 1
public class Room {

    private static int lastNumber = 0;
    private final int number = ++lastNumber;
    private String name;
    private double area;

    public Room() {
        this.name = "Sala " + number;
        this.area = 0;
    }
    
    public Room(String name, double area) {
        this.name = (name == null || name.isEmpty()) ? "Sala " + number : name;
        this.area = (area > 0) ? area : 0;
    }

    public int getNumber() {
        return number;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name != null)
            this.name = name;
    }
    
    public double getArea() {
        return area;
    }

    public void setArea(double area) {
        if (area > 0)
            this.area = area;
    }
    
    @Override
    public String toString() {
        return "###############    " + name + "    ###############";
    }
}
