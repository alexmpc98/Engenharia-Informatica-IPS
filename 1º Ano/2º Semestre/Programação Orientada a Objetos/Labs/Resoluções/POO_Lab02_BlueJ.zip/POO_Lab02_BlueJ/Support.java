
/**
 * Enumeration class Status - suporte utilizado para a pintura
 *
 * @author POO 2019/2020
 * @version mar/2020
 */
//NIVEL 3
public enum Support {
    ON_CANVAS, ON_PAPER, ON_WOOD, ON_GLASS, OTHER;

    @Override
    public String toString() {
        switch (this) {
            case ON_CANVAS:
                return "sobre tela";
            case ON_PAPER:
                return "sobre papel";
            case ON_WOOD:
                return "sobre madeira";
            case ON_GLASS:
                return "sobre vidro";
        }
        return "Suporte não especificado";
    }
}