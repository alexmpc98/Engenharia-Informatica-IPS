
/**
 * Pintura do museu
 *
 * @author POO 2019/2020
 * @version mar/2020
 */
//NIVEL 3
public class Painting extends WorkOfArt {

    private String artMovement;
    private InkType inkType;
    private Support support;

    public Painting() {
        super();
        this.artMovement = "Não especificado";
        this.inkType = InkType.OTHER;
        this.support = Support.OTHER;
    }

    public Painting(String artist, String name, String artMovement, InkType inkType, Support support) {
        super(artist, name);
        this.artMovement = (artMovement != null) ? artMovement : "Não especificado";
        this.inkType = inkType;
        this.support = support;
    }

    public String getArtMovement() {
        return artMovement;
    }

    public void setArtMovement(String artMovement) {
        if (artMovement != null) {
            this.artMovement = artMovement;
        }
    }

    public InkType getInkType() {
        return inkType;
    }

    public void setInkType(InkType inkType) {
        this.inkType = inkType;
    }

    public Support getSupport() {
        return support;
    }

    public void setSupport(Support support) {
        this.support = support;
    }

    @Override
    public String toString() {
        return "Pintura:\n" + super.toString()
                + "\nMovimento artístico - " + artMovement
                + "\nCarateristicas - " + inkType + " " + support + "\n";
    }
}
