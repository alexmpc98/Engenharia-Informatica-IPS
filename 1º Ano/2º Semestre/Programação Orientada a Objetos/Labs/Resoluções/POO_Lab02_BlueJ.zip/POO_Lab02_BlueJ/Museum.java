
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 * Museu relaciona as obras de arte com a respetiva sala de exibição
 *
 * @author POO 2019/2020
 * @version mar/2020
 */
//NIVEL 4
public class Museum {

    private Map<WorkOfArt, Room> museumCollection;

    public Museum () {
        museumCollection = new HashMap<>();
    }

    public void addToMuseumCollection(WorkOfArt workOfArt, Room room) {
        if (workOfArt != null && room != null && !museumCollection.containsKey(workOfArt)) {
            museumCollection.put(workOfArt, room);
        }
    }
    
    public void removeFromMuseumCollection(WorkOfArt workOfArt) {
        if (workOfArt != null && museumCollection.containsKey(workOfArt)) {
            museumCollection.remove(workOfArt);
        }
    }
    
// Nível 5
    public String listArtInRoom(Room room) {
        String str = room.toString();

        for (WorkOfArt woa : museumCollection.keySet()) {
            if (museumCollection.get(woa).equals(room)) {
                str += "\n" + woa;
            }
        }
        return str;
    }
    
// Nível 5
    public void printAllByRoom() {
        HashSet<Room> rooms = new HashSet<>(museumCollection.values());

        for (Room r : rooms) {
            System.out.println(r);
            museumCollection.keySet().stream()
                              .filter(woa -> museumCollection.get(woa).equals(r))
                              .forEach(woa -> System.out.println(woa));
        }
    }
    
    @Override
    public String toString() {
        String str = "";

        for (WorkOfArt woa : museumCollection.keySet()) {
            str += "\n" + woa;
        }
        
        return str;
    }
}
