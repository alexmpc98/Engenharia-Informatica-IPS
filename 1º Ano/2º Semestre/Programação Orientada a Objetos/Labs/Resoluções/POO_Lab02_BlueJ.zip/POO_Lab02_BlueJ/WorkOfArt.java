
/**
 * Obra de arte
 *
 * @author POO 2019/2020
 * @version mar/2020
 */
//NIVEL 2
public class WorkOfArt {

    private static int lastCode = 0;
    private final int code = ++lastCode;
    static final boolean OFF_DISPLAY = false;
    static final boolean ON_DISPLAY = true;
    private boolean onDisplay = OFF_DISPLAY;
    private String artist;
    private String title;

    public WorkOfArt() {
        this("Desconhecido", "Sem título");
    }

    public WorkOfArt(String artist, String title) {
        if (artist != null) {
            this.artist = artist;
        }
        if (title != null) {
            this.title = title;
        }
    }

    public int getCode() {
        return this.code;
    }

    public void setTitle(String title) {
        if (title != null) {
            this.title = title;
        }
    }

    public String getTitle() {
        return this.title;
    }

    public void setOnDisplay(boolean onDisplay) {
        this.onDisplay = onDisplay;
    }

    public boolean getOnDisplay() {
        return this.onDisplay;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        if (artist != null) {
            this.artist = artist;
        }
    }

    @Override
    public String toString() {
        return "Título - " + title + "\nArtista - " + artist;
    }
}