
import java.util.ArrayList;

/**
 *
 * @author NFERRO
 */
public class POO_Lab02_BlueJ {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //NIVEL 1     ***************************************
        System.out.println("//NIVEL 1  *************************************** ");
        ArrayList<Room> rooms = new ArrayList<>();
        
        Room room1 = new Room();
        Room room2 = new Room();
        Room room3 = new Room();
        
        rooms.add(room1);
        rooms.add(room2);
        rooms.add(room3);
        
        for (Room r : rooms) {
            System.out.println(r);
        }
        
        
        //NIVEL 2     ***************************************
        System.out.println("\n//NIVEL 2  *************************************** ");
        WorkOfArt woa1 = new WorkOfArt();
        WorkOfArt woa2 = new WorkOfArt("Desconhecido", "Obra de arte");

        System.out.println("Obra de arte - " + woa1);
        System.out.println("Obra de arte - " + woa2);
        
        
        //NIVEL 3     ***************************************
        System.out.println("\n//NIVEL 3  *************************************** ");
        
        Painting p1 = new Painting("Jean-Baptiste Corot", "Jovem Lendo", "Realismo", InkType.OIL, Support.ON_CANVAS);
        
        Sculpture s1 = new Sculpture("Auguste Rodin", "O pensador", "Bronze");
        
        ArrayList<WorkOfArt> art = new ArrayList<>();
        art.add(p1);
        art.add(s1);

        for (WorkOfArt w : art) {
            System.out.println(w);
        }

        
        //NIVEL 4     ***************************************
        System.out.print("//NIVEL 4  *************************************** ");
        Museum  museum = new Museum ();
        
        museum.addToMuseumCollection(p1, room1);
        museum.addToMuseumCollection(s1, room2);
        
        System.out.println(museum);

        
        //NIVEL 5     ***************************************
        System.out.println("//NIVEL 5  *************************************** ");

        Painting p2 = new Painting("Claude Monet", "Mulher com sombrinha", "Impressionismo", InkType.OIL, Support.ON_CANVAS);
        Sculpture s2 = new Sculpture("Miguel Ângelo", "David", "Mármore de Carrara");
        
        museum.addToMuseumCollection(p2, room1);
        museum.addToMuseumCollection(s2, room3);
        
        System.out.println(museum.listArtInRoom(room1));
        
        museum.printAllByRoom();
    }
    
}
