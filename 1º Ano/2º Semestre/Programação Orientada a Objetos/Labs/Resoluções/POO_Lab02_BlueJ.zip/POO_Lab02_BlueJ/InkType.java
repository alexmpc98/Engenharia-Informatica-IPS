
/**
 * Enumeration class Status - tipo de tinta utilizado para a pintura
 *
 * @author POO 2019/2020
 * @version mar/2020
 */
//NIVEL 3
public enum InkType{
    OIL, WATERCOLOR, PASTEL, ACRYLIC, OTHER;

    @Override
    public String toString() {
        switch (this) {
            case OIL:
                return "Óleo";
            case WATERCOLOR:
                return "Aguarela";
            case PASTEL:
                return "Pastel";
            case ACRYLIC:
                return "Acrílico";
        }
        return "";
    }
}


