/**
 * Representa uma carta de jogar com uma figura.
 * 
 * @author POO 2019/2020
 * @version abr/2020
 */
// Nível 1 
public class FaceCard extends Card {
    private FaceName faceName;

    public FaceCard(FaceName faceName, Suit suit, int value) {
        super(suit, value);
        this.faceName = faceName;
    }

    public FaceCard(FaceName face, Suit suit) {
        super(suit);
        this.faceName = face;
    }

    public FaceName getFaceName() {
        return faceName;
    }

    // Nível 2
    @Override
    public String getName() {
        return faceName.toString(); 
    }

    // Nível 3
    @Override
    public String toString() {
        return faceName + " de " + getSuit();
    }
}
