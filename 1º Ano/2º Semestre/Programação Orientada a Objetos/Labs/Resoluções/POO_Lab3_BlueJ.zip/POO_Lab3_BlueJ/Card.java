/**
 * Representa uma carta de jogar.
 * 
 * @author POO 2019/2020
 * @version abr/2020
 */
// Nível 1
public class Card {

    private Suit suit;
    private int value;

    public Card(Suit suit) {
        this.suit = suit;
    }

    public Card(Suit suit, int value) {
        this.suit = suit;
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public Suit getSuit() {
        return suit;
    }

    // Nível 2
    public String getName() {
        return "";
    }

}
