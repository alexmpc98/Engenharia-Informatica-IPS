import java.util.ArrayList;

/**
 * Esta classe é usada para testar o código do projeto.
 * Para isso deve-se executar o método estático run
 * 
 * @author POO 2019/2020
 * @version abr/2020
 */
public class Program {

    public static void run() {
        // Nível 1
        System.out.println("====== Nível 1 ======");
        FaceCard card1 = new FaceCard(FaceName.JACK, Suit.CLUBS);
        NumberedCard card2 = new NumberedCard(3, Suit.DIAMONDS);

        System.out.print("Carta 1: ");
        System.out.println("" + card1.getFaceName() + " - " + card1.getSuit());

        System.out.print("Carta 2: ");
        System.out.println("" + card2.getNumber() + " - " + card1.getSuit());

        // Nível 2
        System.out.println("\n====== Nível 2 ======");
        ArrayList<Card> cards = new ArrayList<Card>();

        cards.add(card1);
        cards.add(card2);
        cards.add(new NumberedCard(1, Suit.CLUBS));
        System.out.println("Nomes das Cartas:");
        for (Card card : cards) {
            System.out.println(card.getName());
        }

        // Nível 3
        System.out.println("\n====== Nível 3 ======");

        cards.add(new FaceCard(FaceName.KING, Suit.HEARTS));
        cards.add(new FaceCard(FaceName.QUEEN, Suit.SPADES));

        System.out.println("Lista das Cartas:");
        for (Card card : cards) {
            System.out.println(card);
        }

        // Nível 4
        System.out.println("\n====== Nível 4 ======");

        Deck deck1 = new Deck(cards);

        System.out.println("Baralho de cartas:");
        System.out.println(deck1);

        // Nível 5
        System.out.println("\n====== Nível 5 ======");
        SuecaDeck deck2 = new SuecaDeck();
        System.out.println("Baralho de cartas da Sueca:");
        System.out.println(deck2);

        for (int i = 1; i <= 30; i++) {
            deck2.getRandomCard();
        }

        System.out.println("Baralho de cartas da Sueca (sem 30 cartas)");
        System.out.println(deck2);
    }

}

