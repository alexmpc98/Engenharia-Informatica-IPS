/**
 * Classe inicial para representação de uma carta.
 * tem problemas de coesão.
 * 
 * @author POO 2019/2020
 * @version abr/2020
 */
public class Card1 {
    private int number; 
    private Suit suit;
    private int value;
    private boolean isFace;
    private String faceName;
}
