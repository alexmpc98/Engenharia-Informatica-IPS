
public interface Notifiable
{
    public void showNotification();
}
