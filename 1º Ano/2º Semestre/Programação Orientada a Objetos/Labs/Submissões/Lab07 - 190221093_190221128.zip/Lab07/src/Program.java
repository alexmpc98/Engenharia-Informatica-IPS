
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Alexandre & Sérgio
 */
public class Program {
    public static void main(String args[]){
        //Nivel 1 ***************************************************
        ParticipantType speaker = ParticipantType.SPEAKER;
        ParticipantType student = ParticipantType.STUDENT;
        ParticipantType teacher = ParticipantType.TEACHER;
        ParticipantType other = ParticipantType.OTHER;
        
        Participant alex = new Participant("Alex", speaker);
        Participant sergio = new Participant("Sérgio", speaker);
        Registration newRegister1 = new Registration("26/05/2020 20:50", alex, 10.99);
        Registration newRegister2 = new Registration("26/05/2020 21:50", sergio, 10.99);
        
        
        //Nivel 2 ***************************************************
        Event nosAlive = new Event("Nos Alive","26/08/2020","Algés",200.00);
        nosAlive.addRegister(newRegister1);
     
        // Exception 1
        //Participant ErrorUsername = new Participant("",Speaker);
        // Exception 2
        //Registration errorRegister = new Registration("323232",Alex);
        // Exception 3
        //Event errorEvent = new Event("","26/08/2020 20:50","Algés",200.00);
        
        
        //Nivel 3 ***************************************************
        EventManager eventManager = new EventManager();
        eventManager.registerEvent(nosAlive);
        System.out.println(eventManager.ticketInfo(nosAlive, newRegister2));
        System.out.println(eventManager.registerParticipant("Nos Alive", sergio,"26/08/2020 20:50"));
        
        
        //Nivel 4 ***************************************************
        EventManagerFileHandler.printToFile(nosAlive.getName()+" - Participantes.txt", eventManager.getEventParticipantsList(nosAlive.getName()));
        ArrayList <Registration> registrationAL = nosAlive.getRegistrations();
        EventManagerFileHandler.printToFile("UltimoBilhete.txt", eventManager.ticketInfo(nosAlive, registrationAL.get(registrationAL.size()-1)));
        
        
        //Nivel 5 ***************************************************
        EventManager newEventManager = new EventManager();
        Event seminarioPOO = new Event("Seminário de POO", "10/06/2020", "ESTSetúbal", 200.00);
        Event conferenciaIA = new Event("Conferência de IA", "25/08/2020", "ESTSetúbal", 200.00);
        newEventManager.registerEvent(seminarioPOO);
        newEventManager.registerEvent(conferenciaIA);        
        
        for (int i = 0; i < 5; i++) {
            seminarioPOO.addRegister(new Registration("26/05/2020 "+(15+i)+":50",  new Participant("User"+i+1, speaker), 10+i));
        }
        conferenciaIA.addRegister(new Registration("25/08/2020 21:50",  new Participant("User1", speaker), 35));
        
        EventManagerFileHandler.saveEvents("data.bin", newEventManager);
        EventManagerFileHandler.loadEvents("data.bin");
        
    }
}
