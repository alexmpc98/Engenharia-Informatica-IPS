
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Alexandre & Sérgio
 */

public class EventManager implements Serializable {
    private ArrayList<Event> events;  
    
    public EventManager(){
        this.events = new ArrayList<>();
    }
    public void registerEvent(Event event){
        if(event != null)
            this.events.add(event);
    }
    
    public ArrayList<Event> getEvents(){
        return this.events;
    }
    
    public String ticketInfo(Event event, Registration registration){
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy HH:mm");
        String str = "\nBilhete: \n";
        if(event!=null && registration != null){
            str += "Nome do evento: " + event.getName() + "\n";
            str += "Local do evento: " + event.getLocal() + "\n";
            str += "Data do evento: " + formatter.format(event.getDate()) + "\n";
            str += "Nome do participante: " + registration.getParticipant().getName() +"\n";
            str += "Preço do bilhete: " + registration.calculateCost(event.getPrice());          
        }
        return str;
    }
    
    public String registerParticipant(String name, Participant participant, String date) {
        String str = "";
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        Event getEvent = events.stream().filter(event -> event.getName() == name).findAny().orElse(null);
        String finalDate = (date == null) ? formatter.format(date) : date;
        if (getEvent != null) {
            Registration registration = new Registration(finalDate, participant, getEvent.getPrice());
            getEvent.addRegister(registration);
            str = ticketInfo(getEvent, registration);
        } else {
            str = ("\nNão foi encontrado nenhum evento!");
        }   
        return str;
    }
    
    public String getEventParticipantsList(String eventName) {
        String str = "";
        Event getEvent = events.stream().filter(event -> event.getName() == eventName).findAny().orElse(null);
        if (getEvent != null) {
            str += "Participantes do " + eventName + ": \n";
            ArrayList<Registration> registrations = getEvent.getRegistrations();
            for (Registration reg : registrations) {
                str += reg.getParticipant().toString();
            }
        } else {
            str = ("\nNão foi encontrado nenhum evento!");
        }
        return str;
    }
}
