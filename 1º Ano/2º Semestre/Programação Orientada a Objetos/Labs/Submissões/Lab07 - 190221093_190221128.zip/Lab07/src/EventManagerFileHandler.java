
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Alexandre & Sérgio
 */
public abstract class EventManagerFileHandler {

    public static void printToFile(String fileName, String textToSave) {
        if (textToSave == null || textToSave == "") {
            throw new EventManagerIllegalArgumentException(ErrorCode.FILE_CANT_BE_NULL_OR_EMPTY);
        }

        try {
            FileWriter myWriter = new FileWriter(fileName);
            myWriter.write(textToSave);
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public static void saveEvents(String fileName, EventManager eventManager) {
        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName));
            oos.writeObject(eventManager);
            oos.flush();
            oos.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void loadEvents(String fileName) {
        EventManager readEvent;
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        
        try {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName));
            readEvent = (EventManager)ois.readObject();
            ois.close();
            System.out.println("\nEventos existentes: \n");
            System.out.println("Nome                     Local              Data               Participantes");
            ArrayList<Event> eventList = readEvent.getEvents();;
            for (Event e : eventList) {
                System.out.println(e.getName() + "         " + e.getLocal()  + "         " +  formatter.format(e.getDate())  + "         " +  e.getRegistrations().size());
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
}
