/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Alexandre & Sérgio
 */
public class EventManagerIllegalArgumentException extends IllegalArgumentException{
    private ErrorCode error;
    
    public EventManagerIllegalArgumentException(ErrorCode error){
        this.error = error;
    }
    
    public ErrorCode getError() {
        return this.error;
    }
}
