public enum BoatStatus {
    FISHING, MOORED, SAILING
}
