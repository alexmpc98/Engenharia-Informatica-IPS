
package trafficDemo;

import javafx.scene.Group;

/**
 *
 * @author POO 2019/2020
 * @version maio/2020
 */
interface Drawable {
    void addTo(Group group);
}
