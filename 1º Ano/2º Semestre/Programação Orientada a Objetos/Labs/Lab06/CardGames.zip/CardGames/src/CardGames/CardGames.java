/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CardGames;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Jose-MSI
 */
public class CardGames {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        System.out.println("=======================");
        
        List<Card> cards = new ArrayList<>();
        cards.add(new FaceCard(FaceName.JACK, Suit.CLUBS));
        cards.add(new NumberedCard(3, Suit.DIAMONDS));
        cards.add(new NumberedCard(1, Suit.CLUBS));
        cards.add(new FaceCard(FaceName.KING, Suit.HEARTS));
        cards.add(new FaceCard(FaceName.QUEEN, Suit.SPADES));
        
        System.out.println("Lista de Cartas soltas:\n");
        for (Card card : cards) {
            System.out.println(card);
        }
       
        System.out.println("\n\n==================");
        
        Deck deck1 = new Deck(cards);

        System.out.println("Baralho de cartas:\n");
        System.out.println(deck1);

        System.out.println("\n===========================");
        
        SuecaDeck deck2 = new SuecaDeck();
        
        System.out.println("Baralho de cartas da Sueca:\n");
        System.out.println(deck2);  
        
        
        System.out.println("\n==================");
    }

}
