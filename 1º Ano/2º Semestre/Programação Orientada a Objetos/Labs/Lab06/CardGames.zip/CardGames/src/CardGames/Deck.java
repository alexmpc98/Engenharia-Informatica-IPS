
package CardGames;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Esta classe representa um baralho de cartas
 * 
 * @author POO 2019/2020
 * @version maio/2020
 */

public class Deck {

    private List<Card> cards;
    private Random random = new Random();

    public Deck() {
        cards = new ArrayList<>();
    }

    public Deck(List<Card> cards) {
        this.cards = new ArrayList<>(cards);
    }

    public void addCard(Card card) {
        if (card != null) {
            cards.add(card);
        }
    }

    public boolean removeCard(Card card) {
        return cards.remove(card);
    }

    public void clear() {
        cards.clear();
    }

    @Override
    public String toString() {
        String cardsList = "";

        for (Card card : cards) {
            cardsList += card + "\n";
        }

        return cardsList;
    }

    public Card getRandomCard() {
        if (cards.isEmpty()) {
            return null;
        }
        int randomIndex = random.nextInt(cards.size() - 1);
        return cards.remove(randomIndex);
    }
}
