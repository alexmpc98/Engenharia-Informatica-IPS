/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BlockuDoku.Backend;

/**
 *
 * @author Alexandre e Sérgio
 */
public enum GameMode {   

    /**
     * Modo de jogo avançado.
     * 
     */
    ADVANCED,

    /**
     * Modo de jogo básico
     * 
     */
    BASIC    
}
