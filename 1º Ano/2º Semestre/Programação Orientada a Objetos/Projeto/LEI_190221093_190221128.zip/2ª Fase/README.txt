Alexandre Coelho - 190221093 - alexandremp98@hotmail.com
Sérgio Veríssimo - 190221128 - sergio_verissimo_123@hotmail.com