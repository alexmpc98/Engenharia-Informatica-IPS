/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BlockuDoku;

import java.util.Scanner;

/**
 *
 * @author Alexandre e Sérgio
 */
public class Program {

    /**
     * @param args the command row arguments
     */
    public static void main(String[] args) {
        Screen screen = new Screen(); // Game screen
        screen.displayMenus(); // Display menus
    }
}
