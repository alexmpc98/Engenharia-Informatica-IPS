/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 

/**
 *
 * @author jc
 */

public class Rook extends Piece {

   

    public Rook(Colour colour, Position position) {
       super(colour, position);
    }

       public String getName() {
        return "Torre";
    }

    @Override
    public String toString() {
        return "T" + super.toString();
    }
}
