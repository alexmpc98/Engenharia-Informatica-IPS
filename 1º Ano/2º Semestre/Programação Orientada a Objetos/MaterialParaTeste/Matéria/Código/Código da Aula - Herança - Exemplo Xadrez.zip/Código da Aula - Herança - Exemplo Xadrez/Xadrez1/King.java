/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 

/**
 *
 * @author Jose
 */
public class King {
    private Colour colour;
    private Position position;

    public King(Colour colour, Position position) {
        this.colour = colour;
        if (position != null) {
            this.position = position;
        } else {
            this.position = new Position();
        }
    }

    public Colour getColour() {
        return colour;
    }

    public Position getPosition() {
        return new Position(position.getX(), position.getY());
    }

    public void setPosition(char x, int y) {
        position.setX(x);
        position.setY(y);
    }

    public void setPosition(Position position) {
        position.setX(position.getX());
        position.setY(position.getY());
    }
    
    public void setY(int y) {
        position.setY(y);
    }

    public char getX() {
        return position.getX();
    }

    public int getY() {
        return position.getY();
    }

    public String getName() {
        return "Rei";
    }

    @Override
    public String toString() {
        return "R" + position.toString();
    }
}
