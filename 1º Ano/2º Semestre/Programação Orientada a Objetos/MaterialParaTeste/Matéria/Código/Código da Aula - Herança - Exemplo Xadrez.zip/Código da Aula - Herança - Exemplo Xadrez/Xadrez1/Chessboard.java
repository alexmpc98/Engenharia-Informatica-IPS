/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 

import java.util.ArrayList;


/**
 *
 * @author Jose
 */
public class Chessboard {

    ArrayList<Pawn> pawns;
    ArrayList<Knight> knights;
    ArrayList<Rook> rooks;
    ArrayList<Queen> queens;
    ArrayList<Bishop> bishops;
    ArrayList<King> kings;

    public Chessboard() {
        pawns = new ArrayList<>();
        knights = new ArrayList<>();
        rooks = new ArrayList<>();
        queens = new ArrayList<>();
        kings = new ArrayList<>();
        bishops = new ArrayList<>();

        setup();
    }

    private void setup() {
        for (char x = 'a'; x <= 'h'; x++) {
            pawns.add(new Pawn(Colour.WHITE, new Position(x, 2)));
            pawns.add(new Pawn(Colour.BLACK, new Position(x, 7)));
        }
        int line = 1;
        Colour colour = Colour.WHITE;
        rooks.add(new Rook(colour, new Position('a', line)));
        knights.add(new Knight(colour, new Position('b', line)));
        bishops.add(new Bishop(colour, new Position('c', line)));
        queens.add(new Queen(colour, new Position('d', line)));
        kings.add(new King(colour, new Position('e', line)));
        bishops.add(new Bishop(colour, new Position('f', line)));
        knights.add(new Knight(colour, new Position('g', line)));
        rooks.add(new Rook(colour, new Position('h', line)));

        line = 8;
        colour = Colour.BLACK;
        rooks.add(new Rook(colour, new Position('a', line)));
        knights.add(new Knight(colour, new Position('b', line)));
        bishops.add(new Bishop(colour, new Position('c', line)));
        queens.add(new Queen(colour, new Position('d', line)));
        kings.add(new King(colour, new Position('e', line)));
        bishops.add(new Bishop(colour, new Position('f', line)));
        knights.add(new Knight(colour, new Position('g', line)));
        rooks.add(new Rook(colour, new Position('h', line)));
    }

}
