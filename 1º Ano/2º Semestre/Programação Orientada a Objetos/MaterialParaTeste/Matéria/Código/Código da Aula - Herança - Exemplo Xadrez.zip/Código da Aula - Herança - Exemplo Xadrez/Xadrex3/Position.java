/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 

/**
 *
 * @author jc
 */

public class Position {
    private char x;
    private int y;

    public Position(char x, int y) {
        this.x = x;
        this.y = y;
    }

    public Position() {
        this.x = 'a';
        this.y = 1;
    }

    @Override
    public String toString() {
        return "" + x + y;
    }

    public char getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setX(char x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }
}
