/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package efeitos;

import javafx.scene.effect.Effect;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

/**
 *
 * @author rcneves
 */
public class Texto extends Text {

    private static final String TEXTO = "JavaFX!";
    private static final double TAMANHO_FONTE = 60.0;

    public Texto() {
        setText(TEXTO);
        setFill(Color.STEELBLUE);
        setFont(Font.font(null, FontWeight.BOLD, TAMANHO_FONTE));
    }

    public Texto(Effect efeito) {
        this();
        setEffect(efeito);
    }
}
