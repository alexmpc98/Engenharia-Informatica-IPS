/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package transicoes;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author rcneves
 */
public class Transicoes extends Application {

    private static final double LARGURA = 300.0;
    private static final double ALTURA = 750.0;
    private static final double ESPACAMENTO_ELEMENTOS = 60.0;
    private static final double ESPACAMENTO_LATERAL = 10.0;

    @Override
    public void start(Stage primaryStage) {
        Texto textoOriginal = new Texto();
        Texto textoTranslacao = new Texto();
        Texto textoRotacao = new Texto();
        Texto textoEscala = new Texto();
        Texto textoEsbatimento = new Texto();

        VBox root = new VBox(ESPACAMENTO_ELEMENTOS);
        root.setPadding(new Insets(ESPACAMENTO_LATERAL));
        root.getChildren().addAll(textoOriginal,textoTranslacao,textoRotacao,textoEscala,textoEsbatimento);

        Scene scene = new Scene(root, LARGURA, ALTURA);
        primaryStage.setTitle("Transições");
        primaryStage.setScene(scene);
        primaryStage.show();

        CreateTransicoes.Translacao(textoTranslacao).play();
        CreateTransicoes.Rotacao(textoRotacao).play();
        CreateTransicoes.Escala(textoEscala).play();
        CreateTransicoes.Esbatimento(textoEsbatimento).play();
   }

    /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * main() serves only as fallback in case the application can not be
     * launched through deployment artifacts, e.g., in IDEs with limited FX
     * support. NetBeans ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}
