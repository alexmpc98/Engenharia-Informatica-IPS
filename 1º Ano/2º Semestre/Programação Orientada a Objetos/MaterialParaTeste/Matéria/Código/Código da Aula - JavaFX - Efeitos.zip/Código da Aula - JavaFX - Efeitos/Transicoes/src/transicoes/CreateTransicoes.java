/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package transicoes;

import javafx.animation.FadeTransition;
import javafx.animation.RotateTransition;
import javafx.animation.ScaleTransition;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.util.Duration;

/**
 *
 * @author rcneves
 */
public class CreateTransicoes {

    private static final double DURACAO = 2000.0;

    public static TranslateTransition Translacao(Texto texto) {
        TranslateTransition transicao = new TranslateTransition(Duration.millis(DURACAO), texto);
        transicao.setByX(200.0);
        transicao.setCycleCount(Timeline.INDEFINITE);
        transicao.setAutoReverse(true);
        return transicao;
    }

    public static RotateTransition Rotacao(Texto texto) {
        RotateTransition transicao = new RotateTransition(Duration.millis(DURACAO), texto);
        transicao.setByAngle(90.0);
        transicao.setCycleCount(Timeline.INDEFINITE);
        transicao.setAutoReverse(true);
        return transicao;
    }

    public static ScaleTransition Escala(Texto texto) {
        ScaleTransition transicao = new ScaleTransition(Duration.millis(DURACAO), texto);
        transicao.setByX(2.0);
        transicao.setByY(2.0);
        transicao.setCycleCount(Timeline.INDEFINITE);
        transicao.setAutoReverse(true);
        return transicao;
    }

    public static FadeTransition Esbatimento(Texto texto) {
        FadeTransition transicao = new FadeTransition(Duration.millis(DURACAO), texto);
        transicao.setFromValue(1.0);
        transicao.setToValue(0.1);
        transicao.setCycleCount(Timeline.INDEFINITE);
        transicao.setAutoReverse(true);
        return transicao;
    }
}
