/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package efeitos;

import javafx.scene.effect.Reflection;

/**
 *
 * @author rcneves
 */
public class Reflexao extends Reflection {

    public Reflexao() {
        setFraction(0.7);
    }
}
