/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package efeitos;

import javafx.scene.effect.DropShadow;
import javafx.scene.paint.Color;

/**
 *
 * @author rcneves
 */
public class Sombra extends DropShadow {

    public Sombra() {
        setRadius(2.0);
        setOffsetX(5.0);
        setOffsetY(5.0);
        setColor(Color.GREY);

    }
}
