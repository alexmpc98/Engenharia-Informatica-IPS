/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rotacao;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author rcneves
 */
public class Rotacao extends Application {

    private static final double LARGURA = 300.0;
    private static final double ALTURA = 250.0;
    private static final double TAMANHO_FONTE = 60.0;
    private static final double AVANCO = 15.0;

    @Override
    public void start(Stage primaryStage) {
        final Text texto = new Text("JavaFX!");
        texto.setFill(Color.STEELBLUE);
        texto.setFont(Font.font(null, FontWeight.BOLD, TAMANHO_FONTE));
        
        StackPane root = new StackPane();
        root.getChildren().add(texto);

        Scene scene = new Scene(root, LARGURA, ALTURA);
        scene.setOnMouseClicked(
            e -> texto.setRotate(texto.getRotate() + AVANCO)
        );
        primaryStage.setTitle("Rotação");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * main() serves only as fallback in case the application can not be
     * launched through deployment artifacts, e.g., in IDEs with limited FX
     * support. NetBeans ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}
