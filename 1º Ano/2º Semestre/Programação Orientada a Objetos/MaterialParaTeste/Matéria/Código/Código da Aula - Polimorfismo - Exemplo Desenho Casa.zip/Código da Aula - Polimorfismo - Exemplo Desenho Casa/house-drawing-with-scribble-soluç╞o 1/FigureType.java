
/**
 * Enumeration class TipoFigura - write a description of the enum class here
 * 
 * @author (IPOO)
 * @version (2016-12-10)
 */
public enum FigureType
{
    TRIANGLE, CIRCLE, RECTANGLE, SQUARE
}
