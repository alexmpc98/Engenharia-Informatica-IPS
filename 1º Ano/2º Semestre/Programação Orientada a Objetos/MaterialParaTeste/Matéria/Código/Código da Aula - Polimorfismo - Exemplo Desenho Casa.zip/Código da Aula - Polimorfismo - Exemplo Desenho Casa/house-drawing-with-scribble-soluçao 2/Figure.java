 

/**
 * Escreva a descrição da classe Figure aqui.
 *
 * @author (seu nome)
 * @version (número de versão ou data)
 */
public class Figure {

    private FigureType type;
    private Pen pen;
    private Position position;
    private Color color;
    private int height;
    private int width;
    private int radius;

    public Figure(Pen pen) {
        this.pen = pen;
        type = FigureType.NONE;
        position = new Position();
    }

    public FigureType getTipo() {
        return type;
    }

    public void setCor(Color color) {
        this.color = color;
    }

    public Color getColor() {
        return color;
    }

    public void setCircle(Position position, int radius) {
        type = FigureType.CIRCLE;
        this.position = position;
        this.radius = radius;
    }

    public void setSquare(Position position, int side) {
        type = FigureType.SQUARE;
        this.position = position;
        this.width = side;
        this.height = side;
    }

    public void setRectangle(Position position, int width, int height) {
        type = FigureType.RECTANGLE;
        this.position = position;
        this.width = width;
        this.height = height;
    }

    public void setTriangle(Position position, int base, int height) {
        type = FigureType.TRIANGLE;
        this.position = position;
        this.width = base;
        this.height = height;
    }

    public void draw() {
        if (position == null || type == FigureType.NONE || pen == null) {
            return;
        }

        pen.penUp();
        pen.moveTo(position.getX(), position.getY());
        pen.setColor(color);
        pen.penDown();

        switch (type) {
            case CIRCLE:
                drawCircle();
                break;
            case TRIANGLE:
                drawTriangle();
                break;
            case RECTANGLE:
                drawRectangle();
                break;
            case SQUARE:
                drawSquare();
                break;
        }
    }

    private void drawSquare() {
        for (int i = 0; i < 4; i++) {
            pen.move(width);
            pen.turn(90);
        }
    }

    private void drawCircle() {

        int sides = 50;
        int side = (int) (2 * Math.PI * radius / sides);

        for (int i = 0; i < sides + 1; i++) {
            pen.move(side);
            pen.turn((int) (360.0 / sides));
        }
    }

    private void drawRectangle() {
        pen.move(width);
        pen.turn(90);
        pen.move(height);
        pen.turn(90);
        pen.move(width);
        pen.turn(90);
        pen.move(height);
        pen.turn(90);
    }

    private void drawTriangle() {
        int x = position.getX();
        int y = position.getY();

        pen.moveTo(x + (width / 2), y - height);
        pen.moveTo(x + width, y);
        pen.moveTo(x, y);
    }

}
