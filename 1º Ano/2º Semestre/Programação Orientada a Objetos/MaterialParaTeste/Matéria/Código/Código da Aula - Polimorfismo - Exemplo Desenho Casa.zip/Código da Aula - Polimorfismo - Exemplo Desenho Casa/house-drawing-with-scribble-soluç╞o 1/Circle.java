
/**
 * Write a description of class circle here.
 * 
 * @author (IPOO) 
 * @version (2016-12-10)
 */
public class Circle
{
    private Pen pen;
    private Color color;
    private Position position;
    private int radius;

    public Circle(Pen pen,Color color,Position position, int radius)
    {
        this.pen = pen;
        this.color = color;
        this.position = position;
        this.radius = radius;
    }

    public void draw() {
        pen.setColor(color);
        pen.penUp();
        pen.moveTo(position.getX(),position.getY());
        pen.penDown();
        pen.turnTo(0);
        
        int sides = 50;
        int side = (int)(2*Math.PI*radius/sides);     
        for(int i=0; i<sides+1; i++) {
            pen.move(side);
            pen.turn((int)(360.0/sides));
        }    
    }

    // restante código
}
