/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 

/**
 *
 * @author Jose
 */
public class Program {

    public static void main(String[] args) {

        Canvas canvas = new Canvas("Casa", 500, 300, Color.WHITE);
        Pen pen = new Pen(0, 0, canvas);
        Drawing drawing = new Drawing();

        Square wall = new Square(120, new Position(170, 140), pen, Color.RED);
        Square window = new Square(40, new Position(190, 160), pen, Color.BLACK);
        Triangle roof = new Triangle(180, 80, new Position(140, 138), pen, Color.GREEN);
        Circle sun = new Circle(40, new Position(360, 40), pen, Color.YELLOW);

        drawing.addFigure(wall);
        drawing.addFigure(window);
        drawing.addFigure(roof);
        drawing.addFigure(sun);

        drawing.draw();
    }
}
