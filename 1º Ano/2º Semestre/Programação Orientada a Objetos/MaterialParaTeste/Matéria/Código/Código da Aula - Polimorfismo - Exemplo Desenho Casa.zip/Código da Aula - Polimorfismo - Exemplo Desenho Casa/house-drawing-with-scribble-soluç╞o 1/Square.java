
/**
 * Write a description of class Square here.
 * 
 * @author (IPOO) 
 * @version (2016-12-10)
 */
public class Square
{
    private Pen pen;
    private Color color;
    private Position position;
    private int side;

    public Square(Pen pen,Color color,Position position, int side)
    {
        this.pen = pen;
        this.color = color;
        this.position = position;
        this.side = side;
    }

    public void draw() {
        pen.setColor(color);
        pen.penUp();
        pen.moveTo(position.getX(),position.getY());
        pen.penDown();
        pen.turnTo(0);
        
        for(int i=0; i<4; i++) {
            pen.move(side);
            pen.turn(90);
        }
    }

    // restante código
}
