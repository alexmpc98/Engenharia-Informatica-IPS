 

/**
 * Escreva a descrição da classe Circle aqui.
 *
 * @author (seu nome)
 * @version (número de versão ou data)
 */
public class Circle extends Figure {

    private int radius;

    public Circle() {
        this.radius = 1;
    }

    public Circle(int radius) {
        this.radius = radius;
    }

    public Circle(int radius, Position position, Pen pen, Color color) {
        super(position, pen, color);
        this.radius = radius;
    }

    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }

    public void setCentre(Position position) {
        setPosition(position);

    }

    public Position getCentre() {
        return getPosition();
    }	

    public double getArea() {
        return Math.PI * radius * radius;
    }

    public double getPerimeter() {
        return 2 * Math.PI * radius;
    }

    @Override
    public void draw() {
        Pen pen = getPen();
        pen.setColor(getColor());
        pen.penUp();
        pen.moveTo(getX(),getY());
        pen.penDown();
        pen.turnTo(0);
        
        int sides = 50;
        int side = (int) (2 * Math.PI * radius / sides);

        for (int i = 0; i < sides + 1; i++) {
            pen.move(side);
            pen.turn((int) (360.0 / sides));
        }
    }
}
