
/**
 * Escreva a descrição da classe Posicao aqui.
 * 
 * @author (IPOO) 
 * @version (2016-12-10)
 */
public class Position
{
    private int x;
    private int y;

    /**
     * Construtor para objetos da classe Position
     */
    public Position()
    {
        // inicializa variáveis de instância
        x = 0;
        y = 0;
    }
    
    public Position(int x, int y)
    {
        // inicializa variáveis de instância
        this.x = x;
        this.y = y;
    }


    public int getX()
    {
        return x;
    }
    
    public int getY()
    {
        return y;
    }
    
    public void setX(int x)
    {
        this.x = x;
    }
    
    public void setY(int y)
    {
        this.y = y;
    }
}
