
/**
 * Write a description of class Rectangle here.
 * 
 * @author (IPOO) 
 * @version (2016-12-10)
 */
public class Rectangle
{
    private Pen pen;
    private Color Color;
    private Position position;
    private int height, width;

    public Rectangle(Pen pen,Color Color,Position position, int height,int width)
    {
        this.pen = pen;
        this.Color = Color;
        this.position = position;
        this.height = height;
        this.width = width;
    }
    
    public void draw() {
        pen.setColor(Color);
        pen.penUp();
        pen.moveTo(position.getX(),position.getY());
        pen.penDown();
        pen.turnTo(0);
        pen.move(width);
        pen.turn(90);
        pen.move(height);
        pen.turn(90);
        pen.move(width);
        pen.turn(90);
        pen.move(height);
        pen.turn(90);
    }  

    // restante código
}
