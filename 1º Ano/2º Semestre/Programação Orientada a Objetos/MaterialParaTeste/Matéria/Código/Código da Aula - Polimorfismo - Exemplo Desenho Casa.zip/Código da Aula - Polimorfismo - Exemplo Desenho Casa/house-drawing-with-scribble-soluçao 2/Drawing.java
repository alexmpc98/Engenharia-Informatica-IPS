 

import java.util.ArrayList;

/**
 * Escreva a descrição da classe Drawing aqui.
 *
 * @author (seu nome)
 * @version (número de versão ou data)
 */
public class Drawing {

    private ArrayList<Figure> figures;

    /**
     * COnstrutor para objetos da classe Desenho
     */
    public Drawing() {
        figures = new ArrayList<>();
    }

    public void addFigure(Figure figure) {
        if (figure != null) {
            figures.add(figure);
        }
    }

    public void draw() {
        for (Figure figure : figures) {
            figure.draw();
        }
    }
}
