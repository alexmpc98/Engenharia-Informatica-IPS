
/**
 * Escreva a descrição da classe Figura aqui.
 * 
 * @author (IPOO) 
 * @version (2016-12-10)
 */
public class Figure
{
    private FigureType figureType;
    private Square square;
    private Rectangle rectangle;
    private Triangle triangle;
    private Circle circle;

    public Figure(FigureType figureType,Pen pen,Color color,Position position,int dimension) {
        this.figureType = figureType;
        if (figureType == FigureType.CIRCLE) {
            circle = new Circle(pen,color,position, dimension);
        } else {
            square = new Square(pen,color,position, dimension);
        }
    }

    public Figure(FigureType figureType,Pen pen,Color color,Position position,int height,int width) {
        this.figureType = figureType;
        if (figureType == FigureType.TRIANGLE) {
            triangle = new Triangle(pen,color,position, height, width);
        } else {
            rectangle = new Rectangle(pen,color,position, height, width);
        }
    }

    public void draw() 
    {
        switch(figureType) {
            case CIRCLE:
            circle.draw();
            break;
            case TRIANGLE:
            triangle.draw();
            break;
            case RECTANGLE:
            rectangle.draw();
            break;
            case SQUARE:
            square.draw();
            break;
        }        
    }
}
