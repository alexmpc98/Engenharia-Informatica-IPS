
/**
 * Write a description of class Triangle here.
 * 
 * @author (IPOO) 
 * @version (2011-21-10)
 */
public class Triangle
{
    private Pen pen;
    private Color color;
    private Position position;
    private int height, width;

    public Triangle(Pen pen,Color color,Position position, int height,int width)
    {
        this.pen = pen;
        this.color = color;
        this.position = position;
        this.height = height;
        this.width = width;
    }

    public void draw() {
        int x = position.getX();
        int y = position.getY();
        pen.setColor(color);
        pen.penUp();
        pen.moveTo(x,y);
        pen.penDown();
        pen.turnTo(0);
        
        pen.moveTo( x+(width/2), y-height  );
        pen.moveTo( x+width, y);
        pen.moveTo( x, y);            
    }

    // restante código
}
