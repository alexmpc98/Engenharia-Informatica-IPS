
/**
 * Escreva a descrição da classe Programa aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class Program
{

    public void run()
    {
        Canvas canvas = new Canvas("House", 500, 300, Color.WHITE);
        Pen pen = new Pen(0, 0, canvas);
        Drawing drawing = new Drawing();

        drawing.addFigure(new Figure(FigureType.SQUARE,pen,Color.RED,new Position(170, 140), 120));
        drawing.addFigure(new Figure(FigureType.SQUARE,pen,Color.BLACK,new Position(190, 160), 40));
        drawing.addFigure(new Figure(FigureType.TRIANGLE,pen,Color.GREEN,new Position(140, 138), 80, 180));
        drawing.addFigure(new Figure(FigureType.CIRCLE,pen,Color.YELLOW,new Position(360, 40), 40));
        drawing.draw();

    }

    public static void main() 
    {
        Canvas canvas = new Canvas("House", 500, 300, Color.WHITE);
        Pen pen = new Pen(0, 0, canvas);
        Drawing drawing = new Drawing();

        Figure wall = new Figure(FigureType.SQUARE,pen,Color.RED,new Position(170, 140), 120);
        Figure window = new Figure(FigureType.SQUARE,pen,Color.BLACK,new Position(190, 160), 40);
        Figure roof = new Figure(FigureType.TRIANGLE,pen,Color.GREEN,new Position(140, 138), 80, 180);
        Figure sun = new Figure(FigureType.CIRCLE,pen,Color.YELLOW,new Position(360, 40), 40);

        drawing.addFigure(wall);
        drawing.addFigure(window);
        drawing.addFigure(roof);
        drawing.addFigure(sun);

        drawing.draw();

    }
}
