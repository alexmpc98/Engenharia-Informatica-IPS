import java.util.ArrayList;

/**
 * Escreva a descrição da classe Drawing aqui.
 * 
 * @author (IPOO) 
 * @version (2016-12-10)
 */
public class Drawing
{
    private ArrayList<Figure> figures;

    /**
     * Construtor para objetos da classe Drawing
     */
    public Drawing()
    {
        figures = new ArrayList<>();
    }
    
    public void addFigure(Figure figure) 
    {
        if(figure != null) {
            figures.add(figure);
        }
    }
    
    public void draw() {
        for(Figure figure : figures ) {
            figure.draw();
        }
    }
}
