 

/**
 * Escreva a descrição da classe Program aqui.
 *
 * @author (seu nome)
 * @version (número de versão ou data)
 */
public class Program {

    public void run() {
        Canvas canvas = new Canvas("House", 500, 300, Color.WHITE);
        Pen pen = new Pen(0, 0, canvas);
        Drawing drawing = new Drawing();

        Figure wall = new Figure(pen);
        wall.setCor(Color.RED);
        wall.setSquare(new Position(170, 140), 120);
        drawing.addFigure(wall);

        Figure window = new Figure(pen);
        window.setCor(Color.BLACK);
        window.setSquare(new Position(190, 160), 40);
        drawing.addFigure(window);

        Figure roof = new Figure(pen);
        roof.setCor(Color.GREEN);
        roof.setTriangle(new Position(110, 80), 180, 60);
        drawing.addFigure(roof);

        Figure sun = new Figure(pen);
        sun.setCor(Color.YELLOW);
        sun.setCircle(new Position(330, 50), 40);
        drawing.addFigure(sun);

        drawing.draw();

    }

    public static void main() {
        Canvas canvas = new Canvas("House", 500, 300, Color.WHITE);
        Pen pen = new Pen(0, 0, canvas);
        Drawing drawing = new Drawing();

        Figure wall = new Figure(pen);
        wall.setCor(Color.RED);
        wall.setSquare(new Position(170, 140), 120);
        drawing.addFigure(wall);

        Figure window = new Figure(pen);
        window.setCor(Color.BLACK);
        window.setSquare(new Position(190, 160), 40);
        drawing.addFigure(window);

        Figure roof = new Figure(pen);
        roof.setCor(Color.GREEN);
        roof.setTriangle(new Position(140, 138), 180, 60);
        drawing.addFigure(roof);

        Figure sun = new Figure(pen);
        sun.setCor(Color.YELLOW);
        sun.setCircle(new Position(360, 50), 40);
        drawing.addFigure(sun);

        drawing.draw();

    }
}
