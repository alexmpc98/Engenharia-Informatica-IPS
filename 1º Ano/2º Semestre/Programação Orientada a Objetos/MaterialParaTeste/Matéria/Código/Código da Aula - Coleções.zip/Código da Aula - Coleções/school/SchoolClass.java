/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Jose
 */
public class SchoolClass {

    private Map<Integer, Student> students;
    private String name;

    public SchoolClass(String name) {
        this.name = name;
        students = new HashMap<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void add(Student student) {
        students.put(student.getNumber(), student);
    }

    public Student get(int number) {
        return students.get(number);
    }

    public Student remove(int numero) {
        return students.remove(numero);
    }

    public boolean isEnrolled(int number) {
        return students.containsKey(number);
    }

    @Override
    public String toString() {
        String list = name + ":";
        for (Student student : students.values()) {
            list += "\n" + student;
        }
        return list;
    }

}
