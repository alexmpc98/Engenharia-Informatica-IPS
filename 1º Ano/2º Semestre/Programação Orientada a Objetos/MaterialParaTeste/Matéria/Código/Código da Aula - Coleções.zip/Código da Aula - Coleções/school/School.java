/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 

/**
 *
 * @author Jose
 */
public class School {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SchoolClass schoolClass = new SchoolClass("Turma da LEI");
        schoolClass.add(new Student("Rita"));   //Fica com nº 1
        schoolClass.add(new Student("Manuel")); //Fica com nº 2
        schoolClass.add(new Student("Anibal")); //Fica com nº 3
        schoolClass.add(new Student("Maria"));  //Fica com nº 4
        System.out.println(schoolClass);
        Grade grades = new Grade();
        grades.put(schoolClass.get(1), 12); //Rita
        grades.put(schoolClass.get(2), 14); //Manuel
        grades.put(schoolClass.get(3), 8);  //Anibal
        grades.put(schoolClass.get(4), 17); //Maria
        grades.put(schoolClass.get(3), 11); //Recurso do Anibal
        System.out.println(grades);

    }
    
}
