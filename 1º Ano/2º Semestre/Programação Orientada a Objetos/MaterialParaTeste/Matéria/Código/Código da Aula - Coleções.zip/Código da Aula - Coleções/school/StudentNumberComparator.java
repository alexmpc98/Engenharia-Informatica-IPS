/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Comparator;

/**
 *
 * @author Jose
 */
public class StudentNumberComparator implements Comparator<Student> {

    @Override
    public int compare(Student student1, Student student2) {
        return student1.getNumber() - student2.getNumber();
    }
}
