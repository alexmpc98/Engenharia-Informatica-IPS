/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package collectionsexamples;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author Jose-MSI
 */
public class CollectionsExamples {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        System.out.println("Demo ArrayList");
        arrayListDemo();

        System.out.println("\n\nDemo LinkedList");
        linkedListDemo();

        System.out.println("\n\nDemo Iterator");
        iteratorDemo();

        System.out.println("\n\nDemo Hashset");
        hashSetDemo();

        System.out.println("\n\nDemo HashMap");
        hashMapDemo();
        

    }

    private static void hashMapDemo() {
        Map<Integer, String> namesMap = new HashMap<>();
        namesMap.put(13, "Maria");
        namesMap.put(43, "Manuel");
        namesMap.put(37, "Marco");
        namesMap.put(23, "Maria"); //Valor repetido
        namesMap.put(43, "Manuel Matos"); // Chave repetida, 
        // substitui valor anterior
        printMap(namesMap); //Mostrar no ecrã
    }

    public static void printMap(Map<Integer, String> map) {
        System.out.println("Pessoas:");
        for (Integer i : map.keySet()) {
            System.out.println("" + i + " - " + map.get(i));
        }
        
        System.out.println("\n\nPessoas:");
        for (String name : map.values()) {
            System.out.println(name);
        }

        System.out.println("\n\nPessoas:");
        for (Map.Entry pair : map.entrySet()) {
            System.out.println("" + pair.getKey() + " - " + pair.getValue());
        }

    }
    private static void hashSetDemo() {
        System.out.println("*** HashSet professores");
        Set<String> teachers = new HashSet<>();
        teachers.add("Ana");
        teachers.add("Joao");
        for (String s : teachers) {
            System.out.println(s);
        }
        Set<String> students = new HashSet<>();
        students.add("Joao");
        students.add("Luis");
        System.out.println("***** HashSet alunos");
        for (String s : students) {
            System.out.println(s);
        }
        Set<String> persons = new HashSet<>(teachers);
        persons.addAll(students);
        System.out.println("******* HashSet pessoas = professores + alunos");
        for (String s : persons) {
            System.out.println(s);
        }
        teachers = new HashSet<>(persons);
        teachers.removeAll(students);
        System.out.println("********* HashSet professores = pessoas - alunos");
        for (String s : teachers) {
            System.out.println(s);
        }
    }

    private static void iteratorDemo() {
        List<String> stringList = new ArrayList<>();

        System.out.println("Com while:");
        stringList = fillList(stringList);
        Iterator<String> s1 = stringList.iterator();
        while (s1.hasNext()) {
            System.out.println(s1.next());
            s1.remove();
        }

        System.out.println("\nCom do-while:");
        stringList = fillList(stringList);
        Iterator<String> s2 = stringList.iterator();
        if (s2.hasNext()) {
            do {
                System.out.println(s2.next());
                s2.remove();
            } while (s2.hasNext());
        }

        System.out.println("\nCom for:");
        stringList = fillList(stringList);
        Iterator<String> s3 = stringList.iterator();
        for (int i = 0; i < stringList.size(); i++) {
            if (s3.hasNext()) {
                System.out.println(s3.next());
                s3.remove();
            }
        }

        System.out.println("\n\n\n");
    }

    public static List<String> fillList(List<String> list) {
        list.add("IPOO");
        list.add("POO");
        list.add("PV");
        list.add("POO");
        list.add("POO");
        return list;
    }

    private static void linkedListDemo() {
        LinkedList<Integer> list = new LinkedList<>();
        for (int val = 0; val < 10; val++) {
            list.add(new Integer(val));
        }

        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).intValue() == 5) {
                list.remove(i);
            }
        }

        for (int i = 0; i < list.size(); i++) {
            System.out.println("> " + list.get(i));
        }
    }

    private static void arrayListDemo() {
        ArrayList<String> list = new ArrayList<>();

        list.add("IPOO");
        list.add("POO");
        list.add("POO");
        list.add("PV");

        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).equals("POO")) {
                list.remove(i);
            }
        }

        for (int i = 0; i < list.size(); i++) {
            System.out.println("> " + list.get(i));
        }
    }
}
