/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author Jose
 */
public class Grade extends HashMap<Student, Integer> {

    @Override
    public String toString() {
        List<Student> students = new ArrayList<>(keySet());
        Collections.sort(students);
        //Collections.sort(students, new StudentNumberComparator());

        String grades = "Notas:";
        for (Student student : students ) {//students) {
            grades += "\n" + student + ": " + get(student);
        }
        return grades;
    }

}
