/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Jose
 */
public class Student implements Comparable<Student> {

    private static int nextNumber = 1;
    private int number;
    private String name;

    public Student(String name) {
        this.number = Student.nextNumber++;
        this.name = name;
    }

    public int getNumber() {
        return number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int hashCode() {
        //return number;
        Integer number = new Integer(this.number);
        return number.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        return this.number == ((Student) obj).number;
    }

    @Override
    public String toString() {
        return number + " - " + name;
    }

    @Override
    public int compareTo(Student student) {
        return name.compareTo(student.name);
    }
}
