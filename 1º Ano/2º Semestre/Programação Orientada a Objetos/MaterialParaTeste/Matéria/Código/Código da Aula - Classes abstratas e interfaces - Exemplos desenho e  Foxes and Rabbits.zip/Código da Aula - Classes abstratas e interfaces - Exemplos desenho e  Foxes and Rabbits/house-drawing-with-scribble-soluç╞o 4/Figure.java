 

/**
 * Escreva a descrição da classe Figure aqui.
 *
 * @author (seu nome)
 * @version (número de versão ou data)
 */
public abstract class Figure {

    private Pen pen;
    private Position position;
    private Color color;

//    public Figure() {
//        pen = new Pen();
//        position = new Position();
//        color = Color.BLACK;
//    }
//    public Figure(Pen pen, Color color) {
//        if (pen != null) {
//            this.pen = pen;
//        } else {
//            this.pen = new Pen();
//        }
//        position = new Position();
//        if (color != null) {
//            this.color = color;
//        } else {
//            this.color = Color.BLACK;
//        }
//    }
    public Figure() {
        this(new Position(), new Pen(), Color.BLACK);
    }

    public Figure(Pen pen, Color color) {
        this(new Position(), pen, color);
    }

    public Figure(Position position, Pen pen, Color color) {

        this.pen = (pen != null) ? pen : new Pen();

        this.position = (position != null) ? new Position(position.getX(), position.getY()) : new Position();

        this.color = (color != null) ? color : Color.BLACK;

    }

    public void setColor(Color color) {
        if (color != null) {
            this.color = color;
        }
    }

    public Color getColor() {
        return color;
    }

    public Pen getPen() {
        return pen;
    }

    public int getX() {
        return position.getX();
    }

    public int getY() {
        return position.getY();
    }

    public void setX(int x) {
        position.setX(x);
    }

    public void setY(int y) {
        position.setY(y);
    }

    public abstract void draw();

    public Position getPosition() {
        return new Position(position.getX(), position.getY());
    }

    public void setPosition(Position position) {
        if (position != null) {
            this.position = new Position(position.getX(), position.getY());
        }
    }
}
