 

/**
 * Enumeration class Colors - write a description of the enum class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public enum Color {

    BLUE, BLACK, CYAN, GRAY, GREEN, DARK_GRAY, LIGHT_GRAY, MAGENTA, ORANGE, PINK, RED, WHITE, YELLOW
}
