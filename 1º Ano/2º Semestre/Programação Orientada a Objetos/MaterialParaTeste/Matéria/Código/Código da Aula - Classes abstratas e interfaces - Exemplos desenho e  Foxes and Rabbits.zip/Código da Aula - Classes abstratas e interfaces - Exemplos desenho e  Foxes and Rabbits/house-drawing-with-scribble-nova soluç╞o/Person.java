
/**
 * Escreva a descrição da classe Person aqui.
 *
 * @author (seu nome)
 * @version (número de versão ou data)
 */
public class Person implements Drawable {

    private int height;
    private int width;
    private Position position;
    private Color color;
    private Pen pen;

    /**
     * COnstrutor para objetos da classe Person
     */
    public Person() {
        this(new Pen());
    }

    public Person(Pen pen) {
        height = 60;
        width = 30;
        position = new Position(280, 190);
        color = Color.BLACK;
        this.pen = (pen != null) ? pen : new Pen();
    }

    public void setSize(int height, int width) {
        this.height = height;
        this.width = width;
    }

    public void setColor(Color color) {
        if (color != null) {
            this.color = color;
        }
    }

    public Color getColor() {
        return color;
    }

    public int getX() {
        return position.getX();
    }

    public int getY() {
        return position.getY();
    }

    public void setX(int x) {
        position.setX(x);
    }

    public void setY(int y) {
        position.setY(y);
    }

    public Position getPosition() {
        return new Position(position.getX(), position.getY());
    }

    public void setPosition(Position position) {
        if (position != null) {
            this.position = new Position(position.getX(), position.getY());
        }
    }

    public void draw() {
        int bh = (int) (height * 0.7);  
        int hh = (height - bh) / 2;  
        int hw = width / 2;  
        int x = position.getX();
        int y = position.getY();

        int[] xpoints = {x - 3, x - hw, x - hw, x - (int) (hw * 0.2) - 1, x - (int) (hw * 0.2) - 1, x - hw,
            x - hw + (int) (hw * 0.4) + 1, x, x + hw - (int) (hw * 0.4) - 1, x + hw, x + (int) (hw * 0.2) + 1,
            x + (int) (hw * 0.2) + 1, x + hw, x + hw, x + 3, x + (int) (hw * 0.6),
            x + (int) (hw * 0.6), x + 3, x - 3, x - (int) (hw * 0.6), x - (int) (hw * 0.6)};
        int[] ypoints = {y, y + (int) (bh * 0.2), y + (int) (bh * 0.4), y + (int) (bh * 0.2),
            y + (int) (bh * 0.5), y + bh, y + bh, y + (int) (bh * 0.65), y + bh, y + bh,
            y + (int) (bh * 0.5), y + (int) (bh * 0.2), y + (int) (bh * 0.4), y + (int) (bh * 0.2),
            y, y - hh + 3, y - hh - 3, y - hh - hh, y - hh - hh, y - hh - 3, y - hh + 3};

        pen.penUp();
        pen.setColor(color);
        pen.moveTo(xpoints[0], ypoints[0]);
        pen.penDown();

        for (int i = 1; i < xpoints.length; i++) {
            pen.moveTo(xpoints[i], ypoints[i]);
        }
        pen.moveTo(xpoints[0], ypoints[0]);

    }
}
