 

/**
 * Escreva a descrição da classe Square aqui.
 *
 * @author (seu nome)
 * @version (número de versão ou data)
 */
public class Square extends Figure {

    private int side;

    public Square() {
        this.side = 1;
    }

    public Square(int side) {
        this.side = side;
    }

    public Square(int side, Position position, Pen pen, Color color) {
        super(position, pen, color);
        this.side = side;
    }

    public int getSide() {
        return side;
    }

    public void setSide(int side) {
        this.side = side;
    }

    @Override
    public void draw() {
        Pen pen = getPen();
        pen.setColor(getColor());
        pen.penUp();
        pen.moveTo(getX(),getY());
        pen.penDown();
        pen.turnTo(0);   
        
        for (int i = 0; i < 4; i++) {
            pen.move(side);
            pen.turn(90);
        }
    }

    public double getArea() {
        return side * side;
    }

    public double getPerimeter() {
        return 4 * side;
    }
}
