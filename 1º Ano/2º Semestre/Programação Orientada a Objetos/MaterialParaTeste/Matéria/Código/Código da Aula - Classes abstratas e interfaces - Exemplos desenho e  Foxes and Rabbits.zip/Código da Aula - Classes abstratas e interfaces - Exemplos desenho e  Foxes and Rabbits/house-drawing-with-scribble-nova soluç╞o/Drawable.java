
/**
 * Escreva a descrição da interface Drawable aqui.
 * 
 * @author (seu nome) 
 * @version (número da versão ou data)
 */

public interface Drawable
{
    public void draw();
}
