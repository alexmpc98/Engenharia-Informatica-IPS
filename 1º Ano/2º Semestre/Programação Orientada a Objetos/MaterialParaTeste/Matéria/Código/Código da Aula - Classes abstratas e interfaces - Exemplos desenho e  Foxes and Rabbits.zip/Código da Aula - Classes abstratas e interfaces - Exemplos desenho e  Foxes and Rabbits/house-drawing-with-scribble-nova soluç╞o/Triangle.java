 

/**
 * Escreva a descrição da classe Triangle aqui.
 *
 * @author (seu nome)
 * @version (número de versão ou data)
 */
public class Triangle extends Figure {

    private int width;
    private int height;

    public Triangle() {
        width = 1;
        height = 2;
    }

    public Triangle(int width, int height) {
        this.width = width;
        this.height = height;
    }

    public Triangle(int width, int height, Position position, Pen pen, Color color) {
        super(position, pen, color);
        this.width = width;
        this.height = height;
    }

    @Override
    public void draw() {
        int x = getX();
        int y = getY();

        Pen pen = getPen();
        pen.setColor(getColor());
        pen.penUp();
        pen.moveTo(x, y);
        pen.penDown();
        pen.turnTo(0);

        pen.moveTo(x + (width / 2), y - height);
        pen.moveTo(x + width, y);
        pen.moveTo(x, y);
    }

    public double getArea() {
        return width * height / 2;
    }
}
