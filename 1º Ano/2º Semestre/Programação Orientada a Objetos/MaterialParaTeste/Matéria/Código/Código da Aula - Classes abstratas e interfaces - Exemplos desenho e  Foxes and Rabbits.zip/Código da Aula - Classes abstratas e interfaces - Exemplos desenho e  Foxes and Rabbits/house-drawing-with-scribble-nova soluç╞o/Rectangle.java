 

/**
 * Escreva a descrição da classe Rectangle aqui.
 *
 * @author (seu nome)
 * @version (número de versão ou data)
 */
public class Rectangle extends Figure {

    private int width;
    private int height;

    public Rectangle() {
        this.width = 2;
        this.height = 1;
    }

    public Rectangle(int width, int height) {
        this.width = width;
        this.height = height;
    }

    public Rectangle(int width, int height, Position position, Pen pen, Color color) {
        super(position, pen, color);
        this.width = width;
        this.height = height;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    @Override
    public void draw() {
        Pen pen = getPen();
        pen.setColor(getColor());
        pen.penUp();
        pen.moveTo(getX(),getY());
        pen.penDown();
        pen.turnTo(0);

        pen.move(width);
        pen.turn(90);
        pen.move(height);
        pen.turn(90);
        pen.move(width);
        pen.turn(90);
        pen.move(height);
        pen.turn(90);
    }

    public double getArea() {
        return width * height;
    }

    public double getPerimeter() {
        return 2 * width + 2 * height;
    }
}
