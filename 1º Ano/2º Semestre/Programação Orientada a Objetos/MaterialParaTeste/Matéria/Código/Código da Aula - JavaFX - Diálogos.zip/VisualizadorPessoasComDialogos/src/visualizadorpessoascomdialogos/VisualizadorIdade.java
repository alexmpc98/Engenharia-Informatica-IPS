/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visualizadorpessoascomdialogos;

import java.text.NumberFormat;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;

/**
 *
 * @author rcneves
 */
public class VisualizadorIdade extends HBox {

    private final SliderIdade idadeSlider;
    private final TextField idadeCampo;

    public VisualizadorIdade() {
        idadeSlider = new SliderIdade();
        idadeCampo = new TextField();
        idadeCampo.setPrefWidth(50);
        idadeCampo.textProperty().bindBidirectional(idadeSlider.valueProperty(), NumberFormat.getIntegerInstance());
        setSpacing(10);
        getChildren().addAll(idadeSlider, idadeCampo);
    }

    public double getValue() {
        return idadeSlider.getValue();
    }

    public void setValue(double idade) {
        idadeSlider.setValue(idade);
    }
}
