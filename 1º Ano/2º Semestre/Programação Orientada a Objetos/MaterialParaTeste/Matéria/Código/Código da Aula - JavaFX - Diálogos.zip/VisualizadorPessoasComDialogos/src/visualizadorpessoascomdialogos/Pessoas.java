/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visualizadorpessoascomdialogos;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashSet;

/**
 *
 * @author Jose-MSI
 */
public class Pessoas extends HashSet<Pessoa> implements Serializable {

    private static final String NOME_FICHEIRO = "pessoas.dat";

    @Override
    public boolean add(Pessoa pessoa) {
        System.out.println("Adicionei: " + pessoa);
        return super.add(pessoa);
    }

    @Override
    public boolean remove(Object pessoa) {
        System.out.println("Removi: " + pessoa);
        return super.remove(pessoa);
    }

    public void gravarPessoas() {
        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(NOME_FICHEIRO));
            oos.writeObject(this);
            oos.flush();
            oos.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public static Pessoas lerPessoas() {
        Pessoas pessoas;
        try {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream(NOME_FICHEIRO));
            pessoas = (Pessoas) ois.readObject();
            ois.close();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println(e.getMessage());
            pessoas = new Pessoas();
        }
        return pessoas;
    }
}