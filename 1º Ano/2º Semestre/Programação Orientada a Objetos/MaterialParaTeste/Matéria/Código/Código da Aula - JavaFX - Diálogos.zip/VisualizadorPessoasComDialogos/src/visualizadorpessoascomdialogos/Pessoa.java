/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visualizadorpessoascomdialogos;

import java.io.Serializable;

/**
 *
 * @author Jose-MSI
 */
public class Pessoa implements Serializable {

    private static final int IDADE_MINIMA = 0;
    private static final int IDADE_MAXIMA = 120;
    private String nome;
    private int idade;

    protected static boolean nomeValido(String nome) {
        return (nome != null && !nome.isEmpty());
    }

    protected static boolean idadeValida(int idade) {
        return ((idade >= IDADE_MINIMA)
                && (idade <= IDADE_MAXIMA));
    }

    public Pessoa(String nome, int idade) {
        if (!nomeValido(nome)) {
            throw new IllegalArgumentException("O nome da pessoa não é válido!");
        }
        if (!idadeValida(idade)) {
            throw new IllegalArgumentException("A idade da pessoa não é válida!");
        }
        this.nome = nome;
        this.idade = idade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        if (nomeValido(nome)) {
            this.nome = nome;
        }
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        if (idadeValida(idade)) {
            this.idade = idade;
        }
    }

    public static int getIdadeMinima() {
        return IDADE_MINIMA;
    }

    public static int getIdadeMaxima() {
        return IDADE_MAXIMA;
    }

    @Override
    public String toString() {
        return getNome() + " (" + getIdade() + " anos)";
    }
}
