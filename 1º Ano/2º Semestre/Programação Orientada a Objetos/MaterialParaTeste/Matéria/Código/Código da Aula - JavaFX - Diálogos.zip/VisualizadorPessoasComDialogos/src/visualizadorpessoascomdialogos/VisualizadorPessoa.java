/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visualizadorpessoascomdialogos;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

/**
 *
 * @author Jose-MSI
 */
public class VisualizadorPessoa extends Dialog<Pessoa> {

    public VisualizadorPessoa(final Pessoa pessoa) {

        GridPane gridPessoa = new GridPane();

        //Criar os nós
        Label nomeRotulo = new Label("Nome");
        final TextField nomeCampo = new TextField();
        nomeCampo.setPrefWidth(200);
        Label idadeRotulo = new Label("Idade");        
        final VisualizadorIdade idadeSlider = new VisualizadorIdade();
        
        setTitle("Criar Pessoa");
        if (pessoa != null) {
            setTitle("Editar Pessoa");
            nomeCampo.setText(pessoa.getNome());
            idadeSlider.setValue(pessoa.getIdade());
        }

        //Posicionar os nós
        gridPessoa.setPadding(new Insets(10));
        gridPessoa.setVgap(10);
        gridPessoa.setHgap(10);
        gridPessoa.add(nomeRotulo, 0, 0);
        gridPessoa.add(nomeCampo, 1, 0);
        gridPessoa.add(idadeRotulo, 0, 1);
        gridPessoa.add(idadeSlider, 1, 1);

        getDialogPane().setContent(gridPessoa);

        //Botão aceitar
        getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        setResultConverter(button -> {
            if (button == ButtonType.OK) {
                if (pessoa == null) { //Criar
                    try {
                        return new Pessoa(nomeCampo.getText(), (int) idadeSlider.getValue());
                    } catch (Exception ex) {
                        return null;
                    }
                } else { //Atualizar
                    pessoa.setNome(nomeCampo.getText());
                    pessoa.setIdade((int) idadeSlider.getValue());
                    return pessoa;
                }
            }
            return null;
        });
    }
}
