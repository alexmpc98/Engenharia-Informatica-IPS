/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visualizadorpessoascomdialogos;

import javafx.scene.control.Slider;

/**
 *
 * @author Jose-MSI
 */
public class SliderIdade extends Slider {

    public SliderIdade() {
        setMin(Pessoa.getIdadeMinima());
        setMax(Pessoa.getIdadeMaxima());
        setShowTickLabels(true);
        setShowTickMarks(true);
        setMajorTickUnit(10);
    }
}

