/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dialogos;

import java.util.Optional;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Callback;

/**
 *
 * @author Jose-MSI
 */
public class ExemploDialogo extends Application {

    private Text estado;

    public static void main(String[] args) {

        Application.launch(args);
    }

    @Override
    public void start(Stage primaryStage) {

        primaryStage.setTitle("Exemplo Dialog");

        // Título
        Label lblTitulo = new Label("Um Diálogo");
        lblTitulo.setTextFill(Color.DARKBLUE);
        lblTitulo.setFont(Font.font("Calibri", FontWeight.BOLD, 36));
        HBox hbTitulo = new HBox();
        hbTitulo.setAlignment(Pos.CENTER);
        hbTitulo.getChildren().add(lblTitulo);

        // Botão
        Button btnMostrarDialogo = new Button("Prima para mostrar o diálogo");
        btnMostrarDialogo.setOnAction(e -> mostrarDialogo());
        HBox hbMostrarDialogo = new HBox(10);
        hbMostrarDialogo.setAlignment(Pos.CENTER);
        hbMostrarDialogo.getChildren().addAll(btnMostrarDialogo);

        // Mensagem de estado
        estado = new Text();
        estado.setFont(Font.font("Calibri", FontWeight.NORMAL, 20));
        estado.setFill(Color.FIREBRICK);

        // Painel Principal
        VBox root = new VBox(30);
        root.setPadding(new Insets(25, 25, 25, 25));;
        root.getChildren().addAll(hbTitulo, hbMostrarDialogo, estado);

        // Scene
        Scene scene = new Scene(root, 500, 250); // w x h
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void mostrarDialogo() {

        estado.setText("");

        // Dialog Personalizado
        Dialog<Contacto> dialog = new Dialog<>();
        dialog.setTitle("Introduzir Dados");
        dialog.setHeaderText("Isto é um diálogo. Introduza o nome e o telefone e \n"
                + "prima Ok (or prima o 'X' da barra da janela para cancelar).");
        dialog.setResizable(true);

        // Widgets
        Label lblNome = new Label("Nome: ");
        Label lblTelefone = new Label("Telefone: ");
        TextField txtNome = new TextField();
        TextField txtTelefone = new TextField();

        // Criar o layou e adicioná-lo ao diálogo
        GridPane painelDados = new GridPane();
        painelDados.setAlignment(Pos.CENTER);
        painelDados.setHgap(10);
        painelDados.setVgap(10);
        painelDados.setPadding(new Insets(20, 35, 20, 35));
        painelDados.add(lblNome, 1, 1); // col=1, row=1
        painelDados.add(txtNome, 2, 1);
        painelDados.add(lblTelefone, 1, 2); // col=1, row=2
        painelDados.add(txtTelefone, 2, 2);
        dialog.getDialogPane().setContent(painelDados);

        // Adicionar o botão ao diálogo
        ButtonType btnOk = new ButtonType("Ok", ButtonData.OK_DONE);
        ButtonType btnCancel = new ButtonType("Cancel", ButtonData.CANCEL_CLOSE);
        
        dialog.getDialogPane().getButtonTypes().addAll(btnOk, btnCancel);

        // Conversor do resultado para o diálogo
        dialog.setResultConverter(new Callback<ButtonType, Contacto>() {
            @Override
            public Contacto call(ButtonType btn) {

                if (btn == btnOk) {

                    return new Contacto(txtNome.getText(), txtTelefone.getText());
                }

                return null;
            }
        });

        // Mostrar o diálogo
        Optional<Contacto> resultado = dialog.showAndWait();

        if (resultado.isPresent()) {

            estado.setText("Resultado: " + resultado.get());
        }
    }

    private class Contacto {

        private String nome;
        private String telefone;

        Contacto(String nome, String telefone) {

            this.nome = nome;
            this.telefone = telefone;
        }

        @Override
        public String toString() {

            return (nome + ", " + telefone);
        }
    }
}
