/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dialogos;

import java.util.Optional;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author Jose-MSI
 */
public class ExemploAlertaConfirmacao extends Application {

    private Text estado;
    private TextField txtNumero;

    @Override
    public void start(Stage primaryStage) {
        // Receber número
        Label lblNumero = new Label("Número:");
        lblNumero.setFont(Font.font("Calibri", FontWeight.NORMAL, 20));
        txtNumero = new TextField();
        txtNumero.setMinHeight(30.0);
        txtNumero.setPromptText("Introduza o número de aluno");
        txtNumero.setPrefColumnCount(15);
        HBox hbNumero = new HBox();
        hbNumero.setSpacing(10);
        hbNumero.getChildren().addAll(lblNumero, txtNumero);

        // Botões
        Button btnGuardar = new Button("Guardar");
        btnGuardar.setOnAction(e -> {
            if (!verificarNumero()) {
                mostrarErro();
            } else {
                confirmarGravacao();
            }
        });
        HBox hbBotoes = new HBox(10);
        Button btnLimpar = new Button("Limpar");
        btnLimpar.setOnAction(e -> limpar());
        hbBotoes.setAlignment(Pos.CENTER);
        hbBotoes.getChildren().addAll(btnGuardar, btnLimpar);

        // Mensagem de estado
        estado = new Text();
        estado.setFont(Font.font("Calibri", FontWeight.NORMAL, 20));
        estado.setFill(Color.FIREBRICK);

        // Painel principal
        VBox root = new VBox(30);
        root.setPadding(new Insets(25, 25, 25, 25));;
        root.getChildren().addAll(hbNumero, hbBotoes, estado);

        Scene scene = new Scene(root, 400, 230);

        primaryStage.setTitle("Diálogos de Alerta");
        primaryStage.setScene(scene);
        primaryStage.show();

        // Inicial
        estado.setText("Exemplo de Alertas de erro e confirmação. \nIntroduza um número de aluno e guarde-o");
        btnGuardar.requestFocus();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    private boolean verificarNumero() {
        String numero = txtNumero.getText().trim();

        if (numero.isEmpty() || numero.length() != 9) {
            return false;
        }

        if (numero.chars().anyMatch(c -> !Character.isDigit(c))) {
            return false;
        }

        return true;
    }

    private void mostrarErro() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Erro no número");
        alert.setHeaderText("Erro");
        String s = "O número deve ter 9 algarismos. "
                + "\nIntroduza um número válido e guarde-o. ";
        alert.setContentText(s);

        alert.showAndWait();
        estado.setText("Foi introduzido um número inválido");
    }

    private void limpar() {
        txtNumero.setText("");
        estado.setText("Introduza um número de aluno");
    }

    private void confirmarGravacao() {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Confirmar Número");
        alert.setHeaderText("Confirmação");
        String s = "Confirma a gravação do número?";
        alert.setContentText(s);

        Optional<ButtonType> resultado = alert.showAndWait();

        if ((resultado.isPresent()) && (resultado.get() == ButtonType.OK)) {
            estado.setText("Número aceite: " + txtNumero.getText());
            txtNumero.setText("");
        }
        else
            estado.setText("Introduza um número de aluno.");
    }
}
