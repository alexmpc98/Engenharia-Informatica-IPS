/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dialogos;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author Jose-MSI
 */
public class ExemploChoiceDialog extends Application {

    private ChoiceDialog<String> dialogo;
    private final String[] arrayDados = {"Primeiro", "Segundo", "Terceiro", "Quarto"};
    private List<String> dadosDialogo;
    private Text estado;

    public static void main(String[] args) {

        Application.launch(args);
    }

    @Override
    public void start(Stage primaryStage) {

        primaryStage.setTitle("Exemplo ChoiceDialog");

        // Título 
        Label lblTitulo = new Label("Choice Dialog");
        lblTitulo.setTextFill(Color.DARKBLUE);
        lblTitulo.setFont(Font.font("Calibri", FontWeight.BOLD, 36));
        HBox hbTitulo = new HBox();
        hbTitulo.setAlignment(Pos.CENTER);
        hbTitulo.getChildren().add(lblTitulo);

        // Botão
        Button btnEscolha = new Button("Escolher opção");
        btnEscolha.setOnAction(e -> escolherOpcao());
        HBox hbBotao = new HBox(10);
        hbBotao.setAlignment(Pos.CENTER);
        hbBotao.getChildren().addAll(btnEscolha);

        // Status message text
        estado = new Text();
        estado.setFont(Font.font("Calibri", FontWeight.NORMAL, 20));
        estado.setFill(Color.FIREBRICK);

        // Painel principal
        VBox root = new VBox(30);
        root.setPadding(new Insets(25, 25, 25, 25));;
        root.getChildren().addAll(hbTitulo, hbBotao, estado);

        // Scene
        Scene scene = new Scene(root, 500, 250); // w x h
        primaryStage.setScene(scene);
        primaryStage.show();

        // Initial dialog
        dadosDialogo = Arrays.asList(arrayDados);
        escolherOpcao();
    }

    private void escolherOpcao() {
        estado.setText("");

        dialogo = new ChoiceDialog<String>(dadosDialogo.get(0), dadosDialogo);
        dialogo.setTitle("Escolher opção");
        dialogo.setHeaderText("Escolha uma opção");

        Optional<String> resultado = dialogo.showAndWait();
        String selecionado = "cancelado.";

        if (resultado.isPresent()) {

            selecionado = resultado.get();
        }
        estado.setText("Seleção: " + selecionado);
    }
}
