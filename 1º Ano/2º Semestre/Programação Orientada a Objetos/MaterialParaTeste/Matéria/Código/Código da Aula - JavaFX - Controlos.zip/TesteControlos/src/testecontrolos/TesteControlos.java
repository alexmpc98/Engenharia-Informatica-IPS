/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package testecontrolos;

import java.awt.event.MouseEvent;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author rcneves
 */
public class TesteControlos extends Application {

    private ObservableList<String> items;
    private ListView<String> listaNomes;
    private TextField textFieldNome;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Exemplo Controls");
        VBox root = new VBox();
        adicionarPanelTexto(root);
        adicionarPanelList(root);
        primaryStage.setScene(new Scene(root, 400, 300));
        primaryStage.show();
    }

    public void adicionarPanelTexto(Pane root) {

        HBox painelTexto = new HBox();
        painelTexto.setPadding(new Insets(10));
        painelTexto.setSpacing(10);

        Label labelNome = new Label("Nome");

        this.textFieldNome = new TextField();
        this.textFieldNome.setMinSize(12, 10);

        Button botaoOk = new Button("OK");
        botaoOk.setOnAction(e -> adicionarNomeLista());

        painelTexto.getChildren().addAll(labelNome, this.textFieldNome, botaoOk);
        root.getChildren().add(painelTexto);
    }

    public void adicionarPanelList(Pane root) {
        VBox painelList = new VBox();
        painelList.setPadding(new Insets(10));
        painelList.setSpacing(10);

        Label labelNomes = new Label("Lista Pessoas");

        this.items = FXCollections.observableArrayList();
        this.listaNomes = new ListView<>();
        this.listaNomes.setPrefSize(100, 120);
        this.listaNomes.setItems(items);

        Button btnDelete = new Button("Delete");
        //btnDelete.setOnAction(e -> retirarNomeLista());

        painelList.getChildren().addAll(labelNomes, this.listaNomes, btnDelete);
        root.getChildren().add(painelList);
    }

    public void adicionarNomeLista() {
        String nome = this.textFieldNome.getText();
        if (!nome.isEmpty()) {
            this.items.add(nome);
        }
        this.textFieldNome.setText("");
    }

    public void retirarNomeLista() {
        int index;
        index = this.listaNomes.getSelectionModel().getSelectedIndex();
        if (index != -1) {
            this.items.remove(index);
        }
    }

    /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * main() serves only as fallback in case the application can not be
     * launched through deployment artifacts, e.g., in IDEs with limited FX
     * support. NetBeans ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}
