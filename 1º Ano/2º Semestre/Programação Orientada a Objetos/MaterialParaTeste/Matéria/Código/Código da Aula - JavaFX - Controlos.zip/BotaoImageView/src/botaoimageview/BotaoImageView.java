/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package botaoimageview;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author rcneves
 */
public class BotaoImageView extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Botão Imagem");
        Image imageOk = new Image (getClass().getResourceAsStream(
                "icons/ok.png"), 40, 40, false, false);
        ImageView img = new ImageView(imageOk);
        img.setOnMouseClicked(e -> System.out.println("OK"));
//        Button btn = new Button("", new ImageView(imageOk));
//        btn.setOnMouseClicked(e -> System.out.println("OK"));
        StackPane root = new StackPane();
        root.getChildren().add(img);
        Scene scene = new Scene(root, 300, 250);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * main() serves only as fallback in case the application can not be
     * launched through deployment artifacts, e.g., in IDEs with limited FX
     * support. NetBeans ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}
