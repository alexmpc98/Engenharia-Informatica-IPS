/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplocanvas;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

/**
 *
 * @author rcneves
 */
public class ExemploCanvas extends Application {

    @Override
    public void start(Stage primaryStage) {
        HBox root = new HBox();
        SeletorFormaCor seletorFormaCor = new SeletorFormaCor();
        root.getChildren().addAll(seletorFormaCor, new AreaDesenho(seletorFormaCor));
        primaryStage.setTitle("Formas");
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }

    /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * main() serves only as fallback in case the application can not be
     * launched through deployment artifacts, e.g., in IDEs with limited FX
     * support. NetBeans ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
