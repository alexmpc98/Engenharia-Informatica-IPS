/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplocanvas;

import javafx.collections.FXCollections;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

/**
 *
 * @author rcneves
 */
public class SeletorFormaCor extends VBox {

    private static final double ESPACAMENTO = 10.0;
    private static final double LARGURA_LISTA = 130.0;
    private static final double ALTURA_LISTA = 150.0;
    private static final String[] NOMES_CORES = {"Aqua", "Black", "Blue", "Fuchsia", "Gray", "Green", "Lime", "Maroon", "Navy", "Olive", "Orange", "Purple", "Red", "Silver", "Teal", "White", "Yellow"};
    private ListView<Forma> formas;
    private ListView<String> cores;

    public SeletorFormaCor() {
        Label rotuloFormas = new Label("Escolha uma Forma:");
        Label rotuloCores = new Label("Escolha uma Cor:");
        formas = criarListView(Forma.values());
        cores = criarListView(SeletorFormaCor.NOMES_CORES);
        getChildren().addAll(rotuloFormas,formas,rotuloCores, cores);
        setSpacing(SeletorFormaCor.ESPACAMENTO);
    }

    private <T> ListView<T> criarListView(T[] valores)
    {
        ListView<T> result = new ListView<>();
        result.setItems(FXCollections.observableArrayList(valores));
        result.getSelectionModel().select(0);
        result.setPrefWidth(SeletorFormaCor.LARGURA_LISTA);
        result.setPrefHeight(SeletorFormaCor.ALTURA_LISTA);
        return result;
    }
    
    public Forma formaEscolhida() {
        return formas.getSelectionModel().getSelectedItem();
    }
    
    public Color corEscolhida() {
        String nomeCor = cores.getSelectionModel().getSelectedItem();
        return Color.valueOf(nomeCor);
    }

}
