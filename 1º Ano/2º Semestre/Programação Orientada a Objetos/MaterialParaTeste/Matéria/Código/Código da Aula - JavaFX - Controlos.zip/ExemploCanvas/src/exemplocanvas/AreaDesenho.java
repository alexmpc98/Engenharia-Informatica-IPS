/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplocanvas;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

/**
 *
 * @author rcneves
 */
public class AreaDesenho extends Canvas {

    private static final double LARGURA = 600;
    private static final double ALTURA = 400;

    private SeletorFormaCor seletorFormaCor;
    private double xInicial;
    private double yInicial;

    public AreaDesenho(SeletorFormaCor seletorFormaCor) {
        super(AreaDesenho.LARGURA, AreaDesenho.ALTURA);
        this.seletorFormaCor = seletorFormaCor;
        setOnMousePressed(this::fixarInicio);
        setOnMouseReleased(this::desenharForma);
    }

    private void fixarInicio(MouseEvent event) {
        xInicial = event.getX();
        yInicial = event.getY();
    }

    private void desenharForma(MouseEvent event) {
        double xFinal = event.getX();
        double yFinal = event.getY();
        double x = Math.min(xInicial, xFinal);
        double y = Math.min(yInicial, yFinal);
        double largura = Math.abs(xFinal - xInicial);
        double altura = Math.abs(yFinal - yInicial);
        GraphicsContext graphicsContext = getGraphicsContext2D();
        Color corEscolhida = seletorFormaCor.corEscolhida();
        graphicsContext.setFill(corEscolhida);
        graphicsContext.setStroke(corEscolhida);
        seletorFormaCor.formaEscolhida().desenharForma(graphicsContext, x, y, largura, altura);
    }

}
