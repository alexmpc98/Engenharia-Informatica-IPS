/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplocanvas;

import javafx.scene.canvas.GraphicsContext;

/**
 *
 * @author rcneves
 */
public enum Forma {

    Oval, Retangulo, RetArredondado, Cruz;
//Foi quebrada a norma de escrita em MAIÚSCULAS para não
//rescrever o toString para ficar "bonitinho" 

    private static final double ARREDONDAMENTO = 5; //RetArredondado

    public void desenharForma(GraphicsContext graphicsContext, double x, double y, double largura, double altura) {
        switch (this) {
            case Oval:
                graphicsContext.fillOval(x, y, largura, altura);
                break;
            case Retangulo:
                graphicsContext.fillRect(x, y, largura, altura);
                break;
            case RetArredondado:
                graphicsContext.fillRoundRect(x, y, largura, altura, largura / Forma.ARREDONDAMENTO, altura / Forma.ARREDONDAMENTO);
                break;
            case Cruz:
                graphicsContext.strokeLine(x + largura / 2, y, x + largura / 2, y + altura);
                graphicsContext.strokeLine(x, y + altura / 2, x + largura, y + altura / 2);
                break;
        }
    }
}
