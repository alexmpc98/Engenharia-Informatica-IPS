/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Chess2;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Jose
 */
public class Chessboard2 {

    HashMap<Position, Piece> positions;

    public Chessboard2() {
        positions = new HashMap<>();
        setup();
    }

    private void setup() {
        for (char x = 'a'; x <= 'h'; x++) {
            for (int y = 1; y <= 8; y++) {
                Position position = new Position(x, y);
                Piece piece;
                Colour colour = Colour.WHITE;
                if (y == 1 || y == 2) {
                    colour = Colour.WHITE;
                } else if (y == 7 || y == 8) {
                    colour = Colour.BLACK;
                }
                if (y == 2 || y == 7) {
                    piece = new Piece(PieceType.PAWN, colour, position);
                    positions.put(position, piece);
                } else if (y == 1 || y == 8) {
                    switch (x) {
                        case 'a':
                        case 'h':
                            piece = new Piece(PieceType.ROOK, colour, position);
                            break;
                        case 'b':
                        case 'g':
                            piece = new Piece(PieceType.KNIGHT, colour, position);
                            break;
                        case 'c':
                        case 'f':
                            piece = new Piece(PieceType.BISHOP, colour, position);
                            break;
                        case 'd':
                            piece = new Piece(PieceType.QUEEN, colour, position);
                            break;
                        case 'e':
                            piece = new Piece(PieceType.KING, colour, position);
                            break;
                        default:
                            piece = null;
                            break;
                    }
                    positions.put(position, piece);
                } else {
                    positions.put(position, null);
                }
            }
        }
    }

}
