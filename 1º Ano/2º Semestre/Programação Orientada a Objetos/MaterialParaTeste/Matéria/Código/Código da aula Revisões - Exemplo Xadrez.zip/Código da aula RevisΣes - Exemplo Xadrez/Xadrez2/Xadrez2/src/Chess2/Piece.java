/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Chess2;

/**
 *
 * @author jc
 */
public class Piece {

    private Colour colour;
    private Position position;
    private PieceType pieceType;

    public Piece(PieceType pieceType, Colour colour, Position position) {
        this.pieceType = pieceType;
        this.colour = colour;
        if (position != null) {
            this.position = position;
        } else {
            this.position = new Position();
        }
    }

    public Colour getColour() {
        return colour;
    }

    public PieceType getPieceType() {
        return pieceType;
    }

    public void setPieceType(PieceType pieceType) {
        this.pieceType = pieceType;
    }

    
    public Position getPosition() {
        return new Position(position.getX(), position.getY());
    }

    public void setPosition(char x, int y) {
        position.setX(x);
        position.setY(y);
    }

    public void setPosition(Position position) {
        this.position.setX(position.getX());
        this.position.setY(position.getY());
    }

    public void setY(int y) {
        position.setY(y);
    }

    public char getX() {
        return position.getX();
    }

    public int getY() {
        return position.getY();
    }

    @Override
    public String toString() {
        String text = "";
        switch(pieceType){
            case ROOK:
                text += 'T';
                break;
            case KNIGHT:
                text += 'C';
                break;
            case BISHOP:
                text += 'B';
                break;
            case QUEEN:
                text += 'D';
                break;
            case KING:
                text += 'R';
                break;
        }
        text += position.toString();
        return text;
    }

    public String getName() {
        return pieceType.toString();
    }
}
