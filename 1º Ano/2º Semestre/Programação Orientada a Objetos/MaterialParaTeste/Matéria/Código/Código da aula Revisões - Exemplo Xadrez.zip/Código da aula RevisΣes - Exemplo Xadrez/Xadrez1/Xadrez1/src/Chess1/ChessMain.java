/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Chess1;

/**
 *
 * @author rcneves
 */
public class ChessMain {

    public static void main(String[] args) {


        Position pos1 = new Position('e', 7); //posicao x e y
        Position pos2 = new Position();

        System.out.println("Posicao: " + pos1);
        System.out.println("Posicao: " + pos2.getX() + pos2.getY());
       
        Pawn p1 = new Pawn(Colour.BLACK, new Position('e', 7));
        Pawn p2 = new Pawn(Colour.WHITE, new Position());
        p2.setPosition('d', 2);
        
        System.out.println("Peão 1 - " + p1);
        System.out.println("Peão 2 - " + p2);
        
        System.out.print("Peão 1 - ");
        System.out.print(p1.getName() + " na posicao: ");
        System.out.println("" + p1.getX() + p1.getY());

        System.out.print("Peão 2 - ");
        System.out.print(p2.getName() + " na posicao: ");
        System.out.println("" + p2.getX() + p2.getY());

        Rook r1 = new Rook(Colour.WHITE, pos2);
        
        System.out.println("Torre - " + r1);
        
        System.out.print("Torre - ");
        System.out.print(r1.getName() + " na posicao: ");
        System.out.println("" + r1.getX() + r1.getY());
    }
}
