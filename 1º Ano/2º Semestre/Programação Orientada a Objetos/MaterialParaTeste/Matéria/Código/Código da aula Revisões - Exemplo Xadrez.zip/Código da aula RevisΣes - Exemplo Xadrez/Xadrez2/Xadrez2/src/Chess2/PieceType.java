/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Chess2;

/**
 *
 * @author Jose
 */
public enum PieceType {

    PAWN, ROOK, KNIGHT, BISHOP, KING, QUEEN;

    @Override
    public String toString() {
        switch (this) {
            case PAWN:
                return "Peão";
            case ROOK:
                return "Torre";
            case KNIGHT:
                return "Cavalo";
            case BISHOP:
                return "Bispo";
            case QUEEN:
                return "Rainha";
            case KING:
                return "Rei";
        }
        return "";
    }
}
