/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Chess2;

import java.util.ArrayList;

/**
 *
 * @author Jose
 */
public class Chessboard {

    ArrayList<Piece> pieces;

    public Chessboard() {
        pieces = new ArrayList<>();
        setup();
    }

    private void setup() {
        for (char x = 'a'; x <= 'h'; x++) {
            pieces.add(new Piece(PieceType.PAWN, Colour.WHITE, new Position(x, 2)));
            pieces.add(new Piece(PieceType.PAWN, Colour.BLACK, new Position(x, 7)));
        }
        int line = 1;
        Colour colour = Colour.WHITE;
        pieces.add(new Piece(PieceType.ROOK, colour, new Position('a', line)));
        pieces.add(new Piece(PieceType.KNIGHT, colour, new Position('b', line)));
        pieces.add(new Piece(PieceType.BISHOP, colour, new Position('c', line)));
        pieces.add(new Piece(PieceType.QUEEN, colour, new Position('d', line)));
        pieces.add(new Piece(PieceType.KING, colour, new Position('e', line)));
        pieces.add(new Piece(PieceType.BISHOP, colour, new Position('f', line)));
        pieces.add(new Piece(PieceType.KNIGHT, colour, new Position('g', line)));
        pieces.add(new Piece(PieceType.ROOK, colour, new Position('h', line)));
        
        line = 8;
        colour = Colour.BLACK;
        pieces.add(new Piece(PieceType.ROOK, colour, new Position('a', line)));
        pieces.add(new Piece(PieceType.KNIGHT, colour, new Position('b', line)));
        pieces.add(new Piece(PieceType.BISHOP, colour, new Position('c', line)));
        pieces.add(new Piece(PieceType.QUEEN, colour, new Position('d', line)));
        pieces.add(new Piece(PieceType.KING, colour, new Position('e', line)));
        pieces.add(new Piece(PieceType.BISHOP, colour, new Position('f', line)));
        pieces.add(new Piece(PieceType.KNIGHT, colour, new Position('g', line)));
        pieces.add(new Piece(PieceType.ROOK, colour, new Position('h', line)));
    }
     

}
