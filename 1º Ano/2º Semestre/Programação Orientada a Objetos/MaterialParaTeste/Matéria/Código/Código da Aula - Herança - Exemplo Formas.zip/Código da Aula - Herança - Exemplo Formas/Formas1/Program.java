/**
 *
 * @author POO-2019-2020
 */
public class Program {

    public static void main(String[] args) {
        Circle circle = new Circle(1, 1, 23);
        Square square = new Square(0, 0, 4);

        System.out.println("Circulo: - Posição (" + circle.getX() +
                           "," + circle.getY() + 
                           ") – Raio: " + circle.getRadius() );

        System.out.println("Quadrado: - Posição (" + square.getX() +
                           "," + square.getY() +
                           ") – Lado: " + square.getSide() );

        square.moveBy( 2, 2);

        System.out.println("Quadrado: - Posição (" + square.getX() +
                           "," + square.getY() +
                           ") – Lado: " + square.getSide() );
    }
    
}
