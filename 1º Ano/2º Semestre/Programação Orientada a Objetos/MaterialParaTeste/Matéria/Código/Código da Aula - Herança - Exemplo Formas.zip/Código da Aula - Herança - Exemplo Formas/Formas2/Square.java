/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 

/**
 *
 * @author Jose-MSI
 */
public class Square extends Shape {

    private int side;

    public Square() {
        super(0, 0);
        this.side = 1;
    }

    public Square(int x, int y, int side) {
        super(x, y);
        this.side = side;
    }

    public int getSide() {
        return side;
    }

    public void setSide(int lado) {
        this.side = lado;
    }
}
