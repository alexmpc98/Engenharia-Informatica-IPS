/**
 *
 * @author POO-2019-2020
 */
public class Circle {

    private int x, y;    
    private int radius;   

    public Circle() { 
        this.x = 0;
        this.y = 0;
        this.radius = 1; 
    }

    public Circle(int x, int y, int radius) { 
        this.x = x;
        this.y = y;
        this.radius = radius; 
    }

    public int getRadius() { 	
        return radius;  
    }
	
    public void setRadius(int raio) {
       this.radius = raio;  
    }
    
    public int getX() { 
        return x; 
    }

    public void setX(int x) { 
        this.x = x; 
    } 

    public int getY() { 
        return y; 
    }
    
    public void setY(int y) { 
        this.y = y; 
    }

    public void moveBy( int dx, int dy ) {
        x += dx; y += dy; 
    }
}
