/**
 *
 * @author POO-2019-2020
 */
public class Square {

    private int x, y;    
    private int side;

    public Square() { 
        this.x = 0;
        this.y = 0;
        this.side = 1;     
    }

    public Square(int x, int y, int lado) { 
        this.x = x;
        this.y = y;
        this.side = lado; 
    }

    public int getSide() { 	
        return side;  
    }
	
    public void setSide(int side) {
        this.side = side;  
    }

    public int getX() { 
        return x; 
    }

    public void setX(int x) { 
        this.x = x; 
    } 

    public int getY() { 
        return y; 
    }
    
    public void setY(int y) { 
        this.y = y; 
    }

    public void moveBy( int dx, int dy ) {
        x += dx; y += dy; 
    }
}
