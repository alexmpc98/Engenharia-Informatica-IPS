/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package changingtextfonts;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author rcneves
 */
public class ChangingTextFonts extends Application {

    @Override
    public void start(Stage primaryStage) {
        Group root = new Group();
        Scene scene = new Scene(root, 700, 250);
        primaryStage.setTitle("Escrita de texto");
        primaryStage.setScene(scene);
        primaryStage.show();
        Text text1 = new Text(50, 50, "Font Serif RED");
        Font serif = Font.font("Serif", 30);
        text1.setFont(serif);
        text1.setFill(Color.RED);
        root.getChildren().add(text1);
        Text text2 = new Text(50, 100, "Font SanSerif BLUE");
        Font sanSerif = Font.font("SanSerif", 50);
        text2.setFont(sanSerif);
        text2.setFill(Color.BLUE);
        root.getChildren().add(text2);
        Text text3 = new Text(50, 200, "Font Monospaced BLACK");
        Font monoFont = Font.font("Monospaced", 70);
        text3.setFont(monoFont);
        text3.setFill(Color.BLACK);
        root.getChildren().add(text3);
    }

    /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * main() serves only as fallback in case the application can not be
     * launched through deployment artifacts, e.g., in IDEs with limited FX
     * support. NetBeans ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
