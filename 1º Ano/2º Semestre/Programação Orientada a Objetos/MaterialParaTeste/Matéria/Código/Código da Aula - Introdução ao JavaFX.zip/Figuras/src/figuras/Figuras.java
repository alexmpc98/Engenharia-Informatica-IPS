/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package figuras;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/**
 *
 * @author rcneves
 */
public class Figuras extends Application {

    @Override
    public void start(Stage primaryStage) {
        Group root = new Group();
        Circle circulo = new Circle(40, 50, 30, Color.AQUA);
        Rectangle retangulo = new Rectangle(100, 20, 70, 40);
        retangulo.setFill(Color.rgb(255, 165, 0));
        Line linha = new Line(30, 100, 80, 160);
        linha.setStroke(Color.BLUE);
        linha.setStrokeWidth(3);
        Polygon poligono = new Polygon(150, 100, 90, 160, 210, 160);
        poligono.setFill(Color.gray(0.5));
        root.getChildren().addAll(circulo, retangulo, linha, poligono);
        Scene scene = new Scene(root, 300, 250);
        primaryStage.setTitle("Figuras Geométricas");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * main() serves only as fallback in case the application can not be
     * launched through deployment artifacts, e.g., in IDEs with limited FX
     * support. NetBeans ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
