/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package premierleague;

import java.util.Objects;

/**
 *
 * @author Jose
 */
public class Player {

    private String name;
    private int number;
    private int age;

    private static final int MINIMUM_AGE = 16;

    public Player(String name, int age) {
        if (name != null) {
            this.name = name;
        } else {
            this.name = "";
        }
        if (age < MINIMUM_AGE) {
            this.age = MINIMUM_AGE;
        } else {
            this.age = age;
        }
        number = 0;
    }

    public String getName() {

        return name;
    }

    public void setName(String name) {
        if (name != null) {
            this.name = name;
        }
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        if (number > 0) {
            this.number = number;
        }
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age >= MINIMUM_AGE) {
            this.age = age;
        }
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Player other = (Player) obj;
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
        if (this.number != other.number) {
            return false;
        }
        return true;
    }

}
