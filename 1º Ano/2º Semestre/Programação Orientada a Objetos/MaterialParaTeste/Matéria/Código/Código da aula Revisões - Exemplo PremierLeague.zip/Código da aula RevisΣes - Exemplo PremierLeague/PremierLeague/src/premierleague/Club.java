/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package premierleague;

import java.util.Objects;
import java.util.Scanner;

/**
 *
 * @author Jose
 */
public class Club {

    private String name;
    private String city;

    public Club(String name, String city) {
        if (name == null || name.trim().equals("")) {
            this.name = "";
        } else {
            this.name = name;
        }

        this.city = city;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (!(name == null || name.trim().equals(""))) {
            this.name = name;
        }
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 53 * hash + Objects.hashCode(this.name);
        hash = 53 * hash + Objects.hashCode(this.city);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Club other = (Club) obj;
        return this.name.equals(other.name)
                && this.city.equals(other.city);
    }

}
