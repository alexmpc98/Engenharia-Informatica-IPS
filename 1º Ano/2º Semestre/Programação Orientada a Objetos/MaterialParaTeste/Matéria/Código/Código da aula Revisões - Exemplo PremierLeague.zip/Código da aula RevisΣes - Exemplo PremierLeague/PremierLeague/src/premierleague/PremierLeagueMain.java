/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package premierleague;

import java.util.ArrayList;
import java.util.HashSet;

/**
 *
 * @author Jose
 */
public class PremierLeagueMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        HashSet<Club> clubs = new HashSet<>();
            
        
        
        clubs.add(new Club("Chelsea", "London"));
        clubs.add(new Club("Chelsea", "London"));
        
        Club united = new Club("Manchester United", "Manchester");
        Club city = new Club("Manchester City", "Manchester");
        Club liverpool = new Club("Liverpool", "Liverpool");
       
        clubs.add(united);
        clubs.add(city);
        clubs.add(liverpool);
        
        PremierLeague league = new PremierLeague(clubs);
        
        System.out.println(league.clubsNames());
        
        league.addPlayer(new Player("player1", 1), liverpool);
        
        System.out.println(league.clubPlayers(liverpool));
        
        league.removePlayer(null);
        
        league.removePlayer(new Player("player1", 1));
        
        System.out.println(league.clubPlayers(liverpool));
        
        ArrayList<Player> players = new ArrayList<>();
        players.add(new Player("player1", 1));
        players.add(new Player("player2", 2));
        players.add(new Player("player3", 3));
        
        league.addPlayers("Manchester United", players);
        
        league.removeClub(new Club("Manchester United", "Manchester"));
        
        System.out.println("T->" + league.playersWithoutClub());
    }
    
}
