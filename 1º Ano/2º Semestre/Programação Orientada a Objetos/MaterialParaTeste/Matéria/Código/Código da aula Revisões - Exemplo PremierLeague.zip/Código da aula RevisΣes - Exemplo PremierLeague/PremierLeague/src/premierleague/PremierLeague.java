/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package premierleague;

import premierleague.Player;
import premierleague.Club;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 *
 * @author Jose
 */
public class PremierLeague {

    private HashSet<Club> clubs;
    private HashMap<Player, Club> players;

    public PremierLeague(HashSet<Club> clubs) {
        if (clubs != null) {
            this.clubs = new HashSet<>(clubs);
        } else {
            this.clubs = new HashSet();
        }
        players = new HashMap<>();
    }

    public boolean addPlayer(Player player, Club club) {
        if (!clubs.contains(club)) {
            return false;
        }

        if (players.get(player) != null) {
            return false;
        }

        players.put(player, club);
        return true;
    }

    public void removePlayer(Player player) {
        players.remove(player);
    }

    public String getClubName(Player player) {
        Club club = players.get(player);
        if (club != null) {
            return club.getName();
        }

        return "";
    }

    public void addClub(Club club) {
        if (club != null) {
            clubs.add(club);
        }
    }

    public HashSet<Player> getPlayers(Club club) {
        HashSet<Player> clubPlayers = new HashSet<>();

        for (Player player : players.keySet()) {
            if (players.get(player).equals(club)) {
                clubPlayers.add(player);
            }
        }

        return clubPlayers;
    }
    
    public HashSet<Player> getPlayersFunctional(Club club) {
        HashSet<Player> clubPlayers = new HashSet<>();

        players.keySet().stream()
                .filter(player -> players.get(player).equals(club))
                .forEach(player -> clubPlayers.add(player) );

        return clubPlayers;
    }

    public void removeClub(Club club) {
        if (club == null) {
            return;
        }
        clubs.remove(club);

        for (Player player : getPlayers(club)) {
            players.put(player, null);
        }
    }
    
    public void removeClubFunctional(Club club) {
        if (club == null) {
            return;
        }
        clubs.remove(club);

        getPlayers(club).stream()
                        .forEach(player -> players.put(player, null));
    }

    public String clubsNames() {
        String info = "Club List:";

        for (Club club : clubs) {
            info += "\n" + club.getName();
        }

        return info;
    }
    
    

    public String clubPlayers(Club club) {
        if (club == null || !clubs.contains(club)) {
            return "";
        }
        String info = "Players from " + club.getName();

        for (Map.Entry<Player, Club> entry : players.entrySet()) {
            if (entry.getValue().equals(club)) {
                info += "\n" + entry.getKey().getName();
            }
        }

        return info;
    }

    public void addPlayers(String clubName, ArrayList<Player> players) {

        for (Club club : clubs) {
            if (club.getName().equals(clubName)) {

                for (Player player : players) {
                    this.players.put(player, club);
                }
            }
        }
    }

    public ArrayList<Club> getClubsFromCity(String cityName) {
        ArrayList<Club> foundClubs = new ArrayList<>();

        for (Club club : clubs) {
            if (club.getCity().equals(cityName)) {
                foundClubs.add(club);
            }
        }

        return foundClubs;
    }

    public ArrayList<Player> getPlayersStartingWith(char firstLetter) {
        ArrayList<Player> foundPlayers = new ArrayList<>();

        players.keySet().stream()
                .filter(p -> p.getName().charAt(0) == firstLetter)
                .forEach(p -> foundPlayers.add(p));

        return foundPlayers;
    }
    
    public ArrayList<Player> getPlayers(String text) {
        ArrayList<Player> foundPlayers = new ArrayList<>();

        players.keySet().stream()
                .filter(p -> p.getName().contains(text))
                .forEach(p -> foundPlayers.add(p));

        return foundPlayers;
    }

    public int playersWithoutClub() {
        return players.entrySet().stream()
                .filter(pair -> pair.getValue() == null)
                .map(pair -> 1)
                .reduce(0, (runningSum, count) -> runningSum + 1);
    }
}
