/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FormasGeometricas;

import java.util.ArrayList;

/**
 *
 * @author rcneves
 */
public class Programa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        FormaGeometrica[] formas;
//        formas = new FormaGeometrica[6];
//        formas[0] = new Circulo(4, 8, 3);
//        formas[1] = new Circulo(28, 10, 4);
//        formas[2] = new Retangulo(3, 0, 5, 6);
//        formas[3] = new Retangulo(11, 0, 23, 6);
//        formas[4] = new Retangulo(18, 0, 21, 4);
//        formas[5] = new Quadrado(13, 2, 2);
//        double areaTotal = 0;
//
//        for (int i = 0; i < formas.length; i++) {
//            areaTotal += formas[i].getArea();
//        }
//        System.out.println("Area Total: " + areaTotal);

        ArrayList<FormaGeometrica> formas = new ArrayList<>();
        formas.add(new Circulo(4, 8, 3));
        formas.add(new Circulo(28, 10, 4));
        formas.add(new Retangulo(3, 0, 5, 6));
        formas.add(new Retangulo(11, 0, 23, 6));
        formas.add(new Retangulo(18, 0, 21, 4));
        formas.add(new Quadrado(13, 2, 2));
        double areaTotal = 0;

        for (FormaGeometrica forma : formas) {
            areaTotal += forma.getArea();
        }
        System.out.println("Area Total: " + areaTotal);

    }

}
