/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sequencial;

import javafx.animation.RotateTransition;
import javafx.animation.ScaleTransition;
import javafx.animation.SequentialTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 *
 * @author rcneves
 */
public class Sequencial extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Sequential Transition");
        Group root = new Group();
        Scene scene = new Scene(root, 500, 300);
        Rectangle rectangle = new Rectangle(100, 100, 50, 50);
        rectangle.setFill(Color.DARKBLUE);
        root.getChildren().add(rectangle);
        primaryStage.setScene(scene);
        primaryStage.show();

        RotateTransition animaRoda = new RotateTransition(
                Duration.seconds(3), rectangle);
        animaRoda.setByAngle(180f);
        animaRoda.setCycleCount(1);
        animaRoda.setAutoReverse(true);
        ScaleTransition animaTamanho = new ScaleTransition(
                Duration.seconds(2), rectangle);
        animaTamanho.setToX(2f);
        animaTamanho.setToY(2f);
        animaTamanho.setCycleCount(2);
        animaTamanho.setAutoReverse(true);
        SequentialTransition animaSequential = new SequentialTransition();
        animaSequential.getChildren().addAll(animaRoda, animaTamanho);
        animaSequential.setCycleCount(Timeline.INDEFINITE);
        animaSequential.setAutoReverse(true);
        animaSequential.play();
    }

    /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * main() serves only as fallback in case the application can not be
     * launched through deployment artifacts, e.g., in IDEs with limited FX
     * support. NetBeans ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
