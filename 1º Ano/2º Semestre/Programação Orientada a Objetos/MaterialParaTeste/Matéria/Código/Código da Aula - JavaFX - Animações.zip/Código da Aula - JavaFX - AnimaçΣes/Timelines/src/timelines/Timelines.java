/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package timelines;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 *
 * @author rcneves
 */
public class Timelines extends Application {

    @Override
    public void start(Stage primaryStage) {
        Rectangle retangulo = new Rectangle(100,50,100,50);
        retangulo.setFill(Color.RED);

        Group root = new Group();
        root.getChildren().add(retangulo);
        Scene scene = new Scene(root, 500, 200);

        primaryStage.setTitle("Timelines");
        primaryStage.setScene(scene);
        primaryStage.show();

        Timeline timeline = new Timeline();
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.setAutoReverse(true);

        KeyValue keyValue1 = new KeyValue(
                retangulo.xProperty(),
                300.0);

        KeyFrame keyFrame1 = new KeyFrame(
                Duration.millis(1000),
                keyValue1);

        KeyValue keyValue2 = new KeyValue(
                retangulo.heightProperty(),
                100.0);

        KeyFrame keyFrame2 = new KeyFrame(
                Duration.millis(2000),
                keyValue2);

        timeline.getKeyFrames().addAll(keyFrame1,keyFrame2);
        timeline.play();
    }

    /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * main() serves only as fallback in case the application can not be
     * launched through deployment artifacts, e.g., in IDEs with limited FX
     * support. NetBeans ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}
