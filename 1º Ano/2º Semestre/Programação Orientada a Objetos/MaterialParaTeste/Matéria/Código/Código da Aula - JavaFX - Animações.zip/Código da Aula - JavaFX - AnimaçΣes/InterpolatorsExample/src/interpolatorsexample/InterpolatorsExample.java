/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interpolatorsexample;

import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 *
 * @author rcneves
 */
public class InterpolatorsExample extends Application {

    @Override
    public void start(Stage primaryStage) {
        Rectangle ret1 = new Rectangle(100, 50, 100, 50);
        ret1.setFill(Color.RED);
        Timeline timeline1 = new Timeline();
        timeline1.setCycleCount(Timeline.INDEFINITE);
        timeline1.setAutoReverse(true);
        KeyValue keyValue1 = new KeyValue(
                ret1.xProperty(),
                300.0,
                Interpolator.LINEAR);
        KeyFrame keyFrame1 = new KeyFrame(
                Duration.millis(2000),
                keyValue1);
        timeline1.getKeyFrames().add(keyFrame1);

        Rectangle ret2 = new Rectangle(100, 150, 100, 50);
        ret2.setFill(Color.BROWN);
        Timeline timeline2 = new Timeline();
        timeline2.setCycleCount(Timeline.INDEFINITE);
        timeline2.setAutoReverse(true);
        KeyValue keyValue2 = new KeyValue(
                ret2.xProperty(),
                300.0,
                Interpolator.EASE_BOTH);
        KeyFrame keyFrame2 = new KeyFrame(
                Duration.millis(2000),
                keyValue2);
        timeline2.getKeyFrames().add(keyFrame2);

        Rectangle ret3 = new Rectangle(100, 250, 100, 50);
        ret3.setFill(Color.GREEN);
        Timeline timeline3 = new Timeline();
        timeline3.setCycleCount(Timeline.INDEFINITE);
        timeline3.setAutoReverse(true);
        KeyValue keyValue3 = new KeyValue(
                ret3.xProperty(),
                300.0,
                new InterpolatorAnima());
        KeyFrame keyFrame3 = new KeyFrame(
                Duration.millis(2000),
                keyValue3);
        timeline3.getKeyFrames().add(keyFrame3);

        Group root = new Group();
        root.getChildren().addAll(ret1, ret2, ret3);
        Scene scene = new Scene(root, 500, 400);
        primaryStage.setTitle("Interpolators");
        primaryStage.setScene(scene);
        primaryStage.show();

        timeline1.play();
        timeline2.play();
        timeline3.play();
    }

    /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * main() serves only as fallback in case the application can not be
     * launched through deployment artifacts, e.g., in IDEs with limited FX
     * support. NetBeans ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
