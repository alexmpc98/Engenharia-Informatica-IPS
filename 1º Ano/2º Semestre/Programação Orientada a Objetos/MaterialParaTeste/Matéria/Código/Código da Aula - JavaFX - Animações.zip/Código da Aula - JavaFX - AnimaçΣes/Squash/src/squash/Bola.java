/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package squash;

import java.util.Random;
import javafx.animation.TranslateTransition;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.RadialGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Circle;
import javafx.util.Duration;

/**
 *
 * @author rcneves
 */
public class Bola extends Circle {

    public static final int RAIO = 7;
    public static final int X_ORIGINAL = Jogo.LARGURA / 2;
    public static final int Y_ORIGINAL = Raquete.Y_ORIGINAL - Bola.RAIO;
    public static final int X_MIN = Jogo.PADDING + Bola.RAIO;
    public static final int X_MAX = Jogo.LARGURA - Jogo.PADDING - Bola.RAIO;
    public static final int Y_MIN = Jogo.PADDING + Bola.RAIO;
    public static final int Y_MAX = Raquete.Y_ORIGINAL - Bola.RAIO;
    public static final int LARGURA_DISPONIVEL = Bola.X_MAX - Bola.X_MIN;
    public static final int ALTURA_DISPONIVEL = Bola.Y_MAX - Bola.Y_MIN;
    public static final double VELOCIDADE = 3; //Quanto maior, mais lento
    private Random aleatorio;
    private boolean cimaParaBaixo;
    private boolean esquerdaParaDireita;
    private double tangenteAngulo;

    public Bola(final Jogo jogo) {
        //Definir características da bola:
        setRadius(Bola.RAIO);
        setCenterX(Bola.X_ORIGINAL);
        setCenterY(Bola.Y_ORIGINAL);
        setFill(gradienteBola());
        //Preparar a geração de números aleatórios:
        aleatorio = new Random();
    }

    private RadialGradient gradienteBola() {
        return new RadialGradient(
                0,
                0,
                0.3, //30%
                0.3, //30%
                0.6, //60%
                true, //as coordenadas anteriores são indicadas em [0,1], representando percentagens, em relação ao "contentor"
                CycleMethod.NO_CYCLE,
                new Stop(0, Color.WHITE),
                new Stop(1, Color.RED));
    }

    public void iniciarMover(Jogo jogo) {
        cimaParaBaixo = true;
        esquerdaParaDireita = aleatorio.nextBoolean();
        tangenteAngulo = Math.tan(aleatorio.nextDouble() * (Math.PI / 2.0));
        fazerTranslacao(jogo);
    }

    public void pararMover(Jogo jogo) {
        setTranslateX(0);
        setTranslateY(0);
        jogo.pararMoverBola();
        moverComRaquete(jogo.getRaquete());
    }

    public void moverComRaquete(Raquete raquete) {
        setCenterX(raquete.getMeioRaquete());
    }

    public int xAtual() {
        return (int) Math.round(getBoundsInParent().getMinX() + Bola.RAIO); //ou (int)Math.round(getBoundsInParent().getMaxX() - Bola.RAIO); 
    }

    public int yAtual() {
        return (int) Math.round(getBoundsInParent().getMinY() + Bola.RAIO); //ou (int)Math.round(getBoundsInParent().getMaxY() - Bola.RAIO); 
    }

    public boolean naLinhaDaRaquete() {
        return (yAtual() >= Bola.Y_MAX);
    }

    public boolean naMargemTopo() {
        return (yAtual() <= Bola.Y_MIN);
    }

    public boolean naMargemEsquerda() {
        return (xAtual() <= Bola.X_MIN);
    }

    public boolean naMargemDireita() {
        return (xAtual() >= Bola.X_MAX);
    }

    public void fazerTranslacao(final Jogo jogo) {
        //Determinar as distâncias a percorrer:
        int x = xAtual();
        int y = yAtual();
        double dX;
        double dY;
        /*
         //Algoritmo para movimentar a bola, apenas na vertical:
         dX = 0.0;
         if (naLinhaDaRaquete()) {
         dY = -ALTURA_DISPONIVEL;
         } else {
         dY = ALTURA_DISPONIVEL;
         }
         */
        //Algoritmo para movimentar a bola:
        if (naLinhaDaRaquete()) {
            cimaParaBaixo = false;
            modificarTangenteAngulo(x, jogo.getRaquete());
            dY = -Bola.ALTURA_DISPONIVEL;
            if (esquerdaParaDireita) {
                dX = -dY * tangenteAngulo;
                if (x + dX > Bola.X_MAX) {
                    dX = ((Bola.X_MAX == x) ? Bola.X_MAX : Bola.X_MAX - x);
                    dY = -(dX / tangenteAngulo);
                }
            } else {
                dX = dY * tangenteAngulo;
                if (x + dX < Bola.X_MIN) {
                    dX = -((Bola.X_MIN == x) ? Bola.X_MIN : x - Bola.X_MIN);
                    dY = dX / tangenteAngulo;
                }
            }
        } else if (naMargemEsquerda()) {
            esquerdaParaDireita = true;
            dX = Bola.LARGURA_DISPONIVEL;
            if (cimaParaBaixo) {
                dY = dX * tangenteAngulo;
                if (y + dY > Bola.Y_MAX) {
                    dY = ((Bola.Y_MAX == y) ? Bola.Y_MAX : Bola.Y_MAX - y);
                    dX = dY / tangenteAngulo;
                }
            } else {
                dY = -(dX * tangenteAngulo);
                if (y + dY < Bola.Y_MIN) {
                    dY = -((Bola.Y_MIN == y) ? Bola.Y_MIN : y - Bola.Y_MIN);
                    dX = -dY / tangenteAngulo;
                }
            }
        } else if (naMargemTopo()) {
            cimaParaBaixo = true;
            dY = Bola.ALTURA_DISPONIVEL;
            if (esquerdaParaDireita) {
                dX = dY * tangenteAngulo;
                if (x + dX > Bola.X_MAX) {
                    dX = ((Bola.X_MAX == x) ? Bola.X_MAX : Bola.X_MAX - x);
                    dY = dX / tangenteAngulo;
                }
            } else {
                dX = -(dY * tangenteAngulo);
                if (x + dX < Bola.X_MIN) {
                    dX = -((Bola.X_MIN == x) ? Bola.X_MIN : x - Bola.X_MIN);
                    dY = -dX / tangenteAngulo;
                }
            }
        } else if (naMargemDireita()) {
            esquerdaParaDireita = false;
            dX = -Bola.LARGURA_DISPONIVEL;
            if (cimaParaBaixo) {
                dY = -dX * tangenteAngulo;
                if (y + dY > Bola.Y_MAX) {
                    dY = ((Bola.Y_MAX == y) ? Bola.Y_MAX : Bola.Y_MAX - y);
                    dX = -dY / tangenteAngulo;
                }
            } else {
                dY = dX * tangenteAngulo;
                if (y + dY < Bola.Y_MIN) {
                    dY = -((Bola.Y_MIN == y) ? Bola.Y_MIN : y - Bola.Y_MIN);
                    dX = dY / tangenteAngulo;
                }
            }
        } else { //Por segurança
            return;
        }
        dX = Math.round(dX);
        dY = Math.round(dY);
        //Criar, parametrizar e executar a translação:
        TranslateTransition translacao = new TranslateTransition(Duration.millis(Math.sqrt(dX * dX + dY * dY) * Bola.VELOCIDADE), this);
        translacao.setOnFinished(e -> {
            if (naLinhaDaRaquete() && !jogo.getRaquete().dentro(xAtual())) {
                //Saiu pelo fundo: termina
                pararMover(jogo);
            } else {
                //Não saiu pelo fundo: avança com nova translação
                fazerTranslacao(jogo);
            }
        });
        translacao.setByX(dX);
        translacao.setByY(dY);
        translacao.play();
    }

    public void modificarTangenteAngulo(int x, Raquete raquete) {
        double meioRaquete = raquete.getMeioRaquete();
        double percentagemVariacao = 0.25; //25%
        if (tangenteAngulo == 0) {
            tangenteAngulo = percentagemVariacao;
        } else if (esquerdaParaDireita) {
            if (x > meioRaquete) {
                //Aumenta ângulo:
                tangenteAngulo = (1 + percentagemVariacao) * tangenteAngulo;
            } else {
                //Diminuí ângulo:
                tangenteAngulo = (1 - percentagemVariacao) * tangenteAngulo;
            }
        } else {
            if (x > meioRaquete) {
                //Diminuí ângulo:
                tangenteAngulo = (1 + percentagemVariacao) * tangenteAngulo;
            } else {
                //Aumenta ângulo:
                tangenteAngulo = (1 - percentagemVariacao) * tangenteAngulo;
            }
        }
    }
}
