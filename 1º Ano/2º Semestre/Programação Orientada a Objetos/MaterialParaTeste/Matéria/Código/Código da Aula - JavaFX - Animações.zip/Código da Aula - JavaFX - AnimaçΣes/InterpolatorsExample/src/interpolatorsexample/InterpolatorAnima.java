/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interpolatorsexample;

import javafx.animation.Interpolator;

/**
 *
 * @author rcneves
 */
public class InterpolatorAnima extends Interpolator {

    @Override
    protected double curve(double t) {
        System.out.format("%f => %f\n", t, Math.abs(0.5 - t) * 2);
        return Math.abs(0.5 - t) * 2;
    }
}
