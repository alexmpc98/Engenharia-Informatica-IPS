/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxanimationtime;

import javafx.animation.*;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.effect.Lighting;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 *
 * @author PM-Uninova
 */
public class JavaFXAnimationTime extends Application {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    //Valor do interior do circulo
    private Integer valor = 0; //Integer em vez de int para se fazer o toString()

    @Override
    public void start(Stage stage) {
        //Circulo com efeito
        final Circle circle = new Circle(20, Color.CYAN);
        circle.setEffect(new Lighting());
        //Texto dentro do circulo
        final Text text = new Text(valor.toString());
        text.setStroke(Color.BLACK);
        //Painel para conter os elementos (StackPane = centrados)
        final StackPane painel = new StackPane();
        painel.getChildren().addAll(circle, text);
        painel.setLayoutX(30); //X inicial (devia ser uma constante)
        painel.setLayoutY(30); //Y inicial (devia ser uma constante)

        Scene scene = new Scene(painel, 500, 500);
        stage.setScene(scene);
        stage.show();

        //AnimationTimer executa o método handle em cada "frame"
        AnimationTimer timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                text.setText(valor.toString());
                valor++;
            }
        };
        //AnimationTimer é uma classe abstracta
        //com dois métodos concretos: start, stop
        //e um método abstracto, que tem de ser definido: handle
        //Por ter mais de um método não pode ser utilizadas lambda expression

        //Criar os keyValue que aumentem 3 vezes a escala, em X e Y
        KeyValue keyValueX = new KeyValue(painel.scaleXProperty(), 3);
        KeyValue keyValueY = new KeyValue(painel.scaleYProperty(), 3);

        //Duração para atingir os valores anteriores: 2s
        Duration duration = Duration.millis(2000);
        //O que fazer ao atingir o fim da animação: mudar o centro e reset do valor
        EventHandler onFinished = e -> {
            //Mudar o centro
            painel.setTranslateX(java.lang.Math.random() * 300 - 100);
            painel.setTranslateY(java.lang.Math.random() * 200 - 100);
            //Reset do valor
            valor = 0;
        };
        //Criar o keyFrame com base na informação anterior
        KeyFrame keyFrame = new KeyFrame(duration, onFinished, keyValueX, keyValueY);

        //Criar a timeline e indicar as suas características
        Timeline timeline = new Timeline();
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.setAutoReverse(true);
        timeline.getKeyFrames().add(keyFrame);

        //Iniciar as animações
        timeline.play();
        timer.start();
    }
}
