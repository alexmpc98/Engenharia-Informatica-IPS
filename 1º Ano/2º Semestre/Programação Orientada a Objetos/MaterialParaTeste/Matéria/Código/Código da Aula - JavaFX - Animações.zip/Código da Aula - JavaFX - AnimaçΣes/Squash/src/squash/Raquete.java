/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package squash;

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

/**
 *
 * @author rcneves
 */
public class Raquete extends Rectangle {

    public static final int LARGURA = 40;
    public static final int MEIO_RAQUETE = Raquete.LARGURA / 2;
    public static final int ALTURA = 5;
    public static final int X_ORIGINAL = Jogo.LARGURA / 2 - Raquete.LARGURA / 2;
    public static final int Y_ORIGINAL = Jogo.ALTURA - Jogo.PADDING - Raquete.ALTURA;
    public static final int X_MIN = Jogo.PADDING + Math.max(0, Bola.RAIO - Raquete.LARGURA / 2);
    public static final int X_MAX = Jogo.LARGURA - Jogo.PADDING - Raquete.LARGURA - Math.max(0, Bola.RAIO - Raquete.LARGURA / 2);

    public Raquete() {
        setWidth(Raquete.LARGURA);
        setHeight(Raquete.ALTURA);
        setX(Raquete.X_ORIGINAL);
        setY(Raquete.Y_ORIGINAL);
        setFill(Color.BROWN);
    }

    public void mover(double x) {
        setX(Math.max(Raquete.X_MIN, Math.min(x, Raquete.X_MAX)));
    }

    public boolean dentro(double x) {
        return (x >= getX()) && (x <= getX() + Raquete.LARGURA);
    }

    public double getMeioRaquete() {
        return getX() + Raquete.MEIO_RAQUETE;
    }
}
