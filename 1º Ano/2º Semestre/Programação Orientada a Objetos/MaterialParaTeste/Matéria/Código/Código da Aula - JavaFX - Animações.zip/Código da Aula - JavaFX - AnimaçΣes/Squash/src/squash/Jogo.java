/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package squash;

import javafx.scene.Group;

/**
 *
 * @author rcneves
 */
public class Jogo extends Group {

    public static final int LARGURA = 300;
    public static final int ALTURA = 300;
    public static final int PADDING = 2;
    private boolean bolaParada;
    private Bola bola;
    private Raquete raquete;

    public Jogo() {
        bolaParada = true;
        raquete = new Raquete();
        bola = new Bola(this);
        getChildren().addAll(raquete, bola);
    }

    public Bola getBola() {
        return bola;
    }

    public Raquete getRaquete() {
        return raquete;
    }

    public void moverRaqueteBola(double x) {
        raquete.mover(x);
        if (bolaParada) {
            bola.moverComRaquete(raquete);
        }
    }

    public void iniciarMoverBola() {
        if (bolaParada) {
            bolaParada = false;
            bola.iniciarMover(this);
        }
    }

    public void pararMoverBola() {
        bolaParada = true;
    }
}
