/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package janelas;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * @author rcneves
 */
public class DialogoAviso extends Stage {

    public DialogoAviso(String titulo, String mensagem) {
        //Criar o painel com a informação
        VBox painelPrincipal = new VBox(10);
        painelPrincipal.setPadding(new Insets(10));
        painelPrincipal.setAlignment(Pos.CENTER);
        //Criar a mensagem:
        Label apresentacaoMensagem = new Label(mensagem);
        apresentacaoMensagem.setStyle("-fx-font-weight: bold;");
        //Criar botões:
        final Button botaoOk = new Button("OK");
        botaoOk.setOnAction(e -> ((Stage) botaoOk.getScene().getWindow()).close());
        //Posicionar os nós:
        painelPrincipal.getChildren()
                .addAll(apresentacaoMensagem, botaoOk);
        setResizable(false);
        initStyle(StageStyle.UTILITY);
        initModality(Modality.APPLICATION_MODAL);
        setIconified(false);
        centerOnScreen();
        setTitle(titulo);
        setScene(new Scene(painelPrincipal));
        show();
    }
}
