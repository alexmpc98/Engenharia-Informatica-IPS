/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package alternarpaineis;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

/**
 *
 * @author rcneves
 */
public class PainelRadioButtons extends VBox {

    public PainelRadioButtons() {
        RadioButton buttonAmarelo = new RadioButton("amarelo");
        RadioButton buttonAzul = new RadioButton("azul");
        RadioButton buttonVermelho = new RadioButton("vermelho");
        final ToggleGroup group = new ToggleGroup();
        buttonAmarelo.setToggleGroup(group);
        buttonAzul.setToggleGroup(group);
        buttonVermelho.setToggleGroup(group);

        final Text texto = new Text("radio buttons");
        texto.setFill(Color.BLUE);
        buttonAzul.setSelected(true);

        buttonAmarelo.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                texto.setFill(Color.YELLOW);
            }
        });
        buttonAzul.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                texto.setFill(Color.BLUE);
            }
        });
        buttonVermelho.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                texto.setFill(Color.RED);
            }
        });

        this.getChildren().addAll(buttonAmarelo, buttonAzul, buttonVermelho, texto);
        setPadding(new Insets(10));
        setSpacing(10);
    }
}
