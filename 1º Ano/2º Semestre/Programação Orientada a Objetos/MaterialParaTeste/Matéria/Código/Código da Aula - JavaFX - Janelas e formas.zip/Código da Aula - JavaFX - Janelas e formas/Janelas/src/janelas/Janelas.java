/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package janelas;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author rcneves
 */
public class Janelas extends Application {

    @Override
    @SuppressWarnings("ResultOfObjectAllocationIgnored")
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Janela Principal");
        Scene scene = new Scene(new AbrirJanelas(), 300, 100);
        primaryStage.setScene(scene);
        primaryStage.show();

//        new DialogoAviso("Aviso", "Mensagem do aviso!");
        
//        new DialogoConfirmacao("Confirmação",
//                "Confirma a mensagem?",
//                e -> new DialogoAviso("Confirmar", "Confirmei a mensagem no 'Sim'!"));

//      primaryStage.setTitle("Manipulação de Ficheiro");
//      primaryStage.setScene(new Scene(new ManipularFicheiros(), 400, 100));
//      primaryStage.show();
    }

    /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * main() serves only as fallback in case the application can not be
     * launched through deployment artifacts, e.g., in IDEs with limited FX
     * support. NetBeans ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}
