/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package atribuircores;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Slider;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/**
 *
 * @author rcneves
 */
public class AtribuirCores extends Application {

    @Override
    public void start(Stage primaryStage) {
        /*
         primaryStage.setTitle("Atribuir Cores");
         Group root = new Group();
         Scene scene = new Scene(root, 200, 200);
         Rectangle rectangle = new Rectangle(50, 50, 100, 70);
         LinearGradient linearGradiente
         = new LinearGradient(
         50, //startX
         50, //startY
         50, //endX
         50 + rectangle.prefHeight(-1) + 25, //endY
         false, //proportional
         CycleMethod.NO_CYCLE, //.cycleMethod(
         new Stop(0.1f, Color.rgb(255, 200, 0, 0.784)), //stops
         new Stop(1.0f, Color.rgb(0, 0, 0, 0.784)));
         rectangle.setFill(linearGradiente);
         root.getChildren().add(rectangle);
         primaryStage.setScene(scene);
         primaryStage.show();
         */

        //*
        primaryStage.setTitle("Atribuir Cores");
        Group root = new Group();
        Scene scene = new Scene(root, 200, 200);
        Rectangle rectangle = new Rectangle(50, 50, 100, 70);
        LinearGradient linearGradient
                = new LinearGradient(50, //startX
                        50, //startY
                        50, //endX
                        50 + rectangle.prefHeight(-1) + 25, //endY
                        false, //proportional
                        CycleMethod.NO_CYCLE, //cycleMethod
                        new Stop(0.1f, Color.AQUA), new Stop(1.0f, Color.BLUE)); //stops
        rectangle.setFill(linearGradient);
        Slider slider = new Slider(0, 100, 50);
        slider.setLayoutX(50);
        slider.setLayoutY(150);
        slider.setMinorTickCount(2);
        slider.setShowTickLabels(true);
        slider.setShowTickMarks(true);

        rectangle.widthProperty().bind(slider.valueProperty());

        root.getChildren().addAll(rectangle, slider);
        primaryStage.setScene(scene);
        primaryStage.show();

        //*/
    }

    /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * main() serves only as fallback in case the application can not be
     * launched through deployment artifacts, e.g., in IDEs with limited FX
     * support. NetBeans ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}
