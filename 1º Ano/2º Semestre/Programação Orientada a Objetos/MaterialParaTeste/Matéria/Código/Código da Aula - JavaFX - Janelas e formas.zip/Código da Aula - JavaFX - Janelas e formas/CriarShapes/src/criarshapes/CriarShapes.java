/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package criarshapes;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.CubicCurve;
import javafx.scene.shape.StrokeType;
import javafx.stage.Stage;

/**
 *
 * @author rcneves
 */
public class CriarShapes extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Formas");
        Group root = new Group();
        Scene scene = new Scene(root, 200, 200);
        CubicCurve curva = new CubicCurve();
        curva.setStartX(60);
        curva.setStartY(85);
        curva.setControlX1(90);
        curva.setControlY1(-35);
        curva.setControlX2(120);
        curva.setControlY2(185);
        curva.setEndX(150);
        curva.setEndY(85);
        curva.setStrokeType(StrokeType.CENTERED);
        curva.setStrokeWidth(1);
        curva.setStroke(Color.BLUE);
        curva.setFill(Color.YELLOW);
        root.getChildren().add(curva);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * main() serves only as fallback in case the application can not be
     * launched through deployment artifacts, e.g., in IDEs with limited FX
     * support. NetBeans ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}
