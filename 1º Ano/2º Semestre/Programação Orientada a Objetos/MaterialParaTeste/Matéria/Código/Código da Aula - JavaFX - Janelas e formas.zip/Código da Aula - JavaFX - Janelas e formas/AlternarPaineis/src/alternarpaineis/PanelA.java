/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package alternarpaineis;

import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;

/**
 *
 * @author rcneves
 */
public class PanelA extends StackPane {

    public PanelA() {
        this.getChildren().add(new Label("Painel A"));
    }
    
}
