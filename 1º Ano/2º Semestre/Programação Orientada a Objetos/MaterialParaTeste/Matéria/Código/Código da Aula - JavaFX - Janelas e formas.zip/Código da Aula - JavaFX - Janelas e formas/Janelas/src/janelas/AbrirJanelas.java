/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package janelas;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author rcneves
 */
public class AbrirJanelas extends StackPane {

    private static int quantas = 0;

    public AbrirJanelas() {
        Button botao = new Button("Abrir Janelas");
        botao.setOnAction(e -> {
            Stage janela = new Stage();
            janela.setTitle("Janela nº " + ++quantas);
            janela.setScene(new Scene(new AbrirJanelas(), 300, 100));
            janela.show();
        });
        this.getChildren().add(botao);
    }
}
