/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package janelas;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * @author rcneves
 */
public class DialogoConfirmacao extends Stage {

    public DialogoConfirmacao(String titulo, String mensagem, final EventHandler<ActionEvent> accaoSim) {
        //Criar o painel com a informação
        VBox painelPrincipal = new VBox(10);
        painelPrincipal.setPadding(new Insets(10));
        painelPrincipal.setAlignment(Pos.CENTER);
        //Criar a mensagem:
        final Label apresentacaoMensagem = new Label(mensagem);
        apresentacaoMensagem.setStyle("-fx-font-weight: bold;");
        //Criar botões:
        final HBox painelBotoes = new HBox(10);
        painelBotoes.setAlignment(Pos.CENTER);
        Button botaoSim = new Button("Sim");
        botaoSim.setOnAction(e -> {
            accaoSim.handle(e);
            ((Stage) painelBotoes.getScene().getWindow()).close();
        });
        Button botaoNao = new Button("Não");
        botaoNao.setOnAction(e -> ((Stage) painelBotoes.getScene().getWindow()).close());
        painelBotoes.getChildren().addAll(botaoSim, botaoNao);
        //Posicionar os nós:
        painelPrincipal.getChildren().addAll(apresentacaoMensagem, painelBotoes);
        setResizable(false);
        initStyle(StageStyle.UTILITY);
        initModality(Modality.APPLICATION_MODAL);
        setIconified(false);
        centerOnScreen();
        setTitle(titulo);
        setScene(new Scene(painelPrincipal));
        show();
    }
}
