/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package alternarpaineis;

import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;

/**
 *
 * @author rcneves
 */
public class PanelB extends StackPane {

    public PanelB() {
        this.getChildren().add(new Label("Painel B"));
    }
}
