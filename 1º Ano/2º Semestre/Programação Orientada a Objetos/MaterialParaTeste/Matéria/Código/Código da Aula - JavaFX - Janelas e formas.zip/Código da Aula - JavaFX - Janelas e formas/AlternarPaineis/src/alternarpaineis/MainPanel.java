/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package alternarpaineis;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.layout.BorderPane;

/**
 *
 * @author rcneves
 */
public class MainPanel extends BorderPane {

    private final PanelA painelA;
    private final PanelB painelB;

    public MainPanel() {

        MenuBar menuBar = new MenuBar();
        Menu menuConfigurar = new Menu("Configurar");
        MenuItem menuConfigurarA = new MenuItem("Adicionar A");
        menuConfigurarA.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                mostrarPainelA();
            }
        });
        MenuItem menuConfigurarB = new MenuItem("Adicionar B");
        menuConfigurarB.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                mostrarPainelB();
            }
        });
        menuConfigurar.getItems().addAll(menuConfigurarA, menuConfigurarB);
        Menu menuVisualizar = new Menu("Visualizar");
        MenuItem menuVerA = new MenuItem("ver A");
        CheckMenuItem menuVerB = new CheckMenuItem("ver B");
        menuVisualizar.getItems().addAll(menuVerA, new SeparatorMenuItem(), menuVerB);
        Menu menuSair = new Menu("Sair");
        MenuItem menuFechar = new MenuItem("Fechar");
        menuFechar.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Platform.exit();
            }
        });
        menuSair.getItems().add(menuFechar);
        menuBar.getMenus().addAll(menuConfigurar, menuVisualizar, menuSair);
        this.setTop(menuBar);

        this.painelA = new PanelA();
        this.painelB = new PanelB();
    }

    public void mostrarPainelA() {
        this.setCenter(painelA);
    }

    public void mostrarPainelB() {
        this.setCenter(painelB);
    }
}
