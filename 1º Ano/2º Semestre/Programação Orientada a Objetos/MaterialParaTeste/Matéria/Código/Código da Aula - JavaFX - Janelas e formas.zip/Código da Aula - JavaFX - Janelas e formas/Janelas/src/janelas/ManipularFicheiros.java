/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package janelas;

import java.io.File;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;

/**
 *
 * @author rcneves
 */
public class ManipularFicheiros extends VBox {

    public ManipularFicheiros() {
        final Label nomeDoFicheiro = new Label();

        Button botao = new Button("Abrir ficheiro...");
        botao.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();

            ExtensionFilter extensoes = new ExtensionFilter("WMV files (*.wmv)", "*.wmv");
            fileChooser.getExtensionFilters().add(extensoes);

            File file = fileChooser.showOpenDialog(null);

            if (file != null) {
                nomeDoFicheiro.setText(file.getPath());
            } else {
                nomeDoFicheiro.setText("");
            }
        });

        getChildren().addAll(botao, nomeDoFicheiro);

        setPadding(new Insets(10));
        setSpacing(10);
    }
}
