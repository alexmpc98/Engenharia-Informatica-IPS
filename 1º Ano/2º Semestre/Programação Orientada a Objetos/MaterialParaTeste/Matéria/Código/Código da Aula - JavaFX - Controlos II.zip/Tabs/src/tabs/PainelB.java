/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tabs;

import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;

/**
 *
 * @author rcneves
 */
public class PainelB extends StackPane {

    public PainelB() {
        this.getChildren().add(new Label("Painel B"));
    }
}
