/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tabs;

import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;

/**
 *
 * @author rcneves
 */
public class PainelA extends StackPane {

    public PainelA() {
        this.getChildren().add(new Label("Painel A"));
    }
    
}
