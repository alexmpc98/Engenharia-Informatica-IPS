/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tabs;

import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.StackPane;

/**
 *
 * @author rcneves
 */
public class PainelComTab extends StackPane {

    public PainelComTab() {
        TabPane tabPane = new TabPane();

        Tab tabA = new Tab("Painel A");
        tabA.setContent(new PainelA());

        Tab tabB = new Tab("Painel B");
        tabB.setContent(new PainelB());

        tabPane.getTabs().addAll(tabA, tabB);

        //tabPane.getSelectionModel().select(1);
        this.getChildren().add(tabPane);
    }

}
