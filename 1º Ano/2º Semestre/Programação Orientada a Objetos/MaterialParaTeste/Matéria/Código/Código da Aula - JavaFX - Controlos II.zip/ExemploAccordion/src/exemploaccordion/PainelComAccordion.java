/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemploaccordion;

import javafx.scene.control.Accordion;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.StackPane;

/**
 *
 * @author rcneves
 */
public class PainelComAccordion extends StackPane {

    public PainelComAccordion() {
        Accordion accordion = new Accordion();
        TitledPane painel1 = new Painel1();
        TitledPane painel2 = new Painel2();
        accordion.getPanes().add(painel1);
        accordion.getPanes().add(painel2);
        //accordion.setExpandedPane(painel2);
        this.getChildren().add(accordion);
    }
}
