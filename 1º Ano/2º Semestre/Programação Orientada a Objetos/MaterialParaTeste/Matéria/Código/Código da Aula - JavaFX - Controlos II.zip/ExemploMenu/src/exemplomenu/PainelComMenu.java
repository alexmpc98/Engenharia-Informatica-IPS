/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplomenu;

import javafx.application.Platform;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.layout.BorderPane;

/**
 *
 * @author rcneves
 */
public class PainelComMenu extends BorderPane {

    private final PanelA painelA;
    private final PanelB painelB;

    public PainelComMenu() {
        MenuBar menuBar = new MenuBar();
        Menu menuConfigurar = new Menu("Configurar");
        MenuItem menuConfigurarA = new MenuItem("Adicionar A");
        menuConfigurarA.setOnAction(e -> mostrarPainelA());
        MenuItem menuConfigurarB = new MenuItem("Adicionar B");
        menuConfigurarB.setOnAction(e -> mostrarPainelB());
        menuConfigurar.getItems().addAll(menuConfigurarA, menuConfigurarB);
        Menu menuVisualizar = new Menu("Visualizar");
        MenuItem menuVerA = new MenuItem("ver A");
        CheckMenuItem menuVerB = new CheckMenuItem("ver B");
        menuVisualizar.getItems().addAll(menuVerA, new SeparatorMenuItem(), menuVerB);
        Menu menuSair = new Menu("Sair");
        MenuItem menuFechar = new MenuItem("Fechar");
        menuFechar.setOnAction(e -> Platform.exit());
        menuSair.getItems().add(menuFechar);
        menuBar.getMenus().addAll(menuConfigurar, menuVisualizar, menuSair);
        this.setTop(menuBar);
        this.painelA = new PanelA();
        this.painelB = new PanelB();
    }

    public final void mostrarPainelA() {
        this.setCenter(painelA);
    }

    public final void mostrarPainelB() {
        this.setCenter(painelB);
    }
}
