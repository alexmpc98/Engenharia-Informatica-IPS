/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplomenu;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

/**
 *
 * @author rcneves
 */
public class PanelB extends GridPane {

    public PanelB() {
        setPadding(new Insets(10));
        setHgap(10);
        setVgap(10);
        add(new Label("INSERIR B"), 0, 0);
        add(new Label("Designação"), 0, 1);
        add(new TextField(), 1, 1);
        add(new Button("OK"), 0, 2);
        add(new Button("Cancel"), 1, 2);
    }

}
