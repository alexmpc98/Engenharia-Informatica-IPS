/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemploradiobutton;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author rcneves
 */
public class ExemploRadioButton extends Application {

    @Override
    public void start(Stage primaryStage) {
        VBox root = new VBox(10);
        root.setPadding(new Insets(10));
        //Definir os Radio Buttons
        RadioButton buttonAmarelo = new RadioButton("amarelo");
        RadioButton buttonAzul = new RadioButton("azul");
        RadioButton buttonVermelho = new RadioButton("vermelho");
        //Associar os Radio Buttons
        final ToggleGroup group = new ToggleGroup();
        buttonAmarelo.setToggleGroup(group);
        buttonAzul.setToggleGroup(group);
        buttonVermelho.setToggleGroup(group);
        //Definir o Text
        final Text texto = new Text("radio buttons");
        texto.setFill(Color.BLUE);
        buttonAzul.setSelected(true);
        //Definir as ações do Radion Button
        buttonAmarelo.setOnAction(e -> texto.setFill(Color.YELLOW));
        buttonAzul.setOnAction(e -> texto.setFill(Color.BLUE));
        buttonVermelho.setOnAction(e -> texto.setFill(Color.RED));
        //Colocar nós
        root.getChildren().addAll(buttonAmarelo, buttonAzul, buttonVermelho, texto);

        Scene scene = new Scene(root, 300, 250);
        primaryStage.setTitle("Radio Buttons");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
