/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package drawingtext;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author rcneves
 */
public class DrawingText extends Application {

    @Override
    public void start(Stage primaryStage) {
        BorderPane root = new BorderPane();
        HBox hbox = addBotoes();
        root.setTop(hbox);
        VBox vbox = addTextos();
        root.setCenter(vbox);
        Scene scene = new Scene(root, 700, 500);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private HBox addBotoes() {
        HBox hbox = new HBox();
        hbox.setPadding(new Insets(15, 12, 15, 12));
        hbox.setSpacing(10);
        hbox.setStyle("-fx-background-color: #336699;");
        adicionarBotoes(hbox);
        return hbox;
    }

    private void adicionarBotoes(HBox hbox) {
        hbox.getChildren().add(criarBotao("Vermelho", Color.RED));
        hbox.getChildren().add(criarBotao("Azul", Color.BLUE));
    }

    private Button criarBotao(String texto, final Color cor) {
        Button btn = new Button(texto);
        btn.setOnAction(e -> alterarCor(cor, e));
        return btn;
    }

    private void alterarCor(Color cor, ActionEvent event) {
        Button bnt = (Button) event.getSource();
        BorderPane root = (BorderPane) bnt.getParent().getParent();
        VBox vbox = (VBox) root.getCenter();
        Text texto;
        for (Node no : vbox.getChildrenUnmodifiable()) {
            if (no instanceof Text) {
                texto = (Text) no;
                texto.setFill(cor);
            }
        }
    }

    private VBox addTextos() {
        VBox vbox = new VBox();
        vbox.setPadding(new Insets(10));
        vbox.setSpacing(10);
        adicionarTextos(vbox);
        return vbox;
    }

    private void adicionarTextos(VBox vbox) {
        vbox.getChildren().addAll(
                criarTexto("Font Serif", "Serif", 30),
                criarTexto("Font SanSerif", "SanSerif", 50),
                criarTexto("Font Monospaced", "Monospaced", 70)
        );
    }

    private Text criarTexto(String frase,
            String nomeFonte,
            int tamanho) {
        Text texto = new Text(frase);
        Font fonte = Font.font(nomeFonte, tamanho);
        texto.setFont(fonte);
        return texto;
    }

    /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * main() serves only as fallback in case the application can not be
     * launched through deployment artifacts, e.g., in IDEs with limited FX
     * support. NetBeans ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}
