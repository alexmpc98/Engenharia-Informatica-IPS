/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package borderpaneexample;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderPaneBuilder;
import javafx.stage.Stage;

/**
 *
 * @author rcneves
 */
public class BorderPaneExample extends Application {

    @Override
    public void start(Stage primaryStage) {
        Button btn1 = new Button("Botao 1");
        Button btn2 = new Button("Botao 2");
        Button btn3 = new Button("Botao 3");
        Button btn4 = new Button("Botao 4");
        Button btn5 = new Button("Botao 5");
        /*
         BorderPane root = new BorderPane();
         root.setTop(btn1);
         root.setLeft(btn2);
         root.setRight(btn3);
         root.setBottom(btn4);
         root.setCenter(btn5);
         */
        BorderPane root = BorderPaneBuilder.create()
                .top(btn1)
                .left(btn2)
                .right(btn3)
                .bottom(btn4)
                .center(btn5)
                .build();

        primaryStage.setTitle("Border Layout");
        primaryStage.setScene(new Scene(root, 300, 250));
        primaryStage.show();
    }

    /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * main() serves only as fallback in case the application can not be
     * launched through deployment artifacts, e.g., in IDEs with limited FX
     * support. NetBeans ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}
