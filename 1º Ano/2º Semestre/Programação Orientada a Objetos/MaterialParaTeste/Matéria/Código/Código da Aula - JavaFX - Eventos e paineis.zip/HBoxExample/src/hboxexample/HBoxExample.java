/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hboxexample;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

/**
 *
 * @author rcneves
 */
public class HBoxExample extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("BOXs Layout");
        Button btn1 = new Button("Botao 1");
        Button btn2 = new Button("Botao 2");
        Button btn3 = new Button("Botao 3");
        Button btn4 = new Button("Botao 4");
        Button btn5 = new Button("Botao 5");
        HBox root = new HBox();
        root.setPadding(new Insets(15, 12, 15, 12));
        root.setSpacing(10);
        root.getChildren().addAll(btn1, btn2, btn3, btn4, btn5);
        primaryStage.setScene(new Scene(root, 500, 250));
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
