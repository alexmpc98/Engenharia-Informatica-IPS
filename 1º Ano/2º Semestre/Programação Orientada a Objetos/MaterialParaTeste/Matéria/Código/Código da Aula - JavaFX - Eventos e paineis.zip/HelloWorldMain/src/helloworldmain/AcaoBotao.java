/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package helloworldmain;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;

/**
 *
 * @author rcneves
 */
public class AcaoBotao implements EventHandler<ActionEvent> {

    private String mensagem;

    public AcaoBotao(String mensagem) {
        this.mensagem = mensagem;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    @Override
    public void handle(ActionEvent event) {
        System.out.println(mensagem);
    }
}
