/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gridpaneexample;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 *
 * @author rcneves
 */
public class GridPaneExample extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Grid Layout");
        Button btn1 = new Button("Botao 1");
        Button btn2 = new Button("Botao 2");
        Button btn3 = new Button("Botao 3");
        Button btn4 = new Button("Botao 4");
        Button btn5 = new Button("Botao 5");
        GridPane root = new GridPane();
        root.setHgap(20);
        root.setVgap(20);
        root.setPadding(new Insets(20, 10, 20, 10));
        root.setGridLinesVisible(true);
        root.add(btn1, 0, 1);
        root.add(btn2, 0, 2);
        root.add(btn3, 0, 3);
        root.add(btn4, 1, 0);
        root.add(btn5, 1, 1);
        primaryStage.setScene(new Scene(root, 300, 250));
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
