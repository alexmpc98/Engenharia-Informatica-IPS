/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edicaopessoas;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

/**
 *
 * @author rcneves
 */
public class VisualizadorPessoa extends GridPane {

    public VisualizadorPessoa(final Pessoas pessoas, final Pessoa pessoa) {
        //Criar os nós
        Label nomeRotulo = new Label("Nome");
        final TextField nomeCampo = new TextField();
        nomeCampo.setPrefWidth(200);
        Label idadeRotulo = new Label("Idade");
        //final Slider idadeSlider = criarSliderIdade();
        //final SliderIdade idadeSlider = new SliderIdade();
        final VisualizadorIdade idadeSlider = new VisualizadorIdade();
        if (pessoa != null) {
            nomeCampo.setText(pessoa.getNome());
            idadeSlider.setValue(pessoa.getIdade());
        }
        //Botão aceitar
        Button botaoAceitar = new Button("Aceitar");
        botaoAceitar.setOnAction(e -> {
            if (pessoa == null) { //Criar
                try {
//                        pessoas.adicionarPessoa(new Pessoa(nomeCampo.getText(), (int) idadeSlider.getValue()));
                    pessoas.add(new Pessoa(nomeCampo.getText(), (int) idadeSlider.getValue()));
                } catch (Exception ex) {
                }
            } else { //Atualizar
                pessoa.setNome(nomeCampo.getText());
                pessoa.setIdade((int) idadeSlider.getValue());
            }
            nomeCampo.getScene().setRoot(new VisualizadorPessoas(pessoas));
        });
        Button botaoCancelar = new Button("Cancelar");
        botaoCancelar.setOnAction(e -> nomeCampo.getScene().setRoot(new VisualizadorPessoas(pessoas)));
        //Posicionar os nós
        setPadding(new Insets(10));
        setVgap(10);
        setHgap(10);
        add(nomeRotulo, 0, 0);
        add(nomeCampo, 1, 0);
        add(idadeRotulo, 0, 1);
        add(idadeSlider, 1, 1);
        add(botaoAceitar, 0, 2);
        add(botaoCancelar, 1, 2);
    }

//    public final Slider criarSliderIdade() {
//        Slider slider = new Slider();
//        slider.setMin(Pessoa.getIdadeMinima());
//        slider.setMax(Pessoa.getIdadeMaxima());
//        slider.setShowTickLabels(true);
//        slider.setShowTickMarks(true);
//        slider.setMajorTickUnit(10);
//        return slider;
//    }
}
