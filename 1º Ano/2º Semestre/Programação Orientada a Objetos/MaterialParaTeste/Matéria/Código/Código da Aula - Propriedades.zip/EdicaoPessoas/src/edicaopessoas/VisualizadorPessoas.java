/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edicaopessoas;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 *
 * @author rcneves
 */
public class VisualizadorPessoas extends VBox {

    public VisualizadorPessoas(final Pessoas pessoas) {
        //Criar o rótulo
        Label labelLista = new Label("Pessoas");
        //Criar a lista
//        final ObservableList<Pessoa> listaPessoas = FXCollections.observableArrayList(pessoas.getPessoas());
        final ObservableList<Pessoa> listaPessoas = FXCollections.observableArrayList(pessoas);
        final ListView<Pessoa> lista = new ListView<>(listaPessoas);
        //Criar o painel dos botões
        HBox painelBotoes = new HBox(10);
        //Botão criar
        Button botaoCriar = new Button("Criar...");
        botaoCriar.setOnAction(e -> lista.getScene().setRoot(new VisualizadorPessoa(pessoas, null)));
        //Botão editar
        Button botaoEditar = new Button("Editar...");
        botaoEditar.setOnAction(e -> {
            Pessoa pessoa = lista.getSelectionModel().getSelectedItem();
            if (pessoa != null) {
                lista.getScene().setRoot(new VisualizadorPessoa(pessoas, pessoa));
            }
        });
        //Botão apagar
        Button botaoApagar = new Button("Apagar");
        botaoApagar.setOnAction(e -> {
            Pessoa pessoa = lista.getSelectionModel().getSelectedItem();
            if (pessoa != null) {
                listaPessoas.remove(pessoa);
//                pessoas.removerPessoa(pessoa);
                pessoas.remove(pessoa);
            }
        });
        painelBotoes.getChildren().addAll(botaoCriar, botaoEditar, botaoApagar);
        //Posicionar os nós
        setPadding(new Insets(10));
        setSpacing(10);
        getChildren().setAll(labelLista, lista, painelBotoes);
    }
}
