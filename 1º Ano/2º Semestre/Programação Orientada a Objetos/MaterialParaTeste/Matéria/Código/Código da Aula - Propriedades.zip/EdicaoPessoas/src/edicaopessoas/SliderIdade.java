/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edicaopessoas;

import javafx.scene.control.Slider;

/**
 *
 * @author rcneves
 */
public class SliderIdade extends Slider {

    public SliderIdade() {
        setMin(Pessoa.getIdadeMinima());
        setMax(Pessoa.getIdadeMaxima());
        setShowTickLabels(true);
        setShowTickMarks(true);
        setMajorTickUnit(10);
    }
}
