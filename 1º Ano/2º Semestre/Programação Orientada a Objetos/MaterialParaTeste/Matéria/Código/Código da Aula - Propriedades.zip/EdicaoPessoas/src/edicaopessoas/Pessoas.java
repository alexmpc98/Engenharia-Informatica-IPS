/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edicaopessoas;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashSet;

/**
 *
 * @author rcneves
 */
public class Pessoas extends HashSet<Pessoa> implements Serializable {

    private static final String NOME_FICHEIRO = "pessoas.dat";

    @Override
    public boolean add(Pessoa pessoa) {
        System.out.println("Adicionei: " + pessoa);
        return super.add(pessoa);
    }

    @Override
    public boolean remove(Object pessoa) {
        System.out.println("Removi: " + pessoa);
        return super.remove(pessoa);
    }

    public void gravarPessoas() {
        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(NOME_FICHEIRO));
            oos.writeObject(this);
            oos.flush();
            oos.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public static Pessoas lerPessoas() {
        Pessoas pessoas;
        try {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream(NOME_FICHEIRO));
            pessoas = (Pessoas) ois.readObject();
            ois.close();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println(e.getMessage());
            pessoas = new Pessoas();
        }
        return pessoas;
    }
}
/*
 public class Pessoas {

 private HashSet<Pessoa> pessoas;

 public Pessoas() {
 pessoas = new HashSet<>();
 }

 public void adicionarPessoa(Pessoa pessoa) {
 pessoas.add(pessoa);
 }

 public void removerPessoa(Pessoa pessoa) {
 pessoas.remove(pessoa);
 }

 public boolean contemPessoa(Pessoa pessoa) {
 return pessoas.contains(pessoa);
 }

 public Pessoa[] getPessoas() {
 return pessoas.toArray(new Pessoa[pessoas.size()]);
 }
 }
 */
