/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 

/**
 *
 * @author 
 */
public class Generics {

    public static void testListOfNames() {
        ListOfName names = new ListOfName();
//        ListOfObject names = new ListOfObject();
//        List<String> names = new List<>(); //new List<String>(); 
        System.out.println("No início: capacity=" + names.capacity());
        names.add("Bruno");
        names.add("Fausto");
        names.add("José");
        names.add("Rui");
        names.add("Patricia");
        names.add("Joaquim");
        System.out.println("Depois de inseridos os elementos: capacity=" + names.capacity());
        System.out.println("names=" + names);
        System.out.println("size=" + names.size());
        System.out.println("names[4]=" + names.get(4));
        System.out.println("names[10]=" + names.get(10));
        names.remove(4);
        System.out.println("Depois de remove(4): names=" + names);
        System.out.println("size=" + names.size());
        names.set(4, "Silva");
        System.out.println("Depois de set(4): names=" + names);
    }

    public static void testListOfPerson() {
        //ListOfPerson persons = new ListOfPerson();
        //ListOfObject persons = new ListOfObject();
        List<Person> persons = new List<>(); //new List<Person>(); 
        System.out.println("No início: capacity=" + persons.capacity());
        persons.add(new Person("Maria", 28));
        persons.add(new Person("Manuel", 34));
        persons.add(new Person("Marta", 45));
        persons.add(new Person("Mauro", 53));
        persons.add(new Person("Miguel", 19));
        persons.add(new Person("Margarida", 26));
        System.out.println("Depois de inseridos os elementos: capacity=" + persons.capacity());
        System.out.println("persons=" + persons);
        System.out.println("size=" + persons.size());
        System.out.println("persons[4]=" + persons.get(4));
        System.out.println("persons[10]=" + persons.get(10));
        persons.remove(4);
        System.out.println("Depois de remove(4): persons=" + persons);
        System.out.println("size=" + persons.size());
        persons.set(4, new Worker("Matos", 47));
        System.out.println("Depois de set(4): persons=" + persons);
    }

    public static void testListOfObject() {
        ListOfObject objects = new ListOfObject();
        System.out.println("No início: capacity=" + objects.capacity());
        objects.add("Bruno");
        objects.add("Fausto");
        objects.add("José");
        objects.add(new Person("Mauro", 53));
        objects.add(new Person("Miguel", 19));
        objects.add(new Person("Margarida", 26));
        System.out.println("Depois de inseridos os elementos: capacity=" + objects.capacity());
        System.out.println("objects=" + objects);
        System.out.println("size=" + objects.size());
        System.out.println("objects[4]=" + objects.get(4));
        System.out.println("objects[10]=" + objects.get(10));
        objects.remove(4);
        System.out.println("Depois de remove(4): objects=" + objects);
        System.out.println("size=" + objects.size());
        objects.set(4, new Worker("Matos", 47));
        System.out.println("Depois de set(4): objects=" + objects);
    }

    public static <T> void information(T t) {
        System.out.println("T: " + t.getClass().getName());
    }

    public static void main(String[] args) {
//        List<String> names = new List<>();
//        Generics.<List<String>>information(names);
//        Generics.information(names);

//        System.out.println("NOMES:");
//        testListOfNames();
//        System.out.println("PESSOAS:");
//        testListOfPerson();
          System.out.println("OBJETOS:");
          testListOfObject();

        List<Person> persons = new List<>();
        persons.add(new Person("Maria", 28));
        persons.add(new Worker("Matos", 47));

        List<Worker> workers = new List<>();
        workers.add(new Worker("Mateus", 34));
        workers.add(new Worker("Moureira", 53));
        List<Person> error = workers;
        
        
        
        
        
        
        
        List<? extends Person> noError = workers;
          List<Integer> example = new List<>();
    }

}
