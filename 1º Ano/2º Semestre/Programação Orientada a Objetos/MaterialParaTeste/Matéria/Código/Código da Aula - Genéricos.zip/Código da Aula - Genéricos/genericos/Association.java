/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 

/**
 *
 * @author 
 * @param <K>
 * @param <V>
 */
//public class Association<K, V> {
public class Association<K extends Number, V extends Person> {

    private K key;
    private V value;

    public Association(K key, V value) {
        this.key = key;
        this.value = value;
    }

    public K getKey() {
        return key;
    }

    public void setKey(K key) {
        this.key = key;
    }

    public V getValues() {
        return value;
    }

    public void setValues(V value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return key + "-" + value.getName();
    }
}
