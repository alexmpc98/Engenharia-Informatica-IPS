/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

 

/**
 *
 * @author 
 */
public class ListOfPerson {
    
    private static final int DEFAULT_SIZE = 5;
    private Person[] values;
    private int totalValues;

    public ListOfPerson() {
        values = new Person[DEFAULT_SIZE];
        totalValues = 0;
    }

    public void add(Person element) {
        if (totalValues == values.length) {
            Person[] newValues = new Person[values.length * 2];
            for (int i = 0; i < values.length; i++) {
                newValues[i] = values[i];
            }
            values = newValues;
        }
        values[totalValues++] = element;
    }

    public boolean remove(int position) {
        if ((position >= 0) && (position < totalValues)) {
            for (int i = position; i < totalValues - 1; i++) {
                values[i] = values[i + 1];
            }
            totalValues--;
            return true;
        } else {
            return false;
        }
    }

    public Person get(int position) {
        if ((position >= 0) && (position < totalValues)) {
            return values[position];
        } else {
            return null;
        }
    }

    public boolean set(int position, Person element) {
        if ((position >= 0) && (position < totalValues)) {
            values[position] = element;
            return true;
        } else {
            return false;
        }
    }

    public int size() {
        return totalValues;
    }

    public int capacity() {
        return values.length;
    }
    
    @Override
    public String toString() {
        String result = "[";
        boolean first = true;
        for (int i = 0; i < totalValues; i++) {
            if (first) {
                first = false;
            } else {
                result += ", ";
            }
            result += values[i];
        }
        result += "]";
        return result;
    }
}
