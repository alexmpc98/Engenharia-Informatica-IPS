/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 

/**
 *
 * @author rcneves
 */
public class ListOfObject {

    private static final int DEFAULT_SIZE = 5;
    private Object[] values;
    private int totalValues;

    public ListOfObject() {
        values = new Object[DEFAULT_SIZE];
        totalValues = 0;
    }

    public void add(Object element) {
        if (totalValues == values.length) {
            Object[] newValues = new Object[values.length * 2];
            for (int i = 0; i < values.length; i++) {
                newValues[i] = values[i];
            }
            values = newValues;
        }
        values[totalValues++] = element;
    }

    public boolean remove(int position) {
        if ((position >= 0) && (position < totalValues)) {
            for (int i = position; i < totalValues - 1; i++) {
                values[i] = values[i + 1];
            }
            totalValues--;
            return true;
        } else {
            return false;
        }
    }

    public Object get(int position) {
        if ((position >= 0) && (position < totalValues)) {
            return values[position];
        } else {
            return null;
        }
    }

    public boolean set(int position, Object element) {
        if ((position >= 0) && (position < totalValues)) {
            values[position] = element;
            return true;
        } else {
            return false;
        }
    }

    public int size() {
        return totalValues;
    }

    public int capacity() {
        return values.length;
    }

    @Override
    public String toString() {
        String result = "[";
        boolean first = true;
        for (int i = 0; i < totalValues; i++) {
            if (first) {
                first = false;
            } else {
                result += ", ";
            }
            result += values[i];
        }
        result += "]";
        return result;
    }
}
