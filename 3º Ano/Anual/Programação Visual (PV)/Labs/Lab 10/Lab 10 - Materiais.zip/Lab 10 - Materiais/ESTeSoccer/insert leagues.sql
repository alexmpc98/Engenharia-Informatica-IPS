﻿insert into League ([Name], Country) values ('Liga Bwin', 'Portugal')
go
insert into League ([Name], Country) values ('Premier League', 'Inglaterra')
