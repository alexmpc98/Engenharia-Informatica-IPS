﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MediESTeca.Data
{
    public class CheckDigitAttribute : ValidationAttribute
    {
        private int _numeroDigitos;

        public CheckDigitAttribute(int numeroDigitos)
        {
            if (numeroDigitos > 1 && numeroDigitos < 10)
                _numeroDigitos = numeroDigitos;
        }

        public override bool IsValid(object value)
        {
            int numero = (int)value;

            int checkDigit = numero % 10;
            string numeroTxt = (numero / 10).ToString();

            if (_numeroDigitos != 0 && numero.ToString().Length != _numeroDigitos)
            {
                return false;
            }


            return numeroTxt.Sum(c => Convert.ToInt32(c - '0')) % 10 == checkDigit;
        }
    }
}
