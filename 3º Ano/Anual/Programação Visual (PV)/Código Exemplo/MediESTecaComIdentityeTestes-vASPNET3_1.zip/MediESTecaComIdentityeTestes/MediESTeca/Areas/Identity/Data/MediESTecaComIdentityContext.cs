﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediESTeca.Areas.Identity.Data;
using MediESTeca.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace MediESTeca.Data
{
    public class MediESTecaComIdentityContext : IdentityDbContext<Utente>
    {
        public MediESTecaComIdentityContext(DbContextOptions<MediESTecaComIdentityContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            // Customize the ASP.NET Identity model and override the defaults if needed.
            // For example, you can rename the ASP.NET Identity table names and more.
            // Add your customizations after calling base.OnModelCreating(builder);

            builder.Entity<Livro>().HasData(
                new Livro
                {
                    LivroId = 1,
                    Codigo = 123455,
                    Titulo = "ASP.NET MVC 6",
                    Autor = "Bill Gates",
                    AnoEdicao = 2015
                },
                new Livro
                {
                    LivroId = 2,
                    Codigo = 111115,
                    Titulo = "WPF For Dummies",
                    Autor = "José Braz",
                    AnoEdicao = 2015
                },
                new Livro
                {
                    LivroId = 3,
                    Codigo = 121217,
                    Titulo = "Entity Framework 6",
                    Autor = "Paul Alen",
                    AnoEdicao = 2014
                }
            );
        }

        public DbSet<MediESTeca.Models.Livro> Livro { get; set; }

        public DbSet<MediESTeca.Models.Requisicao> Requisicao { get; set; }
    }
}
