﻿using System;
using MediESTeca.Areas.Identity.Data;
using MediESTeca.Data;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

[assembly: HostingStartup(typeof(MediESTeca.Areas.Identity.IdentityHostingStartup))]
namespace MediESTeca.Areas.Identity
{
    public class IdentityHostingStartup : IHostingStartup
    {
        public void Configure(IWebHostBuilder builder)
        {

            // Comentado na transformação para MediESTeca e movido para startup
            //builder.ConfigureServices((context, services) => {
            //    services.AddDbContext<IdentityMediESTecaComIdentityContext>(options =>
            //        options.UseSqlServer(
            //            context.Configuration.GetConnectionString("MediESTecaComIdentityContextConnection")));

            //    services.AddDefaultIdentity<Utente>(options => options.SignIn.RequireConfirmedAccount = true)
            //        .AddEntityFrameworkStores<MediESTecaComIdentityContext>();
            //});

        }
    }
}