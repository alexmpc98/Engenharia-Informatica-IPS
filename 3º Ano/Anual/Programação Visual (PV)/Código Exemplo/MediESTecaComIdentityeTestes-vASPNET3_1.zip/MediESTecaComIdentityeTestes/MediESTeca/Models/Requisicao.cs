﻿using MediESTeca.Areas.Identity.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace MediESTeca.Models
{
    public class Requisicao
    {
        public int RequisicaoId { get; set; }
        public int LivroId { get; set; }

        [ForeignKey("Utente")]
        public string UtenteId { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Data da Requisição")]
        public DateTime DataRequisicao { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Data de Entrega")]
        public DateTime DataEntrega { get; set; }

        public virtual Livro Livro { get; set; }
        public virtual Utente Utente { get; set; }
    }
}
