﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using MediESTeca.Data;
using Microsoft.AspNetCore.Mvc;

namespace MediESTeca.Models
{
    public class Livro
    {
        public int LivroId { get; set; }

        [Remote(action: "CodigoLivroExists", controller: "Livros")]   // Definido nesta aplicação
        [CheckDigit(6, ErrorMessage = "O {0} é inválido")]  // Definido nesta aplicação
        [Display(Name = "Código")]
        [Required(ErrorMessage = "O {0} é obrigatório")]
        public int Codigo { get; set; }

        [Display(Name = "Título")]
        [StringLength(160, ErrorMessage = "O {0} não deve ter mais do que {1} caracteres")]
        [Required(ErrorMessage = "O {0} é obrigatório")]
        public string Titulo { get; set; }

        [StringLength(160, ErrorMessage = "O {0} não deve ter mais do que {1} caracteres")]
        [Required(ErrorMessage = "O {0} é obrigatório")]
        public string Autor { get; set; }

        [Display(Name = "Ano de Edição")]
        [Range(1582, Int32.MaxValue, ErrorMessage = "O {0} deve ser posterior a 1582")]
        public int? AnoEdicao { get; set; }
    }
}
