using System;
using Xunit;

namespace MediESTecaTest
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
