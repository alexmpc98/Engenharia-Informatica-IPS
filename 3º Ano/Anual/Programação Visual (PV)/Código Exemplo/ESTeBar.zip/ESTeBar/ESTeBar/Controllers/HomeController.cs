﻿using ESTeBar.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace ESTeBar.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }


        [HttpGet]
        public IActionResult ValidarIdade()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ValidarIdade(Pessoa pessoa)
        {
            if (pessoa.Idade >= 18)
            {
                ViewBag.Message = "Podes entrar no bar!";
            }
            else
            {
                ViewBag.Message = "Desculpa, não tens idade para entrar no bar!";
            }

            return View("ValidarIdade2");
        }
    }
}
