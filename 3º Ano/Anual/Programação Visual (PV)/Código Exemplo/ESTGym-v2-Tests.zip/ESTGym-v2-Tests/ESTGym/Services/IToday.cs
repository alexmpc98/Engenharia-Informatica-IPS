﻿namespace ESTGym.Services
{
    public interface IToday
    {
        public string Time { get; }
        public string Date { get; }
    }
}
