﻿using System;

namespace School
{
    public class Program
    {
        static void Main(string[] args)
        {
            School ests = new School();

            ests.Run();
        }
    }
}
