﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PersonApi;

namespace PersonApi.Data
{
    public class PersonApiContext : DbContext
    {
        public PersonApiContext (DbContextOptions<PersonApiContext> options)
            : base(options)
        {
        }

        public DbSet<PersonApi.Person> Person { get; set; }
    }
}
