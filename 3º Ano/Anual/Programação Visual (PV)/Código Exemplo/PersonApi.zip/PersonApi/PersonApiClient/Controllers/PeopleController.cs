﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace PersonApiClient.Controllers
{
    public class PeopleController : Controller
    {
        private HttpClient _httpClient;


        public PeopleController()
        {
            _httpClient = new HttpClient();
            _httpClient.BaseAddress = new Uri("http://localhost:5283");

            // https://localhost:7283/api/people
        }

        // GET: PeopleController
        public async Task<IActionResult> Index()
        {
            List<Person> people = new List<Person>();

            HttpResponseMessage response = await _httpClient.GetAsync("api/people");

            if (response.IsSuccessStatusCode)
            {
                people = await response.Content.ReadAsAsync<List<Person>>();
            }

            return View(people);
        }

        // GET: PeopleController/Details/5
        public async Task<IActionResult> Details(int id)
        {
            Person person = null;

            HttpResponseMessage response = await _httpClient.GetAsync($"api/people/{id}");
            if (response.IsSuccessStatusCode)
            {
                person = await response.Content.ReadAsAsync<Person>();
            }

            return View(person);
        }

        // GET: PeopleController/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: PeopleController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PersonId,Name,Age")] Person person)
        {
            if (person == null)
            {
                return BadRequest();
            }

            try
            {
                HttpResponseMessage response = await _httpClient.PostAsJsonAsync("api/people", person);
                if (response.IsSuccessStatusCode)
                    return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }

            return View();
        }

        // GET: PeopleController/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            Person person = null;

            HttpResponseMessage response = await _httpClient.GetAsync($"api/people/{id}");
            if (response.IsSuccessStatusCode)
            {
                person = await response.Content.ReadAsAsync<Person>();
            }

            return View(person);
        }

        // POST: PeopleController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditAsync(int id, [Bind("PersonId,Name,Age")] Person person)
        {
            if (person == null)
            {
                return BadRequest();
            }

            if (id != person.PersonId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    HttpResponseMessage response = await _httpClient.PutAsJsonAsync($"api/people/{person.PersonId}", person);
                    if (response.IsSuccessStatusCode)
                        return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View();
                }

            }
            return View(person);
        }

        // GET: PeopleController/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            Person person = null;

            HttpResponseMessage response = await _httpClient.GetAsync($"api/people/{id}");
            if (response.IsSuccessStatusCode)
            {
                person = await response.Content.ReadAsAsync<Person>();
            }

            return View(person);
        }

        // POST: PeopleController/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmedAsync(int id)
        {
            HttpResponseMessage response = await _httpClient.DeleteAsync($"api/people/{id}");
            if (response.IsSuccessStatusCode)
                return RedirectToAction(nameof(Index));

            return BadRequest();
        }
    }
}
