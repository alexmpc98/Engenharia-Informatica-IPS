﻿using MediESTeca.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace MediESTeca.Controllers
{
    public class UtentesController : Controller
    {
        private readonly MediESTecaContext _context;

        public UtentesController(MediESTecaContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            return View(await _context.Utente.AsNoTracking().ToListAsync());
        }
    }
}
