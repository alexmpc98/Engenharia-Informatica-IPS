﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MediESTeca.Migrations
{
    public partial class inicial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Livro",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Isbn = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Titulo = table.Column<string>(type: "nvarchar(160)", maxLength: 160, nullable: false),
                    Autor = table.Column<string>(type: "nvarchar(160)", maxLength: 160, nullable: false),
                    AnoEdicao = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Livro", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Utente",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nome = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Telefone = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Utente", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Requisicao",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LivroId = table.Column<int>(type: "int", nullable: false),
                    UtenteId = table.Column<int>(type: "int", nullable: false),
                    DataRequisicao = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DataEntrega = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Requisicao", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Requisicao_Livro_LivroId",
                        column: x => x.LivroId,
                        principalTable: "Livro",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Requisicao_Utente_UtenteId",
                        column: x => x.UtenteId,
                        principalTable: "Utente",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Livro",
                columns: new[] { "Id", "AnoEdicao", "Autor", "Isbn", "Titulo" },
                values: new object[,]
                {
                    { 1, 2015, "Bill Gates", "0868910341", "ASP.NET MVC 6" },
                    { 2, 2015, "José Braz", "0145190277", "WPF For Dummies" },
                    { 3, 2014, "Paul Alen", "0501083731", "Entity Framework 6" }
                });

            migrationBuilder.InsertData(
                table: "Utente",
                columns: new[] { "Id", "Nome", "Telefone" },
                values: new object[,]
                {
                    { 1, "João Manuel", 123456789 },
                    { 2, "Ana Sofia", 234567890 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Requisicao_LivroId",
                table: "Requisicao",
                column: "LivroId");

            migrationBuilder.CreateIndex(
                name: "IX_Requisicao_UtenteId",
                table: "Requisicao",
                column: "UtenteId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Requisicao");

            migrationBuilder.DropTable(
                name: "Livro");

            migrationBuilder.DropTable(
                name: "Utente");
        }
    }
}
