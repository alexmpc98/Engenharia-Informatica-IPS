package com.pa.patterns.observerimpl.observer;

import java.util.Optional;

/**
 *
 * @author patriciamacedo
 */
public interface Observer {
    /**
     * When a observer is notified execute this function
     * @param observable - argument of the method
     */
    void update(Observable observable);

}

