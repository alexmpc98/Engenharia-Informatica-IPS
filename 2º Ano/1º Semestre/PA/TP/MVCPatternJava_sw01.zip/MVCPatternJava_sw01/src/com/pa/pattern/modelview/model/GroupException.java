package com.pa.pattern.modelview.model;

public class GroupException extends RuntimeException {
    public GroupException(String s) {
        super(s);
    }
}
