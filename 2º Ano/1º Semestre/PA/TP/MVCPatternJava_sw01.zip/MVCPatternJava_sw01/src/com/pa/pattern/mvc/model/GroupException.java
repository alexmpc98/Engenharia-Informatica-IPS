package com.pa.pattern.mvc.model;

public class GroupException extends RuntimeException {
    public GroupException(String s) {
        super(s);
    }
}
