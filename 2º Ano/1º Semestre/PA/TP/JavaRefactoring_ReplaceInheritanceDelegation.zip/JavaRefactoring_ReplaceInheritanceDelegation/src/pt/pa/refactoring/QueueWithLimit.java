package pt.pa.refactoring;

import java.util.ArrayList;

public class QueueWithLimit<T> implements Queue<T> {

    private ArrayList<T> list;
    private final int CONSTANTE_SIZE= 10;

    public QueueWithLimit() {
        this.list = new ArrayList<T>();
    }

    @Override
    public void enqueue(T elem) throws QueueFullException, NullPointerException {
        if(elem == null) throw new NullPointerException("Null not allowed.");

        if(size() >= CONSTANTE_SIZE) throw new QueueFullException("Queue reached its limit (is full).");

        list.add(elem);
    }

    @Override
    public T dequeue() throws QueueEmptyException {
        if(isEmpty()) throw new QueueEmptyException();

        return list.remove(0);
    }

    @Override
    public T front() throws QueueEmptyException {
        if(isEmpty()) throw new QueueEmptyException();

        return list.get(0);
    }

    /**
     * The number of elements stored in the queue.
     *
     * @return element count.
     */
    @Override
    public int size() {
        return list.size();
    }

    /**
     * Whether the queue is empty or not.
     *
     * @return <i>true</i> if que queue is empty; <i>false</i> otherwise.
     */
    @Override
    public boolean isEmpty() {
        return list.isEmpty();
    }

    /**
     * Clears the contents of the queue, returning to an empty state.
     */
    @Override
    public void clear() {
        this.list.clear();
    }
}
