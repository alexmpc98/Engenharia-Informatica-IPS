package com.pa.refatoring.extractclass;

/* extract class */
public class Calculator {

    /* move field */
    private int total;

    public Calculator() {
        this.total = 1;
    }

    /* move methods x 2*/
    public void reset() {
        total = 1;
    }

    public void multiplyBy(int operand) {
        total = total * operand;
    }

    public int getTotal() {
        return total;
    }
}
