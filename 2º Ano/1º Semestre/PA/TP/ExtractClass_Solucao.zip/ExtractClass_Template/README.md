#Exercício

Aplique a Técnica **Extract Class** de forma a fazer uma correta separação das responsabilidades.
No fim deverá ter 3 classes:
- `AppMainCalculator` - classe responsável por lançar a aplicação JAVAFX
- `CalculatorUI` - classe responsável por implemenatr a interação com o Utilizador
- `Calculator` - classe responsavel por implemenatr a lógica do calculador