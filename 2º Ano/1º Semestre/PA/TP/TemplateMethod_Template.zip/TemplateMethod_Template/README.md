#Exercício

Aplique a técnica **Form Template Method** de forma a resolver a duplicação 
de código ( **Duplicated Code** ) no método `formatMessage` nas subclasses `B` e `C`.
