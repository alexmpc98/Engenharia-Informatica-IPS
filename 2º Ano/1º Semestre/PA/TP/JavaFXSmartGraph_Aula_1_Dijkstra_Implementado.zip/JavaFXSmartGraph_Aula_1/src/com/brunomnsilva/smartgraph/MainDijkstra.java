package com.brunomnsilva.smartgraph;

import com.brunomnsilva.smartgraph.containers.SmartGraphDemoContainer;
import com.brunomnsilva.smartgraph.graph.Edge;
import com.brunomnsilva.smartgraph.graph.Graph;
import com.brunomnsilva.smartgraph.graph.GraphEdgeList;
import com.brunomnsilva.smartgraph.graph.Vertex;
import com.brunomnsilva.smartgraph.graphview.SmartCircularSortedPlacementStrategy;
import com.brunomnsilva.smartgraph.graphview.SmartGraphPanel;
import com.brunomnsilva.smartgraph.graphview.SmartPlacementStrategy;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.util.*;

public class MainDijkstra extends Application {

    @Override
    public void start(Stage ignore) throws Exception {
        Graph<String, EdgeElement> g = slidesGraph();

        SmartPlacementStrategy strategy = new SmartCircularSortedPlacementStrategy();
        //SmartPlacementStrategy strategy = new SmartRandomPlacementStrategy();
        SmartGraphPanel<String, EdgeElement> graphView = new SmartGraphPanel<>(g, strategy);

        Scene scene = new Scene(new SmartGraphDemoContainer(graphView), 1024, 768);

        Stage stage = new Stage(StageStyle.DECORATED);
        stage.setTitle("JavaFX SmartGraph Visualization");
        stage.setMinHeight(500);
        stage.setMinWidth(800);
        stage.setScene(scene);
        stage.show();

        graphView.init();

        Vertex<String> root = null;
        for(Vertex<String> v : g.vertices()) {
            if(v.element().equalsIgnoreCase("B")) {
                root = v;
            }
        }

        Dijkstra(g, root);

    }

    public static void Dijkstra(Graph<String, EdgeElement> g, Vertex<String> vertex_root) {
        List<Vertex<String>> visited = new ArrayList<>();
        List<Vertex<String>> unvisited = new ArrayList<>();
        Map<Vertex<String>, Double> distances = new HashMap<>();
        Map<Vertex<String>, Vertex<String>> predecessors = new HashMap<>();

        /* Inicialização */
        for(Vertex<String> v : g.vertices()) {
            distances.put(v, Double.MAX_VALUE);
            predecessors.put(v, null);

            unvisited.add(v);
        }
        distances.put(vertex_root, 0.0);

        System.out.println(distances);

        /* Iterações do algoritmo */
        while(!unvisited.isEmpty()) {

            Vertex<String> current = findLowerCostVertice(distances, unvisited);

            unvisited.remove(current);

            Collection<Edge<EdgeElement, String>> edges = g.incidentEdges(current);
            for(Edge<EdgeElement, String> e : edges) {
                Vertex<String> vExplore = g.opposite(current, e);
                if(unvisited.contains(vExplore)) {

                    double currentCost = distances.get(current);
                    double edgeCost = e.element().getValue();
                    double total = currentCost + edgeCost;

                    double vExploreCost = distances.get(vExplore);

                    if(total < vExploreCost) {
                        distances.put(vExplore, total);
                        predecessors.put(vExplore, current);
                    }
                }
            }
        }

        System.out.println(distances);
        System.out.println(predecessors);
    }

    public static Vertex<String> findLowerCostVertice(Map<Vertex<String>, Double> distances,
                                                      List<Vertex<String>> unvisited) {
        Vertex<String> selected = null;
        double minDistance = Double.MAX_VALUE;

        for(Vertex<String> v : unvisited) {
            double cost = distances.get(v);
            if(cost < minDistance) {
                minDistance = cost;
                selected = v;
            }
        }

        return selected;
    }

    private static Graph<String, EdgeElement> slidesGraph() {
        Graph<String, EdgeElement> g = new GraphEdgeList<>();

        Vertex<String> a = g.insertVertex("A");
        Vertex<String> b = g.insertVertex("B");
        Vertex<String> c = g.insertVertex("C");
        Vertex<String> d = g.insertVertex("D");
        Vertex<String> e = g.insertVertex("E");

        g.insertEdge(a,b,new EdgeElement("ab", 6));
        g.insertEdge(a,d,new EdgeElement("ad", 1));
        g.insertEdge(d,b,new EdgeElement("db", 2));
        g.insertEdge(d,e,new EdgeElement("de", 1));
        g.insertEdge(b,e,new EdgeElement("be", 2));
        g.insertEdge(b,c,new EdgeElement("bc", 5));
        g.insertEdge(e,c,new EdgeElement("ec", 5));

        return g;
    }

    private static Random random = new Random( 100 /*seeding number*/);

    private static Graph<String, EdgeElement> randomGraph() {
        Graph<String, EdgeElement> generated = new GraphEdgeList<>();

        List<Vertex<String>> vertices = new ArrayList<>();

        /* Generate 10 random vertices */
        for(int i=1; i<=10; i++) {
            Vertex<String> v = generated.insertVertex("v" + i);
            vertices.add(v);
        }

        /* Gerar 20 arestas aleatorias */
        for(int i=0; i<20; i++) {
            Vertex<String> v1 = vertices.get(random.nextInt(10));
            Vertex<String> v2 = vertices.get(random.nextInt(10));
            if(v1 != v2) {
                generated.insertEdge(v1, v2, new EdgeElement(""+v1+v2, (random.nextInt(10)+1)));
            }
        }

        return generated;

    }
}
