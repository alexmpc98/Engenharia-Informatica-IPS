package com.brunomnsilva.smartgraph;

public class EdgeElement {
    String id;
    int value;

    public EdgeElement(String id, int value) {
        this.id = id;
        this.value = value;
    }

    public String getId() {
        return id;
    }

    public int getValue() {
        return value;
    }

    @Override
    public String toString() {
        return ""+getValue();
    }
}
