package pt.pa.refactoring;

public class District {

    private String districtName;
    private int population;

    public District(String districtName, int population) {
        this.districtName = districtName;
        this.population = population;
    }

    public boolean isDistrict(String name){
        return districtName.equals(name);
    }

    public String getDistrictName() {
        return districtName;
    }

    public int getPopulation() {
        return population;
    }

}
