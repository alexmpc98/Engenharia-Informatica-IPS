package pt.pa.refactoring;

import java.util.ArrayList;
import java.util.List;

public class DistrictData {

    private List<District> districts;

    public DistrictData() {
        districts = new ArrayList<>();
    }

    public boolean add(String district, int population) {
        if(!containsDistrict(district)) {
            //Object[] data = new Object[]{district, population};
            District d = new District(district,population);
            districts.add(d);
            return true;
        }
        return false;
    }

    private boolean containsDistrict(String district) {
        for(int i=0; i<districts.size(); i++) {
            //Object[] data = districts.get(i);
            District d = districts.get(i);

            if(d.isDistrict(district)) return true;
        }
        return false;
    }

    public int getTotalPopulation() {
        int total = 0;
        for(int i=0; i<districts.size(); i++) {
            //Object[] data = districts.get(i);
            District d = districts.get(i);

            total += d.getPopulation();
        }
        return total;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-20s | %5s\n", "District", "Population"));
        sb.append(String.format("%-20s | %5s\n", "--------", "----------"));
        for(int i=0; i<districts.size(); i++) {
            //Object[] data = districts.get(i);
            District d = districts.get(i);

            sb.append(String.format("%-20s | %5d\n", d.getDistrictName(), d.getPopulation()));
        }
        return sb.toString();
    }
}
