package com.pa.patterns.command;

public class CommandCodify extends CommandMessage {

    public CommandCodify(Message msg) {
        super(msg);
    }

    @Override
    public void execute() {
        String s = msg.getTxt().replace('a','?');
        s = s.replace('i','$');
        s = s.replace('e','£');

        msg.setTxt( s );
        msg.setDate();
    }

    @Override
    public void unExecute() {
        String s = msg.getTxt().replace('?','a');
        s = s.replace('$','i');
        s = s.replace('£','e');

        msg.setTxt( s );
        msg.setDate();
    }
}
