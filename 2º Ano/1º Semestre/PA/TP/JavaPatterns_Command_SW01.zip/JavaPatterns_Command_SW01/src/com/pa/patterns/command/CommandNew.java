/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pa.patterns.command;

/**
 *
 * @author patricia.macedo
 */

/**
 * Concrete Command
 * Create a new information for the message
 */
public class CommandNew extends CommandMessage {

    private String text;
    private String oldText;

    public CommandNew(Message msg,String text)  {
        super(msg);
        this.text=text;
    }


    @Override
    public void execute() {
        oldText = msg.getTxt();

        msg.setTxt(text);
        msg.setDate();
    }

    @Override
    public void unExecute() {
        msg.setTxt(oldText);
        msg.setDate();
    }

    @Override
    public String toString() {
        return "CommandNew{}";
    }
}
