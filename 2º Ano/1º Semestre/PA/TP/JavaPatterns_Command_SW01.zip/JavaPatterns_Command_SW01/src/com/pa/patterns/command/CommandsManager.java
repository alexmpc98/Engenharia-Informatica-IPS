/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pa.patterns.command;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;


/**
 * @author PM
 */

/**
 * Invoker
 * Manage the commands, invoke the execution of commands.
 */
public class CommandsManager {

    //TODO: fazer com que as modificacoes da macro tambem possam ser desfeitas!!

    private static final String FILENAME_OUT = "msgoOut.txt";

    private final Stack<Command> commandsDone;

    private final List<Command> macroCommands;
    private boolean isRecording;

    public CommandsManager() {
        commandsDone = new Stack();
        macroCommands = new ArrayList<>();
        isRecording = false;
    }

    public void stopMacro() {
        isRecording = false;
    }

    public void playMacro() {
        for(Command c : macroCommands) {
            c.execute();
            // aqui?!
        }
    }

    public void newMacro() {
        macroCommands.clear();
        isRecording = true;
    }

    public void undo() {
       if(commandsDone.isEmpty()) return;

        Command cmd = commandsDone.pop();
        cmd.unExecute();
    }

    public void executeCmd(Command cmd) {
        if(isRecording) {
            macroCommands.add(cmd);
        } else {
            cmd.execute();
            commandsDone.push(cmd);
        }
    }


    public String listAll() {
        String str="";
        int count=1;
        for (Command cmd : commandsDone)
        {
            str= str + (count++) + "-> " + cmd.toString() + "\n";

        }
        return str;

    }
}
