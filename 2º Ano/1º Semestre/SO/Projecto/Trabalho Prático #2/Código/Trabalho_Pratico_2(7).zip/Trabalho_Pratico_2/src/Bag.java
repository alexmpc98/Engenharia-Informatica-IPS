import java.util.ArrayList;

public class Bag {
    ArrayList<Integer> knapsackBin;

    public void setKnapsack(ArrayList<Integer> knapsackBin) {
        this.knapsackBin = knapsackBin;
    }

    public ArrayList<Integer> getKnapsackBin() {
        return knapsackBin;
    }

    public void setKnapsackBin(ArrayList<Integer> knapsackBin) {
        this.knapsackBin = knapsackBin;
    }
}
