import java.util.*;

public class Main extends Thread {

    @Override
    public void run() {
        // CALLS THE FUNCTION THAT MODIFIES KNAPSACK
        modifyKnapsack(getName());
    }

    public static void main(String[] args) {
        // INITIALIZES THE NUMBER OF THREADS TO CREATE
        int iterationNumber = 1;

        // CREATES N THREADS
        for (int i = 0; i < iterationNumber; i++) {
            Main newThread = new Main();
            newThread.start();
        }
    }

    // FUNCTION THAT MODIFIES THE KNAPSACK
    void modifyKnapsack(String threadName) {
        // INITIALIZATES THE FILES VALUES
        /*int valuesArray[] = {60, 40, 90, 15, 100, 15, 1, 10};
        int weightsArray[] = {30, 40, 20, 2, 20, 30, 10, 60};*/
        int knapsackVW[][] = {
                {60, 30},
                {40, 40},
                {90, 20},
                {15, 2},
                {100, 20},
                {15, 30},
                {1, 10},
                {10, 60}
        };
        int n = 8;
        int bestWeight = 102;
        ArrayList<Integer> bagLower = new ArrayList<Integer>(n);
        ArrayList<Integer> bagUpper = new ArrayList<Integer>(n);
        for (var i = 0; i < n; i++) {
            bagLower.add(0);
            bagUpper.add(0);
        }
        ArrayList<Integer> sortedValues = new ArrayList<Integer>(n);
        ArrayList<Integer> sortedWeights = new ArrayList<Integer>(n);

        int weightSumLower = 0;
        int valueSumLower = 0;
        int weightSumUpper= 0;
        int valueSumUpper = 0;
        int cLower = 0;
        int cUpper = 0;

        // INITIALIZES THE KNAPSACK ARRAY LIST
        ArrayList<Knapsack> knapsack = new ArrayList<Knapsack>(n);

        // INITIALIZES THE SHARED MEMORY
        SharedMemory sharedMemory = new SharedMemory();

        for (int i = 0; i < n; i++) {
            // INITIALIZES THE KNAPSACK CLASS
            Knapsack knapsackClass = new Knapsack();
            knapsackClass.setKnapsack(knapsackVW[i][0], knapsackVW[i][1], (double) knapsackVW[i][0] / knapsackVW[i][1]);
            knapsack.add(knapsackClass);
            System.out.println(knapsack.get(i).toString());
        }

        // SORTS THE KNAPSACK ARRAY LIST
        Collections.sort(knapsack);

        // SETS THE VALUES FOR THE SORTED ARRAY LISTS
        for (int i = 0; i < n; i++) {
            sortedValues.add(knapsack.get(i).knapsackValues);
            sortedWeights.add(knapsack.get(i).knapsackWeights);
        }

        for (int i = 0; i < n; i++) {
            if ((weightSumLower + knapsack.get(i).knapsackWeights) < bestWeight) {
                weightSumLower += knapsack.get(i).knapsackWeights;
                valueSumLower += knapsack.get(i).knapsackValues;
                bagLower.set(i, 1);
            } else {
                cLower = i + 1;
                break;
            }
        }

        for (int i = 0; i < n; i++) {
            if ((weightSumUpper + knapsack.get(i).knapsackWeights) < bestWeight) {
                weightSumUpper += knapsack.get(i).knapsackWeights;
                valueSumUpper += knapsack.get(i).knapsackValues;
                bagUpper.set(i, 1);
            } else {
                cUpper = i + 1;
                break;
            }
        }

        System.out.println(weightSumLower + " - " + valueSumLower + " - " + cLower);
        System.out.println(weightSumUpper + " - " + valueSumUpper + " - " + cUpper);
        System.out.println(Arrays.asList(bagLower));
        System.out.println(Arrays.asList(bagUpper));
        System.out.println(Arrays.asList(sortedValues));
        System.out.println(Arrays.asList(sortedWeights));
    }
}