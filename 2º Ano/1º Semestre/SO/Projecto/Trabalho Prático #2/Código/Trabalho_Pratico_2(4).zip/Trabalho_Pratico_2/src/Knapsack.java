
public class Knapsack implements Comparable<Knapsack>{
    int knapsackValues;
    int knapsackWeights;
    double knapsackCalc;

    public void setKnapsack(int knapsackValues, int knapsackWeights, double knapsackCalc) {
        this.knapsackValues = knapsackValues;
        this.knapsackWeights = knapsackWeights;
        this.knapsackCalc = knapsackCalc;
    }

    public int getKnapsackValues() {
        return knapsackValues;
    }

    public int getKnapsackWeights() {
        return knapsackWeights;
    }

    public double getKnapsackCalc() {
        return knapsackCalc;
    }

    public int compareTo(Knapsack knap){
        if(this.knapsackCalc<knap.knapsackCalc)
            return 1;
        else if(knap.knapsackCalc<this.knapsackCalc)
            return -1;
        return 0;
    }

    @Override
    public String toString() {
        return "Knapsack{" +
                "knapsackValues=" + knapsackValues +
                ", knapsackWeights=" + knapsackWeights +
                ", knapsackCalc=" + knapsackCalc +
                '}';
    }


    public String toStringCalc() {
        return "Knapsack{" +
                "knapsackCalc=" + knapsackCalc +
                '}';
    }
}
