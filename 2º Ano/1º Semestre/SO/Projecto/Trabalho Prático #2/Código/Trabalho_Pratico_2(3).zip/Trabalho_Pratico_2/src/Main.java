import java.util.Arrays;
import java.util.Random;

public class Main extends Thread{

    @Override
    public void run() {
        // CALLS THE FUNCTION THAT MODIFIES KNAPSACK
        modifyKnapsack(getName());
    }

    public static void main(String[] args) {
        // INITIALIZES THE NUMBER OF THREADS TO CREATE
        int iterationNumber = 2;

        // CREATES N THREADS
        for (int i = 0; i < iterationNumber; i++) {
            Main newThread = new Main();
            newThread.start();
        }
    }

    // FUNCTION THAT MODIFIES THE KNAPSACK
    void modifyKnapsack(String threadName)  {
        // INITIALIZATES THE FILES VALUES
        int valuesArray[] = {6, 10, 12, 13};
        int weightsArray[] = {2, 4, 6, 7};
        int n = 4;
        int bestWeight = 11;

        // INITIALIZES THE SUM VARIABLES
        int valueSum = 0;
        int weightSum = 0;
        int bestWeightSum = 0;

        // INITIALIZES THE KNAPSACK
        int temporary_knapsack[] = new int[n];
        for (int i = 0; i < n; i++) {
            temporary_knapsack[i] = 0;
        }

        // INITIALIZES THE KNAPSACK
        Knapsack knapsack = new Knapsack();

        // SET THE KNAPSACK TO 0
        knapsack.setKnapsack(temporary_knapsack);

        // INITIALIZES THE KNAPSACK VALUES
        KnapsackValues knapsackValues = new KnapsackValues();
        knapsackValues.setKnapsackValues(valuesArray);

        // INITIALIZES THE KNAPSACK WEIGHTS
        KnapsackWeights knapsackWeights = new KnapsackWeights();
        knapsackWeights.setKnapsackWeights(weightsArray);

        // INITIALIZES THE SHARED MEMORY
        SharedMemory sharedMemory = new SharedMemory();

        // CREATES A RANDOM OBJECT
        Random generator = new Random();

        for (int i = 0; i < 10; i++) {
            // GENERATES A RANDOM NUMBER
            int random_number = generator.nextInt(n);

            // CALLS THE FUNCTION THAT CHANGES THE KNAPSACK VALUES
            knapsack.changeKnapsack(1 - knapsack.getChangedValueKnapsack(random_number), random_number);

            // CALL THE FUNCTION THAT CALCULATES THE VALUE SUM
            valueSum = knapsackValues.calculate_value (knapsackValues.getKnapsackValues(), knapsack.getKnapsack(), n);

            // CALL THE FUNCTION THAT CALCULATES THE WEIGHT SUM
            weightSum = knapsackWeights.calculate_weight(knapsackWeights.getKnapsackWeights(), knapsack.getKnapsack(), n);

            // CHECKS IF THE WEIGHT SUM CALCULATED IS BEST THAN THE EXISTING ONE
            if (weightSum > bestWeightSum && weightSum <= bestWeight && sharedMemory.getBestWeight() < weightSum) {
                bestWeightSum = weightSum;
                sharedMemory.setThreadName(threadName);
                sharedMemory.setBestWeight(weightSum);
                sharedMemory.setBestKnapsack(knapsack.getKnapsack());
            }

            // PRINTS THE CURRENT BEST WEIGHT SUM
            System.out.println("------------------------------------------------------------");
            System.out.println("Thread: " + threadName + " | KS: " + Arrays.toString(knapsack.getKnapsack()) + " | Value: " + valueSum + " | Weight: "+ weightSum);
            System.out.println("------------------------------------------------------------\n");
        }

        // PRINTS THE SHARED MEMORY VALUES
        System.out.println(sharedMemory.toString());
    }
}