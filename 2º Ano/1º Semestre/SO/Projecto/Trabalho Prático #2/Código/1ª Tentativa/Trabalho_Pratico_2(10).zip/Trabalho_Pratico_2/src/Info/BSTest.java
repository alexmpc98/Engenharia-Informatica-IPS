/*package Info;


public class BSTest {
    

    
    

    

    
    
    public static void main(String [] args) {
        String fileName = "ex08_ordered.txt";
        
        importTable(fileName);
        
        // Initial level
        int level = 0;
        
        // Initialize a new "blank" solution and add it to the new listSol
        ArrayList<Solution> listSol = new ArrayList<Solution>();
        Solution s = new Solution(n);
        listSol.add(s);
        
        System.out.println("Level 0");
        System.out.println("-----------------------------------");
        for (int i=0; i < listSol.size(); i++)
            listSol.get(i).show();
        
        
        // Generate the childs for the level 1
        getChilds(listSol,level);
        System.out.println("\nLevel 1");
        System.out.println("-----------------------------------");
        for (int i=0; i < listSol.size(); i++)
            listSol.get(i).show();
               
        // Generate the childs for the level 2
        level++;
        getChilds(listSol,level);
        System.out.println("\nLevel 2");
        System.out.println("-----------------------------------");
        for (int i=0; i < listSol.size(); i++) {
            listSol.get(i).show();
        }
        
        // Generate the childs for the level 3
        level++;
        getChilds(listSol,level);
        System.out.println("\nLevel 3");
        System.out.println("-----------------------------------");
        for (int i=0; i < listSol.size(); i++) {
            listSol.get(i).show();
        }

        // Generate the childs for the level 4
        level++;
        getChilds(listSol,level);
        System.out.println("\nLevel 4");
        System.out.println("-----------------------------------");
        for (int i=0; i < listSol.size(); i++) {
            listSol.get(i).show();
        }

        // Generate the childs for the level 5
        level++;
        getChilds(listSol,level);
        System.out.println("\nLevel 5");
        System.out.println("-----------------------------------");
        for (int i=0; i < listSol.size(); i++) {
            listSol.get(i).show();
        }

        // Generate the childs for the level 6
        level++;
        getChilds(listSol,level);
        System.out.println("\nLevel 6");
        System.out.println("-----------------------------------");
        for (int i=0; i < listSol.size(); i++) {
            listSol.get(i).show();
        }

        // Generate the childs for the level 7
        level++;
        getChilds(listSol,level);
        System.out.println("\nLevel 7");
        System.out.println("-----------------------------------");
        for (int i=0; i < listSol.size(); i++) {
            listSol.get(i).show();
        }

        // Generate the childs for the level 8
        level++;
        getChilds(listSol,level);
        System.out.println("\nLevel 8");
        System.out.println("-----------------------------------");
        for (int i=0; i < listSol.size(); i++) {
            listSol.get(i).show();
        }
    }
    
}*/
