#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <semaphore.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>
// CACULATES THE VALUE
int calc_value (int *values, int *knapsack, int n) {
  int value_sum = 0;
    for (int i=0;i<n;i++) {
      value_sum = value_sum  + (values[i] * knapsack[i]);
    }
    return value_sum;
}

// CALCULATES THE WEIGHT
int calc_weight (int *weights, int *knapsack, int n) {
  int weight_sum = 0;
    for (int i=0;i<n;i++) {
      weight_sum = weight_sum  + (weights[i] * knapsack[i]);
    }
    return weight_sum;
}

// MODIFIES THE KNAPSACK
void modify_knapsack (
    int *knapsack,
    int *weights,
    int *values,
    int n,
    int process_id,
    int *sm_bestVal,
    int *sm_pid
  ){
  int random = 0;
  int x = 0;
  int value = 0;
  int weight = 0;
  int best_value = 0;
  int best_weight = 0;
  //for (int i=0;i<100;i++)
  while(1){
    random = rand() % n;
    x = knapsack[random];
    x = 1 - x;
    knapsack[random] = x;
    int value = calc_value (values, knapsack, n);
    int weight = calc_weight (weights, knapsack, n);
    if (weight <= 11 && value >= best_value) {
      best_value = value ;
      best_weight = weight ;
    }
  }
  if (*sm_bestVal < best_value) {
    *sm_bestVal = best_value;
    *sm_pid = process_id;
  }
  //printf("\nRandom: %d\n", random);
  printf("Process ID: %d\n", *sm_pid);
  printf("Values Sum: %d\n", best_value);
  printf("Weight Sum %d\n", best_weight);
  printf("MEMORY %d\n", *sm_bestVal);
}

void signal_handler(int signal)
{
  printf("Child PID=%d is exiting\n", getpid());
}

int main(int argc, char *argv[]) {
  // INICIATES RANDOM NUMBERS
  srand(time(NULL));
  // INICIATES THE SIGNAL
  signal(SIGKILL, signal_handler);
  // INICIATES THE ARRAYS AND OTHER VARIABLES
  int weights[] = {2,4,6,7};
  int values[] = {6,10,12,13};
  int n = 4;
  int max_weight = 11;
  int knapsack[] = {0,0,0,0};
  int best_knapsack[] = {};
  int test_number = 0;
  char filename [] = {};
  int fork_number = 0;
  int run_time = 0; //SECONDS
  // CREATES THE SHARED MEMORY
  int size = 64;
  int protection = PROT_READ | PROT_WRITE;
  int visibility = MAP_ANONYMOUS | MAP_SHARED;
  int *sm_bestVal = mmap(NULL, sizeof(int), protection, visibility, 0, 0);
  int *sm_pid = mmap(NULL, sizeof(int), protection, visibility, 0, 0);

  if (argc = 3) {
    test_number = atoi(argv[1]);
    strcpy(filename, argv[2]);
    fork_number = atoi(argv[3]);
    run_time = atoi(argv[4]);
    printf("YOYO: %d\n", test_number);
    printf("YOYO: %s\n", filename);
    printf("YOYO: %d\n", fork_number);
    printf("YOYO: %d\n", run_time);
  }

  for (int i =0;i<fork_number;i++) {
    int process_id = fork();
    if (process_id == 0) {
      printf("--------  PID: %d -------- \n", getpid());
      modify_knapsack(knapsack, weights, values, n, getpid(), sm_bestVal, sm_pid);
      exit(0);
    } else {
    }
  }
  sleep(run_time);

  for (int i =0;i<fork_number;i++) {
    kill(getpid(),SIGKILL);
    wait(NULL);
  }
  return 0;
}
