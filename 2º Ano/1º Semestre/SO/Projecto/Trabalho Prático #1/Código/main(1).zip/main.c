#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// CACULATES THE VALUE
int calc_value (int *values, int *knapsack, int n) {
  int value_sum = 0;
    for (int i=0;i<n;i++) {
      value_sum = value_sum  + (values[i] * knapsack[i]);
    }
    return value_sum;
}

// CALCULATES THE WEIGHT
int calc_weight (int *weights, int *knapsack, int n) {
  int weight_sum = 0;
    for (int i=0;i<n;i++) {
      weight_sum = weight_sum  + (weights[i] * knapsack[i]);
    }
    return weight_sum;
}

// MODIFIES THE KNAPSACK
void modify_knapsack (int *knapsack, int *weights, int *values, int n) {
  int random = 0;
  int x = 0;
  int value = 0;
  int weight = 0;
  int best_value = 0;
  for (int i=0;i<100;i++) {
    random = rand() % n;
    x = knapsack[random];
    x = 1 - x;
    knapsack[random] = x;
    int value = calc_value (values, knapsack, n);
    int weight = calc_weight (weights, knapsack, n);
    printf("\nRandom: %d\n", random);
    printf("Values Sum: %d\n", value);
    printf("Weight Sum %d\n", weight);
    if (weight <= 11) {

      printf("BEST\n\n");
    }
  }
}

int main() {
  // INICIATES RANDOM NUMBERS
  srand(time(NULL));
  // INICIATES THE ARRAYS AND OTHER VARIABLES
  int weights[] = {2,4,6,7};
  int values[] = {6,10,12,13};
  int n = 4;
  int max_weight = 11;
  int knapsack[] = {0,0,0,0};
  int best_knapsack[] = {};

  modify_knapsack(knapsack, weights, values, n);
  return 0;
}
