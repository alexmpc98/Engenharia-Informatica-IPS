Nesta pasta estão:
	Os ficheiros com os dados para teste;
	O documento pdf com os dados dos testes realizados;
	O ficheiro com o código do algoritmo (main.c);
	O makefile com o código de compilação e execução para testar o ficheiro ex04_11.txt.