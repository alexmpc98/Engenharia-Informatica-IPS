#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <semaphore.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>

// CACULATES THE VALUE
int calc_value (int *values, int bag_values[], int n) {
  int value_sum = 0;
    for (int i=0;i<n;i++) {
      value_sum = value_sum  + (values[i] * bag_values[i]);
    }
    return value_sum;
}

// CALCULATES THE WEIGHT
int calc_weight (int *weights, int bag_values[], int n) {
  int weight_sum = 0;
    for (int i=0;i<n;i++) {
      weight_sum = weight_sum  + (weights[i] * bag_values[i]);
    }
    return weight_sum;
}

// MODIFIES THE KNAPSACK
void modify_knapsack (
    int process_id,
    int* knapsack,
    int* values,
    int* weights,
    int n,
    int max_weight,
    int bestValue,
    int *sm_bestVal,
    int *sm_pid,
    double *sm_time,
    clock_t begin,
    sem_t *mutex
  ){
  // INICIATES THE BAG VARIABLES
  //int knapsack[] = {0,0,0,0};
  int random = 0;
  int x = 0;
  int value = 0;
  int weight = 0;
  int running_time = 0;
  int in = 0; // ITERATION NUMBER
  while(1){
    running_time += 1;
    random = rand() % n;
    x = knapsack[random];
    x = 1 - x;
    knapsack[random] = x;
    value = calc_value (values, knapsack, n);
    weight = calc_weight (weights, knapsack, n);
    sem_wait(mutex);
    if (bestValue == 0) {
      if (weight <= max_weight && value > *sm_bestVal) {
        *sm_bestVal = value;
        *sm_pid = process_id;
        clock_t end = clock();
        double bestTime = (double)(end - begin)/CLOCKS_PER_SEC * -1;
        *sm_time = bestTime;
        /*printf("PID: %d\n", process_id);
        printf("Values Sum: %d\n", value);
        printf("Weight Sum %d\n", weight);*/
      }
    } else {
      if (weight <= max_weight && value == bestValue && value > *sm_bestVal) {
        *sm_bestVal = value;
        *sm_pid = process_id;
        clock_t end = clock();
        double bestTime = (double)(end - begin)/CLOCKS_PER_SEC * -1;
        *sm_time = bestTime;
        /*printf("PID: %d\n", process_id);
        printf("Values Sum: %d\n", value);
        printf("Weight Sum %d\n", weight);*/
      }
    }
    sem_post(mutex);
    in++;
  }
}

int main(int argc, char *argv[]) {

  // START TIME
  clock_t begin = clock();

  // CREATES THE SEMAPHORE
  sem_unlink("mymutex");
  sem_t *mutex = sem_open("mymutex", O_CREAT, 0644, 1);

  // INICIATES RANDOM NUMBERS
  srand(time(NULL));

  // INICIATES THE ARRAYS AND OTHER VARIABLES
  int n, max_weight, bestValue;
  int temp, temp2, num;
  int hasBestValue = 0;
  int test_number = 0;
  char filename [30] = {};
  int fork_number = 0;
  int forks_id [] = {};
  int run_time = 0; //SECONDS

  // CREATES THE SHARED MEMORY
  int size = 64;
  int protection = PROT_READ | PROT_WRITE;
  int visibility = MAP_ANONYMOUS | MAP_SHARED;
  int *sm_bestVal = mmap(NULL, sizeof(int), protection, visibility, 0, 0);
  int *sm_pid = mmap(NULL, sizeof(int), protection, visibility, 0, 0);
  double *sm_time = mmap(NULL, sizeof(double), protection, visibility, 0, 0);

  // READ RUNNING PARAMETERS
  if (argc = 3) {
    test_number = atoi(argv[1]);
    strcpy(filename, argv[2]);
    fork_number = atoi(argv[3]);
    run_time = atoi(argv[4]);
    printf("TEST NUMBER: %d\n", test_number);
    printf("FILE: %s\n", filename);
    printf("FORK NUMBER: %d\n", fork_number);
    printf("RUNNING TIME: %d\n", run_time);
  }

  // GETS THE FILE VALUES AND STORAGE THEM
  FILE *in_file;
  in_file = fopen(filename, "r");
  if (in_file == NULL){
      printf("Can't open file for reading.\n");
  } else {
      fscanf(in_file, "%d", &n);
      fscanf(in_file, "%d", &max_weight);
      int countNumber = 0;
      while(fscanf(in_file, "%d", &temp) == 1){
        countNumber++;
      }
      countNumber--;
      if(countNumber % 2 == 0)hasBestValue = 1;
      rewind(in_file);
      fscanf(in_file, "%d %d", &temp2, &temp2); //skip 2 positions
      int values[n];
      int weights[n];
      int knapsack[n];
      int countLine = 2;
      int countValue = 0;
      int countWeight = 0;
      for(int i = 0; i < n; i++){
        knapsack[i] = 0;
      }
      for(int i = 0; i < n*2; i++){
        if(i % 2 == 0){
          fscanf(in_file, "%d", &num);
          values[countValue] = num;
          countValue++;
        } else {
          fscanf(in_file, "%d", &num);
          weights[countWeight] = num;
          countWeight++;
        }
      }
      if(hasBestValue == 1) {
        fscanf(in_file, "%d", &bestValue);
        //printf("\n%d", bestvalue);
      } else {
        bestValue = 0;
      }
      /*printf("\n----------------------\n");
      for(int i = 0; i < n; i++){
        printf("%d ", values[i]);
      }
      printf("\n----------------------\n");
      for(int i = 0; i < n; i++){
        printf("%d ", weights[i]);
      }
      printf("\n----------------------\n");*/
      fclose(in_file);

      // CREATES THE FORKS AND START THE NUMBER ANALYZATION
      for (int i =0;i<fork_number;i++) {
        forks_id[i] = fork();
        if (forks_id[i] == 0) {
          //printf("--------  PID: %d -------- \n", getpid());
          modify_knapsack(
            getpid(),
            knapsack,
            values,
            weights,
            n,
            max_weight,
            bestValue,
            sm_bestVal,
            sm_pid,
            sm_time,
            begin,
            mutex
          );
          exit(0);
        }
      }

      // RUNNING TIME
      sleep(run_time);

      // CLOSE THE FORKS
      for (int i =0;i<fork_number;i++) {
        kill(forks_id[i],SIGKILL);
        wait(NULL);
      }

      // VALUES STORED IN THE SHARED MEMORY
      printf("\n");
      printf("MEMORY PID: %d\n", *sm_pid);
      printf("MEMORY BEST: VALUE %d\n", *sm_bestVal);
      printf("MEMORY BEST TIME: %f Segundos\n", *sm_time);
  }

  sem_close(mutex);
  return 0;
}
