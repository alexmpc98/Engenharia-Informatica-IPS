# Quest�o 1.1 

seminario <- data.frame(
  tipo = c("engenheiros", "professores", "analistas de dados", "alunos"),
  participantes = c(32, 20, 16, 12)
  
)

# Quest�o 1.2


Desc(seminario$participantes) #Calcula v�rias medidas para an�lise descritiva
summary(seminario$participantes) #Calcula v�rias medidas para an�lise descritiva

seminario$frequencia<-prop.table(seminario$participantes)*100   #No R, a func�o prop.table() gera 
#os percentuais para uma tabela


pie(seminario$frequencia,labels=seminario$tipo)


# Quest�o 2.1

library(readxl)
obesidade <- read_excel("D:/EST/disciplinas/M�todos Estat�sticos/Material de Estudo/Pasta R/obesidade.xlsx")
View(obesidade)

# Quest�o 2.2 

summary(obesidade$FCVC)
obesidade$FAVC <- factor(obesidade$FAVC, labels=c('N�o','Sim'))
obesidade$FCVC<- factor(obesidade$FCVC, labels=c('Nunca','As vezes','Sempre'))
summary(obesidade$FCVC)

# Quest�o 2.3

summary(obesidade$MTRANS)

local({
  .Table <- with(obesidade, table(MTRANS))
  cat("\ncounts:\n")
  print(.Table)
  cat("\npercentages:\n")
  print(round(100*.Table/sum(.Table), 2))
})

# Outra op��o para obter  as Frequ�ncias absolutas e relativas:


table(obesidade$MTRANS)
civil.tb <- table(obesidade$MTRANS)
prop.table(civil.tb)

Barplot(obesidade$MTRANS, xlab="CALC", ylab="Frequency", label.bars=TRUE)
piechart(obesidade$MTRANS, xlab="", ylab="", main="Gr�fico", scale="percent")

# obter a moda
civil.mo <- names(civil.tb)[civil.tb == max(civil.tb)]
civil.mo


# Quest�o 2.4

summary(obesidade$FCVC)

local({
  .Table <- with(obesidade, table(FCVC))
  cat("\ncounts:\n")
  print(.Table)
  cat("\npercentages:\n")
  print(round(100*.Table/sum(.Table), 2))
})

# Outra op��o para obter  as Frequ�ncias absolutas e relativas:


table(obesidade$FCVC)
civil.tb1 <- table(obesidade$FCVC)
prop.table(civil.tb1)



Barplot(obesidade$FCVC, xlab="FAVC", ylab="Frequency", label.bars=TRUE)
piechart(obesidade$FCVC, xlab="", ylab="", main="FCVC",  scale="percent")

mean(as.numeric(obesidade$FCVC))
median(as.numeric(obesidade$FCVC))
levels(obesidade$FCVC)[median(as.numeric(obesidade$FCVC))]

# obter a moda
civil.mo1 <- names(civil.tb1)[civil.tb1 == max(civil.tb1)]
civil.mo1



# Quest�o 2.5

# Quest�o 2.5 a)

obesidade_feminino<-subset(obesidade,Genero=="Feminino")






