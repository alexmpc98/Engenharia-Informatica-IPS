library(Rcmdr)

# Quest�o 4.1.1

wear <- data.frame(
 visc = c(1.6, 9.4, 15.5, 20, 22, 35.5, 43, 40.5, 33),
  desg = c(240, 181, 193, 155, 172, 110, 113, 75, 94)
  
)
# Quest�o 4.1.2

# Definimos o tamanho (cex) a cor (col) e a forma dos pontos (pch)

plot(wear$visc, wear$desg, main = "Viscosidade*Desgaste", xlab="Viscosidade",
     ylab="Desgaste", col="red", pch=16, cex=1.1)

plot(wear$desg, wear$visc, main = "Desgaste*Viscosidade", xlab="Desgaste",
     ylab="Viscosidade", col="red", pch=16, cex=1.1)

cor1 <-cor(wear$visc, wear$desg)
cor1
cor.test(wear$visc, wear$desg, method = "pearson")

# Quest�o 4.1.3

# De acordo com an�lise gr�fica e com o valor do coeficiente de correla��o de Pearson 
# verifica-se uma correla��o negativa entre a viscosidade e o desgaste do a�o

# Quest�o 4.1.4

resultado1<-lm(wear$desg ~ wear$visc)
resultado1
summary(resultado1)

predict(resultado1)
plot(wear$desg,wear$visc)
abline(lm(resultado1))

resultado2<-lm(wear$visc ~ wear$desg)
resultado2
summary(resultado2)

predict(resultado2)
plot(wear$visc,wear$desg)
abline(lm(resultado2))

# Quest�o 4.1.5

viscdados <-c(30,75)
previsao<-234.0707-3.509*viscdados
previsao

# Quest�o 4.1.6

residmodelo <-resid(resultado1)

plot(resid(resultado1) ~ predict(resultado1),pch=16) # Res�duos vs. Y esperado
abline(0,0,col="red") # Coloca uma reta no Y = 0

#-----------------------------------------------------------------


# Quest�o 4.2.1


library(readr)
fabrica_quimica <- read_delim("C:/Users/Jos� Palma/Downloads/fabrica_quimica.txt", 
                                +     "\t", escape_double = FALSE)

View(fabrica_quimica)

# Quest�o 4.2.2

plot(fabrica_quimica$Temperatura,fabrica_quimica$Vapor)
cor2 <-cor(fabrica_quimica$Temperatura,fabrica_quimica$Vapor)
cor2

# Quest�o 4.2.3

fabrica_quimica$Temperatura[3]<-32

# Quest�o 4.2.4

plot(fabrica_quimica$Temperatura,fabrica_quimica$Vapor)
cor3 <-cor(fabrica_quimica$Temperatura,fabrica_quimica$Vapor)
cor3


# Quest�o 4.2.5

resultado3<-lm(fabrica_quimica$Vapor~ fabrica_quimica$Temperatura)
resultado3
summary(resultado3)
summary(lm(fabrica_quimica$Vapor~ fabrica_quimica$Temperatura))


# Quest�o 4.2.6
  

residuals3<-residuals(resultado3) 

# Res�duos versus Valores Previstos
plot(resid(resultado3) ~ predict(resultado3),pch=16)
abline(h=0)

# Res�duos versus Valores da Vari�vel Explicativa

plot(fabrica_quimica$Temperatura,residuals(resultado3),xlab="Temperatura",ylab="Res�duos")
abline(h=0)


# Quest�o 4.2.7

# o volume aumenta 920.836


# Quest�o 4.2.8

tempdados <-c(47,19)
previsao2<--633.550+920.836*tempdados
previsao2