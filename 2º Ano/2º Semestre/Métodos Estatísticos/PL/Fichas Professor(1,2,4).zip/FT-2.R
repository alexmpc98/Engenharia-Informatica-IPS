library(Rcmdr)

# Quest�o 1.1

df1 <- data.frame(
  Mes = c("Janeiro", "Fevereiro", "Mar�o", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"),
  Chuva = c(101.0, 60.7, 75.1, 19.9, 26.7, 10.5, 2.5, 39.8, 5.7, 51.7, 50.1, 170.6)
  
)

# Quest�o 1.3

summary(df1)
numSummary(df1[,"Chuva", drop=FALSE], statistics=c("mean", "sd", "IQR", 
                                                    "quantiles"), quantiles=c(0,.25,.5,.75,1))
pretotal<-sum(df1$Chuva)
premean<-mean(df1$Chuva)
premedian<-median(df1$Chuva)
prevar<-var(df1$Chuva)
predesviopadrao<-sqrt(var(df1$Chuva))
premin<-min(df1$Chuva)
premax<-max(df1$Chuva)

# Quest�o 1.4

subset(df1, Chuva == min(df1$Chuva), select=Mes)
subset(df1, Chuva == max(df1$Chuva), select=Mes)
subset(df1, Chuva > mean(df1$Chuva), select=Mes)

# Quest�o 1.5
newdata <- df1[6:9,]
newdata$Chuva 
summary(newdata$Chuva)

# Quest�o 1.6

subset(df1, Chuva >50, select=Mes)

# Quest�o 1.7

install.packages("fdth")
library(fdth)

tf16<-fdt(df1$Chuva)

nclasses<-trunc(1+log(length(df1$Chuva), base = exp(1))/log(2, base = exp(1)))
nclasses
hist(df1$Chuva, main="With breaks=4")

# Quest�o 1.8

brk<-seq(0,180,30);# define os intervalos de classe
classes<-c("0-30","30-60","60-90","90-120","120-150","150-180")# nomes das classes
table(cut(df1$Chuva,breaks=brk,right=FALSE,labels=classes))
plot(table(cut(df1$Chuva,breaks=brk,right=FALSE,labels=classes)),ylab="Freq.")

# Exerc�cio 2

#Quest�o 2.1

data("sunspots")

#Quest�o 2.2
sunset_tabfreq<-fdt(sunspots)
hist(sunspots)

#Quest�o 2.3

Sun_nclasses<-trunc(1+log(length(sunspots), base = exp(1))/log(2, base = exp(1)))

tf2<-fdt(sunspots, start=0, end=260, h=10)

brk2<-seq(0,260,26);# define os intervalos de classe
classes2<-c("0-26","26-52","52-78","78-104","104-130","130-156","156-182","182-208","208-234","234-260")# nomes das classes
table(cut(sunspots,breaks=brk2,right=FALSE,labels=classes2))
sunset_tabfreq<-fdt(sunspots)
plot(table(cut(sunspots,breaks=brk2,right=FALSE,labels=classes2)),ylab="Freq.")

#Quest�o 3

numSummary(sunspots)

# (a) os extremos dos dados,
min(sunspots)
max(sunspots)

#  (b) os quartis dos dados;
quantile(sunspots, type=4)
summary(sunspots)
 
# (c) o nono decil dos dados;

quantile(sunspots,.9,type=5)

# (d) o terceiro percentil dos dados;

quantile(sunspots,.03,type=4)

# (e) as medidas de localiza��o central;

mean(sunspots)
median(sunspots)

# (f) as medidas de dispers�o;

var(sunspots)
sd(sunspots)

#  (g) as medidas de simetria e achatamento

library(DescTools)
install.packages("moments")
library(moments)
skewness(sunspots)
kurtosis(sunspots)

# 4 diagrama de extremos e quartis dos dados.

boxplot(sunspots,main="Boxplot")


